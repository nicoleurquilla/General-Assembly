<!-- Header
--------------------------------------------------------------------------- -->
<p align="center"><img alt="GA Logo" src="https://i.imgur.com/CYx9Es5.png" /></p>
<!-- ---------------------------------------------------------------------- -->


<!-- Class Links Table
--------------------------------------------------------------------------- -->
# External Class Links
<table align="center">
    <thead>
        <th colspan="3"><kbd><img width="65%" src="https://i.imgur.com/i43x8CP.png" /></kbd></th>
    </thead>
    <tbody>
        <tr>
            <td align="center">
                <a href="https://generalassembly.zoom.us/j/98813884550?pwd=enBCYVNzcURJZ2pwZjcrOWFiT0hmQT09">Classroom Zoom</a>
            </td>
            <td align="center">
                <a href="https://ga-students.slack.com/archives/C068AB6PD99">Classroom Slack Channel</a>
            </td>
            <td align="center">
                <a href="https://forms.gle/NrT4NzidsRo5UCS2A">Weekly Exit Tickets</a>
            </td>
        </tr>
    <tbody>
</table>
<!-- ---------------------------------------------------------------------- -->


<!-- Unit Schedule Tables
--------------------------------------------------------------------------- -->
# Course Schedule
Refer to this repository daily as it contains schedules of all lessons, labs, exercises, and deliverables discussed in class. Additionally, all recordings of in-class lessons are linked in this directory making it your go-to resource for review sessions during and after the cohort.


## Unit 1
<details>
<summary><strong>Schedule & Links</strong></summary>
<br/>

<table>
    <thead>
        <tr>
            <th colspan="7" align="center">
                <h3>Week 1</h3>
                <hr/>
                <h4>CLI | Git | HTML | CSS | JS</h4>
            </th>
        </tr>
        <tr>
            <th align="center">Day</th>
            <th align="center" width="40px">Zoom Recording</th>
            <th align="center">Topic(s)</th>
            <th align="center" width="240px">Resource Name</th>
            <th align="center" width="140px">Resource Type</th>
            <th align="center" width="120px">Resource Links</th>
            <th align="center">Due Date</th>
        </tr>
    </thead>
    <tbody>
        <!-- W01D01
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="5" align="center">W01D01<br/>- or -<br/>12/04/23</td>
            <td rowspan="2" align="center">Morning</td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=course-info&type=&sort=">Course Info</a></td>
            <td>Cohort Overview</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Cohort-Details">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Installfest</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Installfest">GitHub</a></td>
            <td>12/04</td>
        </tr>
        <tr>
            <td rowspan="3" align="center">Afternoon</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=html&type=&sort=">HTML</a></td>
            <td>Intro to HTML</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/HTML-Fundamentals/blob/main/Lessons/1.%20Intro%20to%20HTML.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/html-and-css-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/html/html-overview">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=css&type=&sort=">CSS</a></td>
            <td>Intro to CSS</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/CSS-Fundamentals/blob/main/Lessons/1.%20Intro%20to%20CSS.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/html-and-css-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/css/css-overview?page=1">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=html&type=&sort=">HTML</a> & <a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=css&type=&sort=">CSS</a></td>
            <td>About Me Page</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%201/1.%20About%20Me%20Page">GitHub</a></td>
            <td>12/05</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W01D02
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="6" align="center">W01D02<br/>- or -<br/>12/05/23</td>
            <td rowspan="2" align="center"><a href="https://generalassembly.zoom.us/rec/share/pYkBG6rbCcW-ei0FjqlCbU8lodhriavNrfQuHdtIxTv4PuymYpGKcPKwLDtQUKkQ.wSJRCQjRvl_9NpwM">Morning</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=html&type=&sort=">HTML</a> & <a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=css&type=&sort=">CSS</a></td>
            <td>About Me Page Presentation</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%201/1.%20About%20Me%20Page">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=cli&type=&sort=">CLI</a></td>
            <td>Intro to the CLI</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/CLI-Fundamentals/blob/main/Lessons/1.%20CLI%20Intro.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="4" align="center"><a href="https://generalassembly.zoom.us/rec/share/3VVjxO_VPGoKGFWOyTCRotY2v5lum8aUm-68NGLobxhn2dH34el5XTBWzN0wDJf5.CDJxypTDEKYtjT4G">Afternoon</a></td>
            <td rowspan="3"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=git&type=&sort=">Git</a></td>
            <td>Intro to Git</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Git-GitHub-Fundamentals/blob/main/Lessons/1.%20Intro%20to%20Git.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Intro to GitHub</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Git-GitHub-Fundamentals/blob/main/Lessons/2.%20Intro%20to%20GitHub.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Submitting Deliverables</td>
            <td>Exercise</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/blob/main/README.md#how-to-submit-a-deliverable">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=cli&type=&sort=">CLI</a></td>
            <td>Kitchen Organizer</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%201/2.%20Kitchen%20Organizer">GitHub</a></td>
            <td>12/06</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W01D03
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="5" align="center">W01D03<br/>- or -<br/>12/06/23</td>
            <td rowspan="2" align="center"><a href="https://generalassembly.zoom.us/rec/share/wuFOrFaFgmv8A9Mp20TPvGezm8twclTOoXo7n79euBEAcCtPYcRfyLDvALkzLOVf.SPrh2HH56mh9nYDY">Morning</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=git&type=&sort=">Git</a></td>
            <td>Happy Fun Ball</td>
            <td>Lab</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Happy-Fun-Ball">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="4"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=css&type=&sort=">CSS</a></td>
            <td>Selector Deep Dive</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/CSS-Fundamentals/blob/main/Lessons/3.%20Selector%20Deep%20Dive.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="3" align="center">Afternoon</td>
            <td>Layouts: Flexbox & Grid</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/CSS-Fundamentals/blob/main/Lessons/2.%20Flexbox%20%26%20Grid.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/html-and-css-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/css/css-overview?page=2">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Developer's Choice</td>
            <td>Exercise</td>
            <td>
                - <a href="https://cssgridgarden.com/">Grid</a><br/>
                - <a href="https://flexboxfroggy.com/">Flexbox</a><br/>
                - <a href="https://flukeout.github.io/">Selectors</a><br/>
            </td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Layout Practice</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%201/3.%20Layout%20Practice">GitHub</a></td>
            <td>12/07</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W01D04
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="5" align="center">W01D04<br/>- or -<br/>12/07/23</td>
            <td rowspan="2" align="center">Morning</td>
            <td rowspan="5"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=js&type=&sort=">JS</a></td>
            <td>Intro to JS & Data Types</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/JS-Fundamentals/blob/main/Lessons/01.%20Intro%20to%20JS.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/front-end-fundamentals-21-parent-us-online-ec-04-december-2023-06-march-2024-201492">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Control Flow</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/JS-Fundamentals/blob/main/Lessons/02.%20Control%20Flow.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/front-end-fundamentals-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/fundamentals-of-javascript/js-overview?page=2">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="3" align="center">
                <a href="https://generalassembly.zoom.us/rec/share/HA7L_Qdk5zRyizZOqCYAoBpbn5QFf0ntZRqe91a2R8S79YmOUZ0wDQWOh7x5czGe.IVS5-xN1PbZssnq4">Afternoon</a>
                <br>&<br>
                <a href="https://generalassembly.zoom.us/rec/share/5Eh6IQOYCEnebofNO2uVw9tc5MEBMtQSU-BytW1x_OSgV-5_ogQ4gZ4EUmYexGYF.RVweI1mflB2c4_bB?startTime=1701983508000">Daily Code Challenges</a>
            </td>
            <td>Control Flow</td>
            <td>Review</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/JS-Fundamentals/blob/main/Instructor%20Example%20Code/controlFlowReview.js">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Intro to Arrays</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/JS-Fundamentals/blob/main/Lessons/03.%20Intro%20to%20Arrays.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/front-end-fundamentals-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/fundamentals-of-javascript/js-overview?page=3">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Arrays & Control Flow Practice</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%201/4.%20Arrays%20%26%20Control%20Flow">GitHub</a></td>
            <td>12/08</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W01D05
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="6" align="center">W01D05<br/>- or -<br/>12/08/23</td>
            <td rowspan="4" align="center"><a href="https://generalassembly.zoom.us/rec/share/kJR8x4xtu8IK7hgnKh94_CaNPkEfQJ0Jdl72rrBWeA8rnj5CXTNPd0mb3yaqt2qX.-H_rkaJH3pGcxrqm?startTime=1702051782000">Morning</a></td>
            <td rowspan="6"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=js&type=&sort=">JS</a></td>
            <td>Intro to Functions</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/JS-Fundamentals/blob/main/Lessons/04.%20Intro%20to%20Functions.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/front-end-fundamentals-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/fundamentals-of-javascript/js-overview?page=5">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Scope</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/JS-Fundamentals/blob/main/Lessons/05.%20Scope.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/front-end-fundamentals-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/fundamentals-of-javascript/js-overview?page=6">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Functions & Scope</td>
            <td>Review</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/JS-Fundamentals/blob/main/Instructor%20Example%20Code/functionReview.js">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Template Literals</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/JS-Fundamentals/blob/main/Lessons/11.%20Template%20Literals.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="2" align="center">Afternoon</td>
            <td>Objects</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/JS-Fundamentals/blob/main/Lessons/06.%20Objects.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/front-end-fundamentals-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/fundamentals-of-javascript/js-overview?page=7">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Objects & Goblins</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%201/5.%20Objects%20%26%20Goblins">GitHub</a></td>
            <td>12/11</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
    </tbody>
</table>

<table>
    <thead>
        <tr>
            <th colspan="7" align="center">
                <h3>Week 2</h3>
                <hr/>
                <h4>HTML | CSS | JS | DOM</h4>
            </th>
        </tr>
        <tr>
            <th align="center">Day</th>
            <th align="center" width="40px">Zoom Recording</th>
            <th align="center">Topic(s)</th>
            <th align="center" width="240px">Resource Name</th>
            <th align="center" width="140px">Resource Type</th>
            <th align="center" width="120px">Resource Links</th>
            <th align="center">Due Date</th>
        </tr>
    </thead>
    <tbody>
        <!-- W02D01
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="4" align="center">W02D01<br/>- or -<br/>12/11/23</td>
            <td rowspan="2" align="center"><a href="https://generalassembly.zoom.us/rec/share/3lSQgMNPbfkLUhqQbvKCuoPrqU6Eq3BjhRkhCCZpcJPFRHiub3m4BT-xhF02gzI.fYvXJiYChKINPXrd?startTime=1702305056000">Morning</a></td>
            <td rowspan="4"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=js&type=&sort=">JS</a></td>
            <td>Objects & Goblins</td>
            <td>Review</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/blob/main/Unit%201/5.%20Objects%20%26%20Goblins/instructor_solution/objects.js">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Classes & OOP</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/JS-Fundamentals/blob/main/Lessons/07.%20Classes%20%26%20OOP.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="2" align="center"><a href="https://generalassembly.zoom.us/rec/share/RHvjeiD_Fj_r_afQjph4X7w5IaJ1-Iqxsop3XHcTRmFkHy7oGCMh-F5d3yqp6dXp.cbuoxEcOUehbQKTE">Afternoon</a></td>
            <td>NodeJS & NPM</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/JS-Fundamentals/blob/main/Lessons/00.%20NodeJS%20%26%20NPM.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Space Battle</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%201/6.%20Space%20Battle">GitHub</a></td>
            <td>12/14</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W02D02
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="6" align="center">W02D02<br/>- or -<br/>12/12/23</td>
            <td rowspan="4" align="center"><a href="https://generalassembly.zoom.us/rec/share/JgCoo6KRpCO8uEbr1EO6OgvnSouJukEGbFVKThgmOtJSm52iqn_ffrWtSVXabsQO._-F9Torm6hFZcXbv?startTime=1702390074000">Morning</a></td>
            <td rowspan="6"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=js&type=&sort=">JS</a></td>
            <td>Arrow Functions</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/JS-Fundamentals/blob/main/Lessons/08.%20Arrow%20Functions.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Callback Functions</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/JS-Fundamentals/blob/main/Lessons/09.%20Callback%20Functions.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Array Iterator Methods</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/JS-Fundamentals/blob/main/Lessons/10.%20Array%20Iterator%20Methods.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/front-end-fundamentals-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/fundamentals-of-javascript/js-overview?page=5">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Array Iterator Methods</td>
            <td>Review</td>
            <td>N/A</td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="2" align="center">Afternoon</td>
            <td>Array Iterator Practice</td>
            <td>Lab</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Array-Iterator-Practice">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Space Battle</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%201/6.%20Space%20Battle">GitHub</a></td>
            <td>12/14</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W02D03
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="7" align="center">W02D03<br/>- or -<br/>12/13/23</td>
            <td rowspan="3" align="center"><a href="https://generalassembly.zoom.us/rec/share/EqPPdvYHkRxCtXB_YAu--o0AGPTo1MLoiILQ-QhWoKz0me3xvN-pdJGHto547H7J.jtHmfJ6lnhrtlL6A">Morning</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=dom&type=&sort=">DOM</a></td>
            <td>Intro to the DOM</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/DOM-Fundamentals/blob/main/Lessons/1.%20Intro%20to%20the%20DOM.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/front-end-fundamentals-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/dom-manipulation-events/dom-overview?page=1">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=dom&type=&sort=">DOM</a> & <a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=css&type=&sort=">CSS</a></td>
            <td>CSS Variables</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/CSS-Fundamentals/blob/main/Lessons/4.%20Variables.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="5"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=dom&type=&sort=">DOM</a></td>
            <td>Interactive Menu Part 1</td>
            <td>Lab</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/DOM-Fundamentals/blob/main/Labs/Interactive%20Menu/Part%201.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="4" align="center"><a href="https://generalassembly.zoom.us/rec/share/PflZ4skc6Fu_ypvPRdU1zIvHMFtuyQyMcvBMcFJhrIUmTlOI1coUxF-DTMHuKLBV._LYqmQth5Src8bVb">Afternoon</a></td>
            <td>Events</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/DOM-Fundamentals/blob/main/Lessons/2.%20DOM%20Events.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/front-end-fundamentals-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/dom-manipulation-events/dom-overview?page=2">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Modals</td>
            <td>Exercise</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/DOM-Fundamentals/blob/main/Labs/1.%20Modals.md">GitHub</td>
            <td align="center">-</td>
        <tr>
            <td>Interactive Menu Part 2</td>
            <td>Lab</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/DOM-Fundamentals/blob/main/Labs/Interactive%20Menu/Part%202.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Space Battle</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%201/6.%20Space%20Battle">GitHub</a></td>
            <td>12/14</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W02D04
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="4" align="center">W02D04<br/>- or -<br/>12/14/23</td>
            <td rowspan="2" align="center"><a href="https://generalassembly.zoom.us/rec/share/eU1efHc06YZpzgPjTQjIKrCwwQMi44WUHAzcQe04rA6DYtQVoIR-3yqq6lQdsn4W.sTHdx-jxda3zYJ7i">Morning</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=css&type=&sort=">CSS</a></td>
            <td>Transform, Transitions, & Animations</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/CSS-Fundamentals/blob/main/Lessons/8.%20Transitions%20&%20Animations.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=js&type=&sort=">JS</a></td>
            <td>Space Battle CLI</td>
            <td>Review</td>
            <td><a href="#">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="2" align="center"><a href="https://generalassembly.zoom.us/rec/share/pm1bipo66_QOBY1HzzSgKNnfvfJ0VbTZj_l0WiZi4bOjRq65ImwnhLP16sP01T5a.ni8AwIIISYh9LHRT">Afternoon</a></td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=dom&type=&sort=">DOM</a></td>
            <td>Space Battle DOM</td>
            <td>Exercise</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Space-Battle-DOM/blob/main/README.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Developer's Choice</td>
            <td>Lab</td>
            <td>
                - <a href="https://git.generalassemb.ly/SEBR-Tardigrade/DOM-Fundamentals/tree/main/Labs/Interactive%20Menu">DOM Menu</a>
                <br/>
                - <a href="https://git.generalassemb.ly/SEBR-Tardigrade/Page-Transitions-Lab">Page Transitions</a>
            </td>
            <td align="center">-</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W02D05
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="6" align="center">W02D05<br/>- or -<br/>12/15/23</td>
            <td rowspan="3" align="center"><a href="https://generalassembly.zoom.us/rec/share/AVEhcN9Vz3xhFitWCJgNIgpgTXd3bYWf4MMDdqJxTs138SrlwtrH6mxsc2lEEcLH.Q16bOj2OgUqrTieZ">Morning</a></td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=dom&type=&sort=">DOM</a></td>
            <td>Rock, Paper, Scissors Walkthrough</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%201/7.%20Rock%2C%20Paper%2C%20Scissors">GitHub</a></td>
            <td>12/15</td>
        </tr>
        <tr>
            <td>Simple SPA</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/DOM-Fundamentals/blob/main/Lessons/3.%20Simple%20SPA.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=html&type=&sort=">HTML</a></td>
            <td>Simple MPA</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/HTML-Fundamentals/blob/main/Lessons/2.%20Simple%20MPA.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="3" align="center"><a href="https://generalassembly.zoom.us/rec/share/sv5tVrYhPnkcEcZNzZC2KSvcUK5fmdNxl4LJFcaQQdQOCoeJ-1QVe3HxU6WEoP1W.UT_jXmJADgGlQHCQ">Afternoon</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=css&type=&sort=">CSS</a></td>
            <td>Responsive Design</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/CSS-Fundamentals/blob/main/Lessons/5.%20Responsive%20Design.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/html-and-css-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/css/css-overview?page=5">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=course-info&type=&sort=">Course Info</a></td>
            <td>Unit 1 Project Intro</td>
            <td>Unit Project</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/tree/main/Unit%201">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Project Proposal</td>
            <td>Unit Project</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/issues/new?assignees=&labels=Pending&template=project-proposal.md&title=Project+%23+-+Your+Name+-+Your+Pod+Lead">GitHub</a></td>
            <td>12/15</td>
        </tr>
        <!-- -------------------------------------------------------------- -->

<table>
    <thead>
        <tr>
            <th colspan="7" align="center">
                <h3>Weeks 3 & 4</h3>
                <hr/>
                <h4>GitHub Pages | Project Presentations</h4>
            </th>
        </tr>
        <tr>
            <th align="center">Day</th>
            <th align="center" width="40px">Zoom Recording</th>
            <th align="center">Topic(s)</th>
            <th align="center" width="240px">Resource Name</th>
            <th align="center" width="140px">Resource Type</th>
            <th align="center" width="120px">Resource Links</th>
            <th align="center">Due Date</th>
        </tr>
    </thead>
    <tbody>
        <!-- W03D04
        ------------------------------------------------------------------- -->
        <tr>
            <td align="center">W03D04<br/>- or -<br/>12/21/23</td>
            <td align="center"><a href="https://generalassembly.zoom.us/rec/share/P5ZpdHMdpcqanxgEaTKyfVCHZk5OHdqx6u0gT64jZyLb1GoZnnPyxB9ZZcDWnbZL.o27omDjz0GTi49TY">Morning</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=git&type=&sort=">Git</a></td>
            <td>Deployment to GitHub Pages</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Git-GitHub-Fundamentals/blob/main/Lessons/3.%20GitHub%20Pages.md">GitHub</a></td>
            <td>12/22</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W03D04
        ------------------------------------------------------------------- -->
        <tr>
            <td align="center">W04D01<br/>- or -<br/>01/02/24</td>
            <td align="center">Morning</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=course-info&type=&sort=">Course Info</a></td>
            <td>Project Presentations</td>
            <td>Unit Project</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/issues/new?assignees=&labels=Pending&template=project-submission.md&title=YOUR+FULL+NAME">GitHub</a></td>
            <td>01/02</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
    <tbody>
</table>
</details>


## Unit 2
<details>
<summary><strong>Schedule & Links</strong></summary>
<br/>
    
<table>
    <thead>
        <tr>
            <th colspan="7" align="center">
                <h3>Week 4</h3>
                <hr/>
                <h4>Internet & APIs | JS | CSS | Express</h4>
            </th>
        </tr>
        <tr>
            <th align="center">Day</th>
            <th align="center" width="40px">Zoom Recording</th>
            <th align="center">Topic(s)</th>
            <th align="center" width="240px">Resource Name</th>
            <th align="center" width="140px">Resource Type</th>
            <th align="center" width="120px">Resource Links</th>
            <th align="center">Due Date</th>
        </tr>
    </thead>
    <tbody>
        <!-- W04D02
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="4" align="center">W04D02<br/>- or -<br/>01/02/24</td>
            <td align="center">Morning</td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=css&type=&sort=">CSS</a></td>
            <td>Intro to Frameworks</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/CSS-Fundamentals/blob/main/Lessons/6.%20Intro%20to%20Frameworks.md">GitHub</a> | <a href="https://generalassembly.zoom.us/rec/share/xFTXEo3nhmGbOXggFJaQddN8MVRQ6DQjD2kTBH81YOrOcA5ODfrcrCzVRFZS8yFm.83GBio8VsfYnYWL_?startTime=1693490465000">Video</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="3" align="center">Afternoon</td>
            <td>Bootstrap Basics</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/CSS-Fundamentals/blob/main/Lessons/7.%20Bootstrap%20Basics.md">GitHub</a> | <a href="https://generalassembly.zoom.us/rec/share/Cctu9UrYY6XGDooW5F9V0C7n3-Vl5jCqyAyD5sVKyG2_qZ8fDoCv2_R-L1EuK4eV.d7y7udSOxnaZHWX4?startTime=1693492009000">Video</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=internet&type=&sort=">Internet</a></td>
            <td>Intro to the Internet</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Internet-Fundamentals">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Intro to Full-stack & HTTP</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Internet-Fundamentals/blob/main/Lessons/1.%20Intro%20to%20Full-stack%20%26%20HTTP.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/full-stack-development-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/internet-fundamentals/getting-started">TI</a></td>
            <td align="center">-</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W04D03
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="5" align="center">W04D03<br/>- or -<br/>01/03/24</td>
            <td rowspan="3" align="center"><a href="https://generalassembly.zoom.us/rec/play/I2Z3dld2WyvYHdSPguLvbcprFG5uD6lyDLMxmjrogJDiMGiqn_V7R2LwPaXp7-lAUfa13cBKXx77r4I3.GZcifsYSRgU82kIX">Morning</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=js&type=&sort=">JS</a></td>
            <td>Asynchronous JS</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/JS-Fundamentals/blob/main/Lessons/12.%20Asynchronous%20JS.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=internet&type=&sort=">Internet</a></td>
            <td>APIs & AJAX</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Internet-Fundamentals/blob/main/Lessons/2.%20APIs%20%26%20AJAX.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Pokemon Playground</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%202/1.%20Pokemon%20Playground">GitHub</a></td>
            <td>01/04</td>
        </tr>
        <tr>
            <td rowspan="2" align="center">Afternoon</td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=express&type=&sort=">Express</a></td>
            <td>MVC Architecture</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Express-Fundamentals/blob/main/Lessons/1.%20MVC%20Architecture.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Intro to Express</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Express-Fundamentals/blob/main/Lessons/2.%20Intro%20to%20Express.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/full-stack-development-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/the-express-js-framework/express-fundamentals?page=1">TI</a></td>
            <td align="center">-</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W04D04
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="7" align="center">W04D04<br/>- or -<br/>01/04/24</td>
            <td rowspan="3" align="center"><a href="https://generalassembly.zoom.us/rec/share/vDEMeCEZKxOQXxch5BQ1kAV5jx6V6CpFYlso7lxjB-GfDUmeH1xChL0NWYcAjc1U.R_jHk_mUSDEjx4h7">Morning</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=internet&type=&sort=">Internet</a></td>
            <td>Pokemon Playground</td>
            <td>Review</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%202/1.%20Pokemon%20Playground">GitHub</a></td>
            <td>01/04</td>
        </tr>
        <tr>
            <td rowspan="6"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=express&type=&sort=">Express</a></td>
            <td>Middleware</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Express-Fundamentals/blob/main/Lessons/3.%20Middleware.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>URL Parameters</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Express-Fundamentals/blob/main/Lessons/4.%20URL%20Parameters.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="4" align="center"><a href="https://generalassembly.zoom.us/rec/share/-GJTR2zJ6TX8KqFmMm4yihB_ekRRYNXqhluqp6WX33OsEAhzoQKub0Dvo_uwQkA.Cre-D_8iW-W0KN_A">Afternoon</a></td>
            <td rowspan="2">Parameter Potpourri</td>
            <td>Lab</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Express-Fundamentals/blob/main/Labs/parameter-potpourri/README.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Review</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Express-Fundamentals/blob/main/Labs/parameter-potpourri/README.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>EJS Partials</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Express-Fundamentals/blob/main/Lessons/5.%20EJS%20Partials.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>GitPub</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%202/2.%20GitPub">GitHub</a></td>
            <td>01/05</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W04D05
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="3" align="center">W04D05<br/>- or -<br/>01/05/24</td>
            <td rowspan="2" align="center"><a href="#">Morning</a></td>
            <td rowspan="3"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=express&type=&sort=">Express</a></td>
            <td>3rd Party APIs & Express</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Express-Fundamentals/blob/main/Lessons/6.%203rd%20Party%20APIs.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Movie Match</td>
            <td>Exercise</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Express-Fundamentals/tree/main/Labs/movie-match">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td align="center">Afternoon</td>
            <td>Pokedexes</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%202/3.%20Pokedexes">GitHub</a></td>
            <td>01/08</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
    </tbody>
</table>

<table>
    <thead>
        <tr>
            <th colspan="7" align="center">
                <h3>Week 5</h3>
                <hr/>
                <h4>MongoDB | Mongoose | Express | Internet</h4>
            </th>
        </tr>
        <tr>
            <th align="center">Day</th>
            <th align="center" width="40px">Zoom Recording</th>
            <th align="center">Topic(s)</th>
            <th align="center" width="240px">Resource Name</th>
            <th align="center" width="140px">Resource Type</th>
            <th align="center" width="120px">Resource Links</th>
            <th align="center">Due Date</th>
        </tr>
    </thead>
    <tbody>
        <!-- W05D01
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="5" align="center">W05D01<br/>- or -<br/>01/08/24</td>
            <td rowspan="3" align="center"><a href="https://generalassembly.zoom.us/rec/share/3IfA9QvTEOwpTOX1rLGKf58vTlsEei89G4kkd3qj_MlfeTwTZ1Hf2MDQqJgETUQv.3ReN2_rsJjuc88M4">Morning</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=express&type=&sort=">Express</a></td>
            <td>Pokedexes</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%202/3.%20Pokedexes">GitHub</a></td>
            <td>01/08</td>
        </tr>
        <tr>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=mongo&type=&sort=">MongoDB</a></td>
            <td>MongoDB Atlas Account Set Up</td>
            <td>Exercise</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Mongo-Mongoose-Fundamentals/blob/main/Lessons/1.%20Set%20Up%20MongoDB%20Atlas.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Intro to MongoDB</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Mongo-Mongoose-Fundamentals/blob/main/Lessons/2.%20Intro%20to%20MongoDB.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/full-stack-development-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/mongodb-mongoosejs/mongodb?page=1">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="2" align="center">Afternoon</td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=mongo&type=&sort=">Mongoose</a></td>
            <td>Intro to Mongoose</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Mongo-Mongoose-Fundamentals/blob/main/Lessons/5.%20Intro%20to%20Mongoose.md">GitHub</a> | <a href="https://generalassembly.zoom.us/rec/share/b8SoeZ8xULYK5TMV60xfQWBUo2Toj8uzIJgk3Hm4haRLwlt4GoELqAHl7KUCkWrq.KjsRSuigObvTT5pV">Video</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Mongoose Vampires</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%202/4.%20Mongoose%20Vampires">GitHub</a></td>
            <td>01/09</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W05D02
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="5" align="center">W05D02<br/>- or -<br/>01/09/24</td>
            <td rowspan="3" align="center"><a href="https://generalassembly.zoom.us/rec/share/d_UWWYvh81RcF4NP9sSBpH0bRHa0KfAb3oRnB_juvG3Dy9IY3QwIKAmH0SXkw6Np.RmgBQtdD8RHVnRvY">Morning</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=mongoose&type=&sort=">Mongoose</a></td>
            <td>Mongoose Relationships</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Mongo-Mongoose-Fundamentals/blob/main/Lessons/6.%20Mongoose%20Relationships.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=internet&type=&sort=">Internet</a></td>
            <td>REST APIs & CRUD</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Internet-Fundamentals/blob/main/Lessons/3.%20REST%20APIs%20%26%20CRUD.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="3"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=express&type=&sort=">Express</a></td>
            <td>Furever Friends Part 1</td>
            <td rowspan="2">Exercise</td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Furever-Friends/tree/main/part-1">GitHub</a></td>
            <td rowspan="2" align="center">-</td>
        </tr>
        <tr>
            <td rowspan="2" align="center"><a href="https://generalassembly.zoom.us/rec/share/icTMZm5EOIfDE0ecTg9UskvLuaze--qiZm49h-gQsj4ieJ0iYEkdZ0E0MebD5Sr9.XLAJD-byetweq4wp">Afternoon</a></td>
            <td>Furever Friends Part 1 cont.</td>
        </tr>
        <tr>
            <td>Express Store Part 1</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%202/5.%20Express%20Store#part-1---index-show-and-seed-routes">GitHub</a></td>
            <td>01/12</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W05D03
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="4" align="center">W05D03<br/>- or -<br/>01/10/24</td>
            <td rowspan="2" align="center"><a href="https://generalassembly.zoom.us/rec/share/Whyl7HHA218R3MH_plYEgVb3yDkXuPRDWltEIu6ziClUJo3Nbs-UgPTtQqI-XsGK.jrwgZexob5j6rCsV">Morning</a></td>
            <td rowspan="4"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=express&type=&sort=">Express</a></td>
            <td>Furever Friends Part 1</td>
            <td>Exercise</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Furever-Friends/tree/main/part-1">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Furever Friends Part 2</td>
            <td rowspan="2">Exercise</td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Furever-Friends/tree/main/part-2">GitHub</a></td>
            <td rowspan="2" align="center">-</td>
        </tr>
        <tr>
            <td rowspan="2" align="center"><a href="https://generalassembly.zoom.us/rec/share/FMAdfrikivfwCF5pAB70NVMIwVPPWvBj5K83vcMDrkrs_M5kNSThg_ikx3yjW9Yx.Lp2q4-AvsF-Wl5eN">Afternoon</a></td>
            <td>Furever Friends Part 2 cont.</td>
        </tr>
        <tr>
            <td>Express Store Part 2</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%202/5.%20Express%20Store#part-2---all-other-restful-routes">GitHub</a></td>
            <td>01/12</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W05D04
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="2" align="center">W05D04<br/>- or -<br/>01/11/24</td>
            <td align="center"><a href="https://generalassembly.zoom.us/rec/share/fafFaUvXWHi1fc8pVIBMdGXSDKZJ_vL-SNk54i896vK76qyM130TqOHs5ma9jR2m.oKnfZ7OOTyHBQGLo">Morning</a></td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=express&type=&sort=">Express</a></td>
            <td>Furever Friends Part 3</td>
            <td>Exercise</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Furever-Friends/tree/main/part-3">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Afternoon</td>
            <td>Express Store Part 3</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%202/5.%20Express%20Store#part-3---reviews">GitHub</a></td>
            <td>01/12</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W05D05
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="3" align="center">W05D05<br/>- or -<br/>01/12/24</td>
            <td align="center"><a href="https://generalassembly.zoom.us/rec/share/IYRLgIz4kAVEIdpESukNJqtPEDpO9ix6Z-ybG9-NLNmMRfSSEkziVzGixDEB_wej.b34udKP_8kNVteQX">Morning</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=express&type=&sort=">Express</a></td>
            <td>Express Store Presentations</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%202/5.%20Express%20Store">GitHub</a></td>
            <td>01/12</td>
        </tr>
        <tr>
            <td rowspan="2" align="center">Afternoon</td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=course-info&type=&sort=">Course Info</a></td>
            <td>Unit 1 Project Intro</td>
            <td>Unit Project</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/tree/main/Unit%201">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Project Proposal</td>
            <td>Unit Project</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/issues/new?assignees=&labels=Pending&template=project-proposal.md&title=Project+%23+-+Your+Name+-+Your+Pod+Lead">GitHub</a></td>
            <td>01/12</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
    </tbody>
</table>

<table>
    <thead>
        <tr>
            <th colspan="7" align="center">
                <h3>Weeks 6 & 7</h3>
                <hr/>
                <h4>GitHub Campus | Heroku | Project Presentations</h4>
            </th>
        </tr>
        <tr>
            <th align="center">Day</th>
            <th align="center" width="40px">Zoom Recording</th>
            <th align="center">Topic(s)</th>
            <th align="center" width="240px">Resource Name</th>
            <th align="center" width="140px">Resource Type</th>
            <th align="center" width="120px">Resource Links</th>
            <th align="center">Due Date</th>
        </tr>
    </thead>
    <tbody>
        <!-- W06D02
        ------------------------------------------------------------------- -->
        <tr>
            <td align="center">W06D02<br/>- or -<br/>01/16/24</td>
            <td align="center"><a href="https://generalassembly.zoom.us/rec/share/YYR_3iGxMkaxgXkq6MjpOWLjQRGBpzQVtJ31RzkzD1X7lemcnhkLLpcwn40sSfYS.ZDmuBXz770fxc6ED">Morning</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=git&type=&sort=">Git</a></td>
            <td>Getting Started with GitHub Campus</td>
            <td>Live Lesson</td>
            <td>
                <a href="https://git.generalassemb.ly/SEBR-Tardigrade/Git-GitHub-Fundamentals/blob/main/Lessons/4.%20GitHub%20Campus.md">Markdown 1</a>
                <br>
                <a href="https://git.generalassemb.ly/SEBR-Tardigrade/Heroku-Deployment/blob/main/Lessons/1.%20Getting%20Started%20with%20Heroku.md">Markdown 2</a>
            </td>
            <td align="center">-</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W06D05
        ------------------------------------------------------------------- -->
        <tr>
            <td align="center">W06D05<br/>- or -<br/>01/19/24</td>
            <td align="center"><a href="https://generalassembly.zoom.us/rec/share/fbubk1YQsK7YesRXohtLQ5aKIj5gIXAapfSp3UK94untHJHS7EhmPJlr2_n6lXuW.jdoLtuG7tkvui4DC">Morning</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=heroku&type=&sort=">Heroku</a></td>
            <td>MEN Stack Deployment on Heroku</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Heroku-Deployment/blob/main/Lessons/2.%20MEN%20Stack%20Deployment.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W07D01
        ------------------------------------------------------------------- -->
        <tr>
            <td align="center">W07D01<br/>- or -<br/>01/22/24</td>
            <td align="center">Morning</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=course-info&type=&sort=">Course Info</a></td>
            <td>Project Presentations</td>
            <td>Unit Project</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/issues/new?assignees=&labels=Pending&template=project-submission.md&title=YOUR+FULL+NAME">GitHub</a></td>
            <td>01/22</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
    <tbody>
</table>
</details>


## Unit 3
<details>
<summary><strong>Schedule & Links</strong></summary>
<br/>

<table>
    <thead>
        <tr>
            <th colspan="7" align="center">
                <h3>Week 7</h3>
                <hr/>
                <h4>Team Work | Python | CLI</h4>
            </th>
        </tr>
        <tr>
            <th align="center">Day</th>
            <th align="center" width="40px">Zoom Recording</th>
            <th align="center">Topic(s)</th>
            <th align="center" width="240px">Resource Name</th>
            <th align="center" width="140px">Resource Type</th>
            <th align="center" width="120px">Resource Links</th>
            <th align="center">Due Date</th>
        </tr>
    </thead>
    <tbody>
        <!-- W07D01
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="4" align="center">W07D01<br/>- or -<br/>01/22/24</td>
            <td rowspan="4" align="center">Afternoon</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=course-info&type=&sort=">Course Info</a></td>
            <td>Working in Teams</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/blob/main/Unit%203/Working%20in%20Teams.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="3"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=python&type=&sort=">Python</a></td>
            <td>Intro to Python</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Python-Fundamentals/blob/main/Lessons/1.%20Intro%20to%20Python.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/python-and-django-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/fundamentals-of-python/python-overview?page=1">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Control Flow</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Python-Fundamentals/blob/main/Lessons/2.%20Control%20Flow.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/python-and-django-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/fundamentals-of-python/python-overview?page=2">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Control Flow Practice</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%203/1.%20Python%20Control%20Flow">GitHub</a></td>
            <td>01/23</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W07D02
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="3" align="center">W07D02<br/>- or -<br/>01/23/24</td>
            <td align="center">Morning</td>
            <td rowspan="3"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=python&type=&sort=">Python</a></td>
            <td>Containers: Parts 1-5</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Python-Fundamentals/blob/main/Lessons/3.%20Containers.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/python-and-django-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/fundamentals-of-python/python-overview?page=3">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="2" align="center">Afternoon</td>
            <td>Functions</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Python-Fundamentals/blob/main/Lessons/4.%20Functions.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/python-and-django-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/fundamentals-of-python/python-overview?page=8">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Containers & Functions Practice</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%203/2.%20Containers%20%26%20Functions">GitHub</a></td>
            <td>01/24</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W07D03
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="3" align="center">W07D03<br/>- or -<br/>01/24/24</td>
            <td rowspan="2" align="center">Morning</td>
            <td rowspan="3"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=python&type=&sort=">Python</a></td>
            <td>Classes & OOP: Parts 1-3</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Python-Fundamentals/blob/main/Lessons/5.%20Classes%20%26%20OOP.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/python-and-django-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/fundamentals-of-python/python-overview?page=9">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="2">Pokémon TCG</td>
            <td rowspan="2">Group Lab</td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Python-Pokemon-TCG">GitHub</a></td>
            <td rowspan="2" align="center">-</td>
        </tr>
        <tr>
            <td align="center">Afternoon</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W07D04
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="3" align="center">W07D04<br/>- or -<br/>01/25/24</td>
            <td align="center">Morning</td>
            <td rowspan="3"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=python&type=&sort=">Python</a></td>
            <td rowspan="3">Pokémon TCG</td>
            <td rowspan="2">Group Lab</td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Python-Pokemon-TCG">GitHub</a></td>
            <td rowspan="3" align="center">-</td>
        </tr>
        <tr>
            <td rowspan="2" align="center">Afternoon</td>
        </tr>
        <tr>
            <td>Group Presentation</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Python-Pokemon-TCG#presention">GitHub</a></td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W07D05
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="5" align="center">W07D05<br/>- or -<br/>01/26/24</td>
            <td rowspan="3" align="center"><a href="https://generalassembly.zoom.us/rec/share/4hEqrwWDHQemYtwAY2ytvqy6icB5F9FV-8nXTS-d6sBY7uGYrCjlVADU1MOsu8Ii.N30az80XCqPxievm">Morning</a></td>
            <td rowspan="5"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=psql&type=&sort=">PSQL</a></td>
            <td>Installing PostgreSQL</td>
            <td>Exercise</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/PostgreSQL-Fundamentals/blob/main/Lessons/1.%20Installing%20PostgreSQL.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Intro to SQL & Relational Databases</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/PostgreSQL-Fundamentals/blob/main/Lessons/2.%20Intro%20to%20SQL.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/python-and-django-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/postgresql/sql?page=1">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Querying Data</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/PostgreSQL-Fundamentals/blob/main/Lessons/3.%20Querying%20Data.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="2" align="center"><a href="https://generalassembly.zoom.us/rec/share/mFfO_LacOlr5VVhMtBYaZxNf1GFKMiqGDy6i6z3kB3BY85CpZGI8g0u16-0EuIMF.ioeMdPoEpcJ8kBG8">Afternoon</a></td>
            <td>Basic Joins</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/PostgreSQL-Fundamentals/blob/main/Lessons/4.%20Basic%20Joins.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>PSQL Practice: Carmen & NFL</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%203/3.%20PSQL%20Practice">GitHub</a></td>
            <td>01/29</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
    </tbody>
</table>

<table>
    <thead>
        <tr>
            <th colspan="7" align="center">
                <h3>Week 8</h3>
                <hr/>
                <h4>Team Work | Git | Python | Django</h4>
            </th>
        </tr>
        <tr>
            <th align="center">Day</th>
            <th align="center" width="40px">Zoom Recording</th>
            <th align="center">Topic(s)</th>
            <th align="center" width="240px">Resource Name</th>
            <th align="center" width="140px">Resource Type</th>
            <th align="center" width="120px">Resource Links</th>
            <th align="center">Due Date</th>
        </tr>
    </thead>
    <tbody>
        <!-- W08D01
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="5" align="center">W08D01<br/>- or -<br/>01/29/24</td>
            <td rowspan="3" align="center">Morning</td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=course-info&type=&sort=">Course Info</a></td>
            <td>Unit 3 Project Intro</td>
            <td>Unit Project</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/tree/main/Unit%203">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Pitch Decks & Trello</td>
            <td>Unit Project</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/blob/main/Unit%203/README.md#pitch-deck---presented-by-your-team-on-february-2nd-2024">GitHub</a></td>
            <td>02/02</td>
        </tr>
        <tr>
            <td rowspan="3"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=django&type=&sort=">Django</a></td>
            <td>Intro to Django</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Django-Fundamentals/blob/main/Lessons/1.%20Intro%20to%20Django.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/python-and-django-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/django-web-framework/django-overview?page=1">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="2" align="center">Afternoon</td>
            <td>URLs, Templates, & Views</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Django-Fundamentals/blob/main/Lessons/2.%20URLs%2C%20Views%2C%20%26%20Templates.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/python-and-django-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/django-web-framework/django-overview?page=2">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Finch Collector Part 1</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%203/4.%20Finch%20Collector">GitHub</a></td>
            <td>02/02</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W08D02
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="4" align="center">W08D02<br/>- or -<br/>01/30/24</td>
            <td rowspan="2" align="center"><a href="https://generalassembly.zoom.us/rec/share/35Y8josEw-6-GRoMC14FFO0__fz5XwgmQ5xbv4wg1e5iB5obfM5vXZTztE_4dPa2.OsZmWfaAd7-tJxkZ">Morning</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=git&type=&sort=">Git</a></td>
            <td>Team Workflows</td>
            <td>Exercise</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Git-GitHub-Fundamentals/blob/main/Lessons/5.%20Team%20Workflows.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=course-info&type=&sort=">Course Info</a></td>
            <td>Pitch Decks & Trello</td>
            <td>Unit Project</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/blob/main/Unit%203/README.md#pitch-deck---presented-by-your-team-on-february-2nd-2024">GitHub</a></td>
            <td>02/02</td>
        </tr>
        <tr>
            <td rowspan="2" align="center">Afternoon</td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=django&type=&sort=">Django</a></td>
            <td>Intro to Models</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Django-Fundamentals/blob/main/Lessons/3.%20Intro%20to%20Models.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/python-and-django-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/django-web-framework/django-overview?page=4">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Finch Collector Part 2</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%203/4.%20Finch%20Collector#part-2">GitHub</a></td>
            <td>02/02</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W08D03
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="3" align="center">W08D03<br/>- or -<br/>01/31/24</td>
            <td rowspan="2" align="center">Morning</td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=django&type=&sort=">Django</a></td>
            <td>Class-based Views</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Django-Fundamentals/blob/main/Lessons/4.%20Class-based%20Views.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/python-and-django-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/django-web-framework/django-overview?page=5">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Finch Collector Part 3</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%203/4.%20Finch%20Collector#part-3">GitHub</a></td>
            <td>02/02</td>
        </tr>
        <tr>
            <td align="center">Afternoon</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=course-info&type=&sort=">Course Info</a></td>
            <td>Pitch Decks & Trello</td>
            <td>Unit Project</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/blob/main/Unit%203/README.md#pitch-deck---presented-by-your-team-on-february-2nd-2024">GitHub</a></td>
            <td>02/02</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W08D04
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="3" align="center">W08D04<br/>- or -<br/>02/01/24</td>
            <td rowspan="2" align="center">Morning</td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=django&type=&sort=">Django</a></td>
            <td>One-to-Many Models</td>
            <td>Async Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Django-Fundamentals/blob/main/Lessons/5.%20One-to-Many%20Models.md">GitHub</a> | <a href="https://hub.generalassemb.ly/learn/course/python-and-django-21-parent-us-online-ec-04-december-2023-06-march-2024-201492/django-web-framework/django-overview?page=6">TI</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Finch Collector Part 4</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%203/4.%20Finch%20Collector#part-4">GitHub</a></td>
            <td>02/02</td>
        </tr>
        <tr>
            <td align="center">Afternoon</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=course-info&type=&sort=">Course Info</a></td>
            <td>Pitch Decks & Trello</td>
            <td>Unit Project</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/blob/main/Unit%203/README.md#pitch-deck---presented-by-your-team-on-february-2nd-2024">GitHub</a></td>
            <td>02/02</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W08D05
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="2" align="center">W08D05<br/>- or -<br/>02/02/24</td>
            <td rowspan="2" align="center">Morning</td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=course-info&type=&sort=">Course Info</a></td>
            <td>Pitch Deck Presentations</td>
            <td rowspan="2">Unit Project</td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/blob/main/Unit%203/README.md#pitch-deck---presented-by-your-team-on-february-2nd-2024">GitHub</a></td>
            <td rowspan="2">02/02</td>
        </tr>
        <tr>
            <td>Proposal Review & Approval</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
    </tbody>
</table>

<table>
    <thead>
        <tr>
            <th colspan="7" align="center">
                <h3>Weeks 9 & 10</h3>
                <hr/>
                <h4>Python | Heroku | Project Presentations</h4>
            </th>
        </tr>
        <tr>
            <th align="center">Day</th>
            <th align="center" width="40px">Zoom Recording</th>
            <th align="center">Topic(s)</th>
            <th align="center" width="240px">Resource Name</th>
            <th align="center" width="140px">Resource Type</th>
            <th align="center" width="120px">Resource Links</th>
            <th align="center">Due Date</th>
        </tr>
    </thead>
    <tbody>
        <!-- W09D05
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="2" align="center">W09D05<br/>- or -<br/>02/09/24</td>
            <td rowspan="2" align="center"><a href="https://generalassembly.zoom.us/rec/share/eLFcfYLMXN7wtdEHBhRIrM39BnSheqFbS-W9GWBKCjYONNQBaLpQlsy3ZCT44ww6._HqwITNiJJEL8tOM?startTime=1707487404000">Morning</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=python&type=&sort=">Python</a></td>
            <td>Pip & Virtual Environments</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Python-Fundamentals/blob/main/Lessons/6.%20Pip%20%26%20Virtual%20Environments.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=heroku&type=&sort=">Heroku</a></td>
            <td>Deploying a Django Project</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Heroku-Deployment/blob/main/Lessons/3.%20Django%20Deployment.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W10D01
        ------------------------------------------------------------------- -->
        <tr>
            <td align="center">W10D01<br/>- or -<br/>02/12/24</td>
            <td align="center">Morning</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=course-info&type=&sort=">Course Info</a></td>
            <td>Project Presentations</td>
            <td>Unit Project</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/issues/new?assignees=&labels=Pending&template=project-submission.md&title=YOUR+FULL+NAME">GitHub</a></td>
            <td>02/12</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
    <tbody>
</table>
</details>


## Unit 4
<details open>
<summary><strong>Schedule & Links</strong></summary>
<br/>

<table>
    <thead>
        <tr>
            <th colspan="7" align="center">
                <h3>Week 10</h3>
                <hr/>
                <h4>JavaScript | React | MERN | TailwindCSS</h4>
            </th>
        </tr>
        <tr>
            <th align="center">Day</th>
            <th align="center" width="40px">Zoom Recording</th>
            <th align="center">Topic(s)</th>
            <th align="center" width="240px">Resource Name</th>
            <th align="center" width="140px">Resource Type</th>
            <th align="center" width="120px">Resource Links</th>
            <th align="center">Due Date</th>
        </tr>
    </thead>
    <tbody>
        <!-- W10D01
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="5" align="center">W10D01<br/>- or -<br/>02/12/24</td>
            <td rowspan="2" align="center"><a href="https://generalassembly.zoom.us/rec/share/FaTjGhjRPFgwaEISjBlUC_3FgEaxjfA3r_Skgxh29qm0u0A62bGlWtYu9Cd_3g.Lbs8BaKwPAx0MTKT?startTime=1707752072000">Morning</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=js&type=&sort=">JS</a></td>
            <td>Mutability vs. Immutability</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/JS-Fundamentals/blob/main/Lessons/13.%20Immutability%20vs%20Mutability.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="4"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=react&type=&sort=">React</a></td>
            <td>Single Page Applications</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/React-Fundamentals/blob/main/Lessons/1.%20Single%20Page%20Applications.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="3" align="center"><a href="https://generalassembly.zoom.us/rec/share/4nFexvuISQNMGdaYnHyadArMrOXnX71dS6Tbf8ejaoCRN6Sb2f1_PwVrPj1ZBH0B.OrBD2854f0a5lvR3?startTime=1707766488000">Afternoon</a></td>
            <td>Building a Hobby SPA</td>
            <td>Lab</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/React-Fundamentals/blob/main/Exercises/Hobby%20SPA.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Intro to React</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/React-Fundamentals/blob/main/Lessons/2.%20Intro%20to%20React.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Knitter's Nook</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%204/1.%20Knitters%20Nook">GitHub</a></td>
            <td>02/13</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W10D02
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="7" align="center">W10D02<br/>- or -<br/>02/13/24</td>
            <td rowspan="4" align="center"><a href="https://generalassembly.zoom.us/rec/share/OCJw8lRUzeFL7ItbY9NYH3_taD3OhFrjfpsFnfukGOgw_rCSWTijl8gDfQxqh3nc.MPr-wVJAUI_Zo60j?startTime=1707833338000">Morning</a></td>
            <td rowspan="7"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=react&type=&sort=">React</a></td>
            <td>Knitter's Nook</td>
            <td>Presentations</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%204/1.%20Knitters%20Nook">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Setting Up TailwindCSS with Vite</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/React-Fundamentals/blob/main/Lessons/0.%20Tailwind%20%26%20Vite.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Hooks</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/React-Fundamentals/blob/main/Lessons/3.%20Hooks.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Aesthetic Domain Part 1</td>
            <td>Exercise</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Aesthetic-Domain/blob/main/Part%201.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="3" align="center"><a href="https://generalassembly.zoom.us/rec/share/Gc8gO2A1IRUFL6a9l09o9q-OOO6lRj07GB2i4QEoje5p8nn52ndfCuj_ARMGjs3Y.E0vJnwlthaBH2qpx?startTime=1707847412000">Afternoon</a></td>
            <td>Aesthetic Domain Part 1 cont.</td>
            <td>Exercise</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Aesthetic-Domain/blob/main/Part%201.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Intro to Props</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/React-Fundamentals/blob/main/Lessons/4.%20Intro%20to%20Props.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>React Likes</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%204/2.%20React%20Likes">GitHub</a></td>
            <td>02/14</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W10D03
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="4" align="center">W10D03<br/>- or -<br/>02/14/24</td>
            <td rowspan="2" align="center"><a href="https://generalassembly.zoom.us/rec/share/BXP3JcZX5MxqT3eBEFJjWGUDoCnjynF6779luHsTUNKMKYa07RTH_FRF-6PUWY73.HML5jUzl7q1eElFe?startTime=1707920033000">Morning</a></td>
            <td rowspan="4"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=react&type=&sort=">React</a></td>
            <td>Aesthetic Domain Part 2</td>
            <td>Exercise</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Aesthetic-Domain/blob/main/Part%202.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>React Giphy Searcher Part 1</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%204/3.%20Giphy%20Searcher">GitHub</a></td>
            <td>02/20</td>
        </tr>
        <tr>
            <td rowspan="2" align="center"><a href="https://generalassembly.zoom.us/rec/share/KEkzjtxVrcQ1eUtyQ73ROKENB5OieOLtYEOmu1BCTe9jeQxDVqjjUTqZl_hr2Z68.NTWF4scuWyuBbnRq?startTime=1707934218000">Afternoon</a></td>
            <td>Aesthetic Domain Part 3</td>
            <td>Exercise</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Aesthetic-Domain/blob/main/Part%203.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>React Giphy Searcher Part 1</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%204/3.%20Giphy%20Searcher#deliverable-part-1">GitHub</a></td>
            <td>02/20</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W10D04
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="5" align="center">W10D04<br/>- or -<br/>02/15/24</td>
            <td rowspan="3" align="center"><a href="https://generalassembly.zoom.us/rec/share/TTBg6xROP9ixlu9mz0lMtFnweqbQP1W7zWBtQzr5ksEC9xQpgiMuB-03MV3T4qLu.Yg-hDPN19YjZHOsV">Morning</a></td>
            <td rowspan="5"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=react&type=&sort=">React</a></td>
            <td>Lifting State & Prop Drilling</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/React-Fundamentals/blob/main/Lessons/5.%20Lifting%20State.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Aesthetic Domain Part 4</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Aesthetic-Domain/blob/main/Part%204.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>React Router</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/React-Fundamentals/blob/main/Lessons/6.%20React%20Router.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="2" align="center"><a href="https://generalassembly.zoom.us/rec/share/tvuC15iTBLeIRp26Han4RoEL1nxamrh4CLTqf0i4b0ve960OInD65ocY7JwOoUIL.DlNURGSz6fMi-_hc">Afternoon</a></td>
            <td>Aesthetic Domain Part 5</td>
            <td>Exercise</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Aesthetic-Domain/blob/main/Part%205.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>React Giphy Searcher Part 2</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%204/3.%20Giphy%20Searcher#deliverable-part-2">GitHub</a></td>
            <td>02/20</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W10D05
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="6" align="center">W10D05<br/>- or -<br/>02/16/24</td>
            <td rowspan="3" align="center"><a href="https://generalassembly.zoom.us/rec/share/3zzu8sWD5MKNF1Eg3yv7iOKlfjzvIlkzw80PLw8mClb3fB-YrSuSLDNszCUXKmyE.nGviB2hP8y4WIafx">Morning</a></td>
            <td rowspan="3"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=react&type=&sort=">React</a></td>
            <td>Controlled Forms</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/React-Fundamentals/blob/main/Lessons/7.%20Controlled%20Forms.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Aesthetic Domain Part 6</td>
            <td>Exercise</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Aesthetic-Domain/blob/main/Part%206.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>React Giphy Searcher Part 3</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%204/3.%20Giphy%20Searcher#deliverable-part-3">GitHub</a></td>
            <td>02/20</td>
        </tr>
        <tr>
            <td rowspan="3" align="center"><a href="https://generalassembly.zoom.us/rec/share/5SSrRVBg_hvZ0dNNVln6WJ4Oi7dQiukR4-DOTE7_4w5Y1Bi0z0eVrf4y0-VzYyVZ.dMXBcjg9Htq7I6eP?startTime=1708107245000">Afternoon</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=react&type=&sort=">MERN</a></td>
            <td>MERN Stack Project Structure</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/MERN-Stack-Fundamentals/blob/main/Lessons/1.%20Project%20Structure.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=react&type=&sort=">React</a></td>
            <td>Aesthetic Domain Part 7</td>
            <td>Exercise</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Aesthetic-Domain/blob/main/Part%207.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>React Giphy Searcher Part 3</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%204/3.%20Giphy%20Searcher#deliverable-part-3">GitHub</a></td>
            <td>02/20</td>
        </tr>
    <tbody>
</table>

<table>
    <thead>
        <tr>
            <th colspan="7" align="center">
                <h3>Week 11</h3>
                <hr/>
                <h4>React | MERN | TailwindCSS</h4>
            </th>
        </tr>
        <tr>
            <th align="center">Day</th>
            <th align="center" width="40px">Zoom Recording</th>
            <th align="center">Topic(s)</th>
            <th align="center" width="240px">Resource Name</th>
            <th align="center" width="140px">Resource Type</th>
            <th align="center" width="120px">Resource Links</th>
            <th align="center">Due Date</th>
        </tr>
    </thead>
    <tbody>
        <!-- W11D02
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="4" align="center">W11D02<br/>- or -<br/>02/20/24</td>
            <td rowspan="3" align="center"><a href="https://generalassembly.zoom.us/rec/share/mmNwXAmEiM1JpX4bNSh2aYKvXZta1j0wRe0rSCqf3yiT8faRSGkuyMoWY2rFih39.xzDmRlqwSnDzB1vu?startTime=1708440433000">Morning</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=react&type=&sort=">React</a></td>
            <td>Giphy Searcher Presentations</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Aesthetic-Domain/blob/main/Part%208.md">GitHub</a></td>
            <td>02/20</td>
        </tr>
        <tr>
            <td rowspan="3"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=mern&type=&sort=">MERN</a></td>
            <td>Aesthetic Domain Part 8</td>
            <td>Exercise</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Aesthetic-Domain/blob/main/Part%208.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>MERN World Explorer</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%204/4.%20MERN%20World%20Explorer">GitHub</a></td>
            <td>02/23</td>
        </tr>
        <tr>
            <td align="center">Afternoon</td>
            <td>MERN World Explorer</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%204/4.%20MERN%20World%20Explorer">GitHub</a></td>
            <td>02/23</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W11D03
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="4" align="center">W11D03<br/>- or -<br/>02/21/24</td>
            <td align="center">Morning</td>
            <td rowspan="4"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=mern&type=&sort=">MERN</a></td>
            <td>MERN World Explorer</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%204/4.%20MERN%20World%20Explorer">GitHub</a></td>
            <td>02/23</td>
        </tr>
        <tr>
            <td rowspan="3" align="center"><a href="https://generalassembly.zoom.us/rec/share/hzWjTcGzSxaqXvdCiL04ElI6uY59EptWor8pZFTAJbtHDvHjmqUHx-O3Rkxsg3AR.WgrNKpiL4F9bulCi?startTime=1708538547000">Afternoon</a></td>
            <td>Intro to JWTs</td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/MERN-Stack-Fundamentals/blob/main/Lessons/2.%20Intro%20to%20JWTs.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>
                Auth with JWTs 
                <br/>
                (<a href="https://git.generalassemb.ly/SEBR-Tardigrade/Aesthetic-Domain/blob/main/Part%209.md">Aesthetic Domain Part 9</a>)
            </td>
            <td>Live Lesson</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/MERN-Stack-Fundamentals/blob/main/Lessons/3.%20Implementing%20Auth%20with%20JWTs.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>MERN World Explorer</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%204/4.%20MERN%20World%20Explorer">GitHub</a></td>
            <td>02/23</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W11D04
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="3" align="center">W11D04<br/>- or -<br/>02/22/24</td>
            <td align="center">Morning</td>
            <td rowspan="3"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=mern&type=&sort=">MERN</a></td>
            <td>MERN World Explorer</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%204/4.%20MERN%20World%20Explorer">GitHub</a></td>
            <td>02/23</td>
        </tr>
        <tr>
            <td rowspan="2" align="center"><a href="https://generalassembly.zoom.us/rec/share/6nTVxPMDPRokxQ_nKWLeZ5DCROGrci6iXsMv8Ts7FsIIVwfh4Y9YyCZOJzLvy5wg.x3h_I4vx1U1Yxvhn?startTime=1708632177000">Afternoon</a></td>
            <td>Aesthetic Domain Part 10</td>
            <td>Exercise</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Aesthetic-Domain/blob/main/Part%2010.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>MERN World Explorer</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%204/4.%20MERN%20World%20Explorer">GitHub</a></td>
            <td>02/23</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
        <!-- W11D05
        ------------------------------------------------------------------- -->
        <tr>
            <td rowspan="3" align="center">W11D05<br/>- or -<br/>02/23/24</td>
            <td rowspan="3" align="center"><a href="#">Morning</a></td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=mern&type=&sort=">MERN</a></td>
            <td>MERN World Explorer Presentations</td>
            <td>Deliverable</td>
            <td><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Deliverables/tree/main/Unit%204/4.%20MERN%20World%20Explorer">GitHub</a></td>
            <td>02/23</td>
        </tr>
        <tr>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade?q=course-info&type=&sort=">Course Info</a></td>
            <td>Capstone Project Intro</td>
            <td rowspan="2">Unit Project</td>
            <td rowspan="2"><a href="https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/blob/main/Unit%204/README.md">GitHub</a></td>
            <td align="center">-</td>
        </tr>
        <tr>
            <td>Proposal Review & Approval</td>
            <td>02/23</td>
        </tr>
        <!-- -------------------------------------------------------------- -->
    </tbody>
</table>
</details>
# Pokemon TCG - Python OOP
<img src="https://i.imgur.com/avaERb6.jpg" width="100%" />


## Introduction
Nintendo was pleased with your pokedexes from last unit! They now commissioned you again and placed you in a team of developers to build the very first CLI-based Pokemon trading card game (TCG).

Using your knowledge of Python classes, functions, containers, and control flow you will be paired with 2-3 other developers and build Pokemon TCG in the terminal.

For the rest of the day and tomorrow your team will build out Pokemon TCG. 1 hour before class ends on **Thursday**, submit your game as a pull request on this repo. You'll then have 15 minutes to plan out your presentations.


## The Game Concept
You are going to create a simple card game in which a player will be able to battle the autoplayer. The game will deal 3 cards (each of which has a damage value) to the player and three cards to the autoplayer. The player will choose a card, and the computer will randomly choose a card, and whichever's card has the highest value will win the point. A round is finished once this has happened three times.


### Example Play
1. There are 18 Pokemon cards in the deck
1. Ash (the player) is dealt three random cards from the deck
1. The computer is dealt three random cards from the deck
1. Ash chooses a card and plays it! It has a damage of 10.
1. The computer randomly chooses a card and plays it! It has a damage of 8.
1. Ash wins!
1. The score is displayed:
    ```
    Score
    -----
    Ash: 1, Computer: 0

    Rounds Won
    ----------
    Ash: 0, Computer: 0
    ```
1. They do this again two more times. The round ends.
1. The score is displayed. The rounds won are displayed.


## Working as a Team
### Planning
- Choose an animal mascot (fictional or non) for your group and name your team after it.
    - Examples: Team Velociraptor, Team Unicorn
- Determine each team member's role
    - For a team of 3 these are the possible roles:
        1. **Team Member 1:** Responsible for creating the `Card` class and leading the development of the UI. They will work in the `card_class` file and other files where the UI is built.
        1. **Team Member 2:** Responsible for creating the `Game` class. They will work in the `game_class.py` file.
        1. **Team Member 3:** Responsible for creating the `Player` class They will work in the `player_class.py` file.
    - For a team of 4 these are the possible roles:
        1. **Team Member 1:** Responsible for leading the development of the `Card` class and assisting in the development of the UI. They will work in the `card_class.py` file and other files where the UI is built.
        1. **Team Member 2:** Responsible for leading the development of the `Game` class. They will work in the `game_class.py` file.
        1. **Team Member 3:** Responsible for leading the development of the `Player` class. They will work in the `player_class.py` file.
        1. **Team Member 4:** Responsible for leading the development of the UI and assiting other team members with their responsibilities. This team meber will be working in all the game files as needed.
- Together, wireframe out the game play using a flow chart or by creating a simple list of actions in a `txt` file. This wireframe will be submitted with the finished game.

### Development
- Team Member 1 will fork and clone this repo
- Team Member 1 will and open up the `game` directory inside the cloned repo and start a [Live Share](https://learn.microsoft.com/en-us/visualstudio/liveshare/use/install-live-share-visual-studio-code) collaboration session.
- Each team member will work in their designated files (with team members 1 working in multiple files with other team members).
- Work together and communicate frequently, especially since your Classes will have methods that need to look at the properties of objects instantiated from other Classes.
- After your Classes are built, execute the game logic in the `app.py` file

### Submission
- Team Member 1 will submit the finished game and wireframe when specified by your instructor (i.e. the end of class, the beginning of class the next day).
- Make a pull request titled **Team [Your Group Mascot]** to submit your work. 
- Make sure your work (wireframe and code) is presentation ready!


### Presention
- Your team's presentation will take ***10 minutes***. An instructor will give you a 1 minute warning.
- Make sure each team member has a chance to talk about what they worked on and how they implemented certain features.
- Plan out what you would like to showcase about your code and/or UI.



## MVP Requirements
For each class, think about:
- What's the best data type for this property? Number? String? Array? object? boolean? Some crazy combination of these?
    - **Hint**: use a property when you want to "keep track" of something
- Or should you create a method?
    - **Hint**: use a method when you want to "do" something


### The `Game` Class
Instantiate the `Game` class. You can use various methods of the instantiated game to execute different game play logic.

It should be able to:
- keep a library of all the Pokemon cards that can be played (see the `starter_data` list in the `app.ipynb` file)
- know what cards have been played
- know how many cards are left to be played/dealt overall (Include a graveyard for played cards)
- track points for both the player and the computer 
    - Points are determined by the following: 
        - If the player's card beats the computer's card, the player gets one point (and vice versa). 
        - If there is a tie, no one gets a point.
- track rounds
- track number of rounds won for both player and computer
- automatically deal 3 cards from the library to the player and 3 cards to the computer each round
- determine the winner of each play
- stop once there are no cards left or not enough to deal 3 to each the player and computer


### The `Player` Class
- see their stats: their points and how many rounds they've won.
- see what cards they have been dealt/see what cards are left in their hand
- pick a card from the hand that has been dealt to them (thereby playing this card agaist the computer's card). The round ends once this has happened 3 times.
- receive new cards given to them by the game each round.
- see the cards that they have played throughout the game.


### The `Card` Class
Using the starter data, instantiate 18 card objects from the `Card` class. Each playing card will:
- be able to attack and "destroy" another card
- have a name for quick reference, such as when a player is looking at the past cards they've played.
- have a visual representation when the card is in the player's hand and on the playing field. Here's an example of what the visual representation could look like:
    ```
    ┌─────────────┐
    │             │
    │             │
    │  Bulbasaur  │
    │             │
    │    60 DMG   │
    │             │
    │             │
    └─────────────┘
    ```


### The UI (Terminal Input and Output)
The Terminal should display:
- the scoreboard after each round
- the cards in the player's hand
- the cards in the computer's hand
- the cards that are in play
- the winner of each round (or if there was a tie)
- the winner of the game when the game is over
- the final score when the game is over

The Terminal will prompt the user for the following:
- starting a game
- selecting a card
- advancing to the next round
- if they want to see the past cards they've played


## Bonus
- Keep tracker of a player's stats (wins and losses) of each **game** they've played.
    - **Hint:** think of some way to store data between games, perhaps a JSON file?
- Make your UI even fancier! Think about how you can dynamically create card visualizations, make a gamebaord, etc.
    - Look into the [`pyfiglet` package](https://pypi.org/project/pyfiglet/0.7/) to print ASCII text to the CLI.
    - How could you print to the CLI using custom colors?
- Edit the gameplay logic so that the player and the computer each lay down 3 cards at a time, and take turns attacking.
    - On their turn, the player will choose which of their cards attacks, and also which of the computer's cards will be attacked
    - On its turn, the computer will randomly choose which its cards attacks, and also which of the player's cards will be attacked
    - Whoever destroys all the other player's cards will win that round


## Licensing
1. All content is licensed under a CC­BY­NC­SA 4.0 license.
2. All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.

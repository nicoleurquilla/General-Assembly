# Import the `os` package to allow for terminal clearing
import os

# Import the classes from the other files
from card_class import Card
from game_class import Game
from player_class import Player


# Clear the terminal at the start of a game (you can also use this at different points in the game play)
os.system('clear')

// Define the required variables
let board = [
    ['', '', ''],
    ['', '', ''],
    ['', '', '']
]; // Represents the state of the squares on the board

let turn; // Tracks whose turn it is
let winner; // Represents if anyone has won yet
let tie; // Represents if the game has ended in a tie

// Define constant squareEls to store the square elements
const squareEls = document.querySelectorAll('.sqr');

// Define constant messageEl to store the message element
const messageEl = document.getElementById('message');

// Console log to ensure correct element references
console.log(squareEls);
console.log(messageEl);

// Define the init function to initialize the game state
function init() {
    // Set the board variable to a 2-dimensional array representing the board
    board = [
        ['', '', ''],
        ['', '', ''],
        ['', '', '']
    ];

    // Set the turn to X - representing player X
    turn = 'X';

    // Set the winner to null
    winner = null;

    // Set tie to false
    tie = false;

    // Console log as a confirmation check
    console.log('Game initialized.');

    // Call the render function
    render();
}

// Call the init function when the app loads
window.onload = function() {
    init();
};

// Define the render function to render the game state to the user
function render() {
    updateBoard();
    updateMessage();
}

// Define the updateBoard function to update the visual representation of the board
function updateBoard() {
    board.forEach((row, i) => {
        row.forEach((cell, j) => {
            squareEls[i * 3 + j].textContent = cell; // Set the text content of each square to the corresponding value in the board array
        });
    });
}

// Define the updateMessage function to update the message displayed to the user based on the game state
function updateMessage() {
    if (!winner && !tie) {
        // If there is no winner and no tie, display whose turn it is
        if (turn === 'X') {
            messageEl.textContent = `Player one's turn!`; // Player one's turn
        } else {
            messageEl.textContent = `Player two's turn!`; // Player two's turn
        }
    } else if (!winner && tie) {
        // If it's a tie, display tie message
        messageEl.textContent = `It's a tie!`; // Tie message
    } else {
        // If there is a winner, display the winning player
        if (winner === 'X') {
            messageEl.textContent = `Player one wins!`; // Player one wins
        } else {
            messageEl.textContent = `Player two wins!`; // Player two wins
        }
    }
}

// Define the required constants
const winningCombos = [
    [0, 1, 2], // Top row
    [3, 4, 5], // Middle row
    [6, 7, 8], // Bottom row
    [0, 3, 6], // Left column
    [1, 4, 7], // Middle column
    [2, 5, 8], // Right column
    [0, 4, 8], // Diagonal from top-left to bottom-right
    [2, 4, 6]  // Diagonal from top-right to bottom-left
];

// Create a function named placePiece that accepts an index parameter
function placePiece(index) {
    // Calculate the row and column from the index
    const row = Math.floor(index / 3);
    const col = index % 3;
    // Update the board array at the row and column with the current player's symbol
    board[row][col] = turn;
}

// Create a function named checkForWinner
function checkForWinner() {
    // Loop through each winning combination
    for (let combo of winningCombos) {
        // Destructure the winning combination
        const [a, b, c] = combo;
        // Calculate the row and column for each cell in the combo
        const rowA = Math.floor(a / 3);
        const colA = a % 3;
        const rowB = Math.floor(b / 3);
        const colB = b % 3;
        const rowC = Math.floor(c / 3);
        const colC = c % 3;
        // Check if there is a winner based on the current board state
        if (board[rowA][colA] !== '' && board[rowA][colA] === board[rowB][colB] && board[rowA][colA] === board[rowC][colC]) {
            // If a player has won, set winner to the current player
            winner = turn;
            return;
        }
    }
}

// Create a function named checkForTie
function checkForTie() {
    // Check if there is a winner
    if (winner) {
        return;
    }
    // Check if there are any empty squares left on the board
    tie = board.every(row => row.every(cell => cell !== ''));
}

// Create a function called switchPlayerTurn
function switchPlayerTurn() {
    // If there is no winner, switch the turn
    if (!winner) {
        turn = turn === 'X' ? 'O' : 'X';
    }
}

// Define handleClick function to handle player clicks on squares
function handleClick(event) {
    // Get the index of the clicked square
    const index = Array.from(squareEls).indexOf(event.target);
    // If the clicked square is empty and there is no winner
    if (board[Math.floor(index / 3)][index % 3] === '' && !winner) {
        // Place the current player's piece
        placePiece(index);
        // Check for winner
        checkForWinner();
        // Check for tie
        checkForTie();
        // Switch player turn
        switchPlayerTurn();
        // Render the updated game state
        render();
    }
}

// Attach event listener to each square element
squareEls.forEach(square => {
    square.addEventListener('click', handleClick);
});

// Get the reset button element
const resetBtnEl = document.getElementById('reset');

// Attach event listener to reset button
resetBtnEl.addEventListener('click', init);

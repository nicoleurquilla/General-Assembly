/*
Exercise 1: maxOfTwoNumbers()

In this exercise, create a function named maxOfTwoNumbers. It should take two numbers as inputs and return the larger number. If they're equal, return either one.

Exercise 1 has been completed for you:
*/

const maxOfTwoNumbers = (x, y) => {
    if (x >= y) {
      return x;
    } else {
      return y;
    }
  }
  
  console.log(maxOfTwoNumbers(10, 11));
  
  /*
Exercise 2: isAdult()

Write a function named isAdult. It should take an age (number) and return 'Adult' if the age is 18 or over and 'Minor' otherwise.

Example: isAdult(21) should return 'Adult'.

Complete the exercise in the space below:
*/
let isAdult = 21

if (isAdult >= 18)
 {
    console.log('Adult')
} else {
    console.log('Minor')
}

/*
Exercise 3: isCharAVowel()

Write a function named isCharAVowel that takes a single character as an argument. It should return true if the character is a vowel and false otherwise. For the purposes of this exercise, the character y should not be considered a vowel.

Example: isCharAVowel('a') should return true.

Complete the exercise in the space below:
*/

if (isCharAVowel = ("a", "e", "i", "o", "u")) {
  console.log("true")
  } else {
    console.log("false")
  }

  isCharAVowel = ("i")


  /*
Exercise 4: generateEmail()

Create a function named generateEmail. It should take two strings: a name and a domain. It should return a simple email address.

Example: generateEmail('johnsmith', 'example.com') should return 'johnsmith@example.com'.

Complete the exercise in the space below:
*/

function generateEmail(name, domain) {
  return name + "@" + domain;
}

console.log(generateEmail('johnsmith', 'example.com'));

  /*
Exercise 5: greetUser()

Define a function called greetUser. It should take a name and a time of day (morning, afternoon, evening) and return a personalized greeting.

Example: greetUser('Sam', 'morning') should return "Good morning, Sam!"

Complete the exercise in the space below:
const greetUser = function (greet, user) {

let greet = 'morning'
let user = 'Sam'

console.log("Good 'greet', 'user'!")
}

*/

let friendName = "Sam"
let greet = "morning"

const greetUser = () => {
    //function scope
    let message = "Good " + greet + ", " + friendName + "!";
    console.log(message);
}

greetUser();



/*
Exercise 6: reverseString()

Define a function called reverseString. It should take a string and return it with its characters in reverse order. 

Example: reverseString('rockstar') should return the string "ratskcor".

Complete the exercise in the space below:
*/

function reverseString(str) { 
  let strRev = ""; 
  for (let i = str.length - 1; i >= 0; i--) { 
      strRev += str[i]; 
  } 
  console.log(strRev); 
} 

reverseString("rockstar"); 


/*
Exercise 7: checkPalindrome()

Define a function called checkPalindrome. It should take a string and return true if the string is a palindrome (reads the same forwards and backwards) and false otherwise.

Example: checkPalindrome('radar') should return true.
Example: checkPalindrome('taco') should return false.

Complete the exercise in the space below:
*/

function checkPalindrome(str) {

  var len = str.length;
  var mid = Math.floor(len/2);

  for ( var i = 0; i < mid; i++ ) {
      if (str[i] !== str[len - 1 - i]) {
          return false;
      }
  }

  return true;
  console.log(radar)
}

console.log(checkPalindrome("taco"));
console.log(checkPalindrome("radar"));

/*
Exercise 8: maxOfThree()

Define a function, maxOfThree. It should accept three numbers and return the largest among them.

Example: maxOfThree(17, 4, 9) should return 17.

Complete the exercise in the space below:
*/
function maxOfThree(num1, num2, num3) {
  if (num1 >= num2 && num1 >= num3) {
      return num1;
  } else if (num2 >= num1 && num2 >= num3) {
      return num2;
  } else {
      return num3;
  }
}

console.log(maxOfThree(5, 10, 8));

/*
Exercise 9: calculateTip()

Create a function called calculateTip. It should take two arguments: the bill amount and the tip percentage (as a whole number). The function should return the amount of the tip.

Example: calculateTip(50, 20) should return 10.

Complete the exercise in the space below:
*/

function calculateTip(billAmount, tipPercentage) {
  //Convert tipPercentage from whole number to decimal
  const tip = (billAmount * tipPercentage) / 100;
  return tip;
}

const billAmount = 50;
const tipPercentage = 20;
const tipAmount = calculateTip(billAmount, tipPercentage);

console.log(tipAmount) ; // Output: 10

/*
Exercise 10: convertTemperature()

Write a function named convertTemperature. It takes two arguments: a temperature and a string representing the scale ('C' for Celsius, 'F' for Fahrenheit). Convert the temperature to the other scale.

Example: convertTemperature(32, 'C') should return 89.6 (Fahrenheit).
Example: convertTemperature(32, 'F') should return 0 (Celsius).

Complete the exercise in the space below:
*/

function convertTemperature(temperature, scale) {
  if (scale === 'C') {
    // Convert Celsius to Fahrenheit
    return (temperature * 9/5) + 32;
  } else if (scale === 'F') {
    // Convert Fahrenheit to Celsius
    return (temperature - 32) * 5/9;
  } else {
    return "Invalid scale. Please use 'C' for Celsius or 'F' for\n Fahrenheit.";
  }
}

console.log(convertTemperature(32, 'C'))
console.log(convertTemperature(32, 'F'))



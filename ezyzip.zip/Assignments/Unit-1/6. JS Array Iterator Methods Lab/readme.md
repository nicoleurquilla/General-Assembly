Please use [this](https://generalassembly.instructure.com/courses/246/assignments/2828) link to access the lab:

Setup has been completed already.

You have two methods at your disposal for executing the code we write in the script.js:

Open the index.html file in your browser and access the console output in your browser’s dev tools.
 
**or**

Use nodeJS to execute the script.js file directly by using this command in your terminal:
```
node script.js
```

Upon completion please commit your work

1. git add -A
2. git commit -m "add your message inside quotes"
3. git push

Then submit the URL link to the specific respoitory end point into in Canvas. There should be a text field at the bottom of the assignment requesting the URL. Click "submit" and you should be all set!
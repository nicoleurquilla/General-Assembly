Please use [this](https://generalassembly.instructure.com/courses/246/assignments/2824) link to access the lab:

Setup has been completed already.

Use nodeJS to execute the app.js file directly by using this command in your terminal:

```
node app.js
```

Info on [nodeJS](https://nodejs.org/en/learn/getting-started/introduction-to-nodejs) (which you will learn more about in unit2). For now just know you can run the app.js file using the above command in your terminal.

**FYI -> nodeJS is being used here because of the secondary javascript file being introduced that holds the data (array of pokemon objects) in the data.js file (take a look at it!). In order to access this information, nodeJS allows us to import/require access to the data in another module.**

Upon completion please commit your work

1. git add -A
2. git commit -m "add your message inside quotes"
3. git push

Then submit the URL link to the specific respoitory end point into in Canvas. There should be a text field at the bottom of the assignment requesting the URL. Click "submit" and you should be all set!
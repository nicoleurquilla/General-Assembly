let display = document.getElementById('display'); //this line finds the area on the webpage where we want to show our calculator's output, the number display
let firstOperand = ''; //lines 2-4 prepare storage spaces to hold the numbers and the operation we're going to perform
let operator = '';
let secondOperand = '';

//this function makes sure that when we press a number, it shows up on the display. If the display shows 'O' or an error, it replaces the content with the number. Otherwise, it adds the
//number to the existing display.
function appendToDisplay(value) {
  if (display.innerText === '0' || display.innerText === 'Error') {
    display.innerText = value;
  } else {
    display.innerText += value;
  }
}

//this function clears everything, resetting the calculator to its starting state.
function clearDisplay() {
  display.innerText = '0';
  firstOperand = '';
  operator = '';
  secondOperand = '';
}

//this function sets the operation to perform when we press an operator (+,-,x,/). It remembers the first number you've entered and the operation you've chosen.
function operate(op) {
  if (operator === '') {
    firstOperand = display.innerText;
    operator = op;
    display.innerText = '';
  }
}
/*This function does the math. It takes the numbers and operation you've chosen and calculates the result. Then it displays the result. 
If you try to divide by zero, it shows an error message instead. After showing the result, it prepares the calculator for the next calculation. */
function calculate() {
  if (operator === '' || display.innerText === 'Error') return;

  secondOperand = display.innerText;
  let result;
  switch (operator) {
    case '+':
      result = parseFloat(firstOperand) + parseFloat(secondOperand);
      break;
    case '-':
      result = parseFloat(firstOperand) - parseFloat(secondOperand);
      break;
    case '*':
      result = parseFloat(firstOperand) * parseFloat(secondOperand);
      break;
    case '/':
      if (parseFloat(secondOperand) === 0) {
        result = 'Error';
      } else {
        result = parseFloat(firstOperand) / parseFloat(secondOperand);
      }
      break;
    default:
      break;
  }
  display.innerText = result;
  firstOperand = '';
  operator = '';
}

Please use [this](https://generalassembly.instructure.com/courses/246/assignments/2827) link to access the lab:

Setup has been completed already.

Upon opening the app you will need to initialize nodeJS. Pleasedo so with the following command, in your terminal, in the **4. CRUD App Lab** directory.

```
npm init
```

**During node initialization, you will be prompted to customize your project and the package.json file. Accept the defaults (by just hitting Return/Enter for each prompt without adding any values).

Upon completion of the lab please commit your work:

1. git add -A
2. git commit -m "add your message inside quotes"
3. git push

Then submit the URL link to the specific respoitory end point into in Canvas. There should be a text field at the bottom of the assignment requesting the URL. Click "submit" and you should be all set!
Please use [this](https://generalassembly.instructure.com/courses/246/assignments/2827) link to access the lab:

Setup has been completed already.

Upon opening the app you will need to initialize nodeJS and install the **expressJS** package.

Please run the following commands (in order), in your terminal, in the **1. Intro to Express Lab** directory.
```
1. npm init -y
2. npm i express
```

Then complete the lab! : )

Upon completion please commit your work:

1. git add -A
2. git commit -m "add your message inside quotes"
3. git push

Then submit the URL link to the specific respoitory end point into in Canvas. There should be a text field at the bottom of the assignment requesting the URL. Click "submit" and you should be all set!
Please use [this](https://generalassembly.instructure.com/courses/246/assignments/2827) link to access the lab.



- Setup: 

1. Install node / packages with: ```npm i```

2. Create your **.env** file in the root of your **5. Cookbook App Lab** folder.

3. Add these items to your .env:
```
MONGODB_URI=
SESSION_SECRET=
```



- Part 1: lab requires completing session auth setup (user sign up and login).
    - Use either "Path 1" or "Path 2". (both paths are the same up until the ["Build the Index Route"](https://pages.git.generalassemb.ly/modular-curriculum-all-courses/men-stack-relating-data-lab-cookbook/exercise-embedding-related-data/#build-the-index-route) heading) and stop at the heading to complete part 1.

- Part 2: Will follow Path 1 from the ["Build the Index Route"](https://pages.git.generalassemb.ly/modular-curriculum-all-courses/men-stack-relating-data-lab-cookbook/exercise-embedding-related-data/#build-the-index-route) heading and is complete at the end of that path.

- Part 3: Will follow Path 2 from the ["Build the Index Route"](https://pages.git.generalassemb.ly/modular-curriculum-all-courses/men-stack-relating-data-lab-cookbook/exercise-embedding-related-data/#build-the-index-route) heading and is complete at the end of that path.


3 - As you hit milestones / have code working, don't forget to commit and push your work!

```
1. git add -A
2. git commit -m "add your message inside quotes"
3. git push
```

4 - Upon completion please submit the URL link to the specific respoitory end point into in Canvas. There should be a text field at the bottom of the assignment requesting the URL. Click "submit" and you should be all set!

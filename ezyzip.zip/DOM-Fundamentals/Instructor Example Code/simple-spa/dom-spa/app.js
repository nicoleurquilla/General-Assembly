// Grab buttons inside the nav bar
const btns = document.querySelectorAll('nav button')
// grab all section elements
const sections = document.querySelectorAll('section')


// Add event listener to each button that will display the corresponding section
for (let btn of btns) {
    btn.addEventListener('click', (event) => {
        // Looping over all sections and hiding them
        for (let section of sections) {
            section.style.display = 'none'

            // display the section that corresponds to the button that was clicked
            if (event.target.innerText.toLowerCase() === section.id) {
                section.style.display = 'flex'
            }
        }
    })
}
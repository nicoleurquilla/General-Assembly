/* Accessing HTML elements
---------------------------------------------------------------------- */
// Grabbing About the Game button
const openBtn = document.getElementById('open-modal');
// Grabbing modal element
const modal = document.getElementById('modal')
// Grabbing close button
const closeBtn = document.getElementById('close')


/* Creating event listeners
---------------------------------------------------------------------- */
// Create a nanmed function to open to change modal display to 'block'. This function will be used in multiple places.
const openModal = () => modal.style.display = 'block';

// Call the openModal function when the "About the Game" btn is pressed
openBtn.addEventListener('click', openModal)

// Change modal display to 'none' when the "Close" element is pressed
closeBtn.addEventListener('click', () => modal.style.display = 'none')

// Automatically display the modal after 5 seconds
setTimeout(openModal, 5000);

# Interactive Menu
<img src="https://i.imgur.com/PHlbGUa.jpg" width="100%">


## Getting Started
This lab is ***NOT*** a deliverable, but is great practice working with the DOM! You'll also get practice with CSS Variables and a sneak peak at CSS Transitions, which is a concept we'll cover more in depth tomorrow.
1. On your computer, create a folder called `DOM Interactive Menu`
1. In the folder you created above, make an `index.html` file, a `style.css` file, and a `script.js` file
1. Start with [Part 1](./Part%201.md), and when you're done, move on to [Part 2](./Part%202.md)

Note that each part has a link to a solution, which you can use if you get stuck. Give it your best shot first before checking the solution!

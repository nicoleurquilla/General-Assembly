# DOM Fundamentals
<img src="https://i.imgur.com/6br24ru.png" width="100%" />


## What is the DOM?
The Document Object Model (DOM) is a programming interface for web documents. It represents the structure of an HTML as a tree-like structure, with each element, attribute, and text node represented as a node in the tree. The DOM provides a way to access and manipulate the content, structure, and style of a web page using JavaScript or other programming languages and respond to user interactions.

In simple terms, the DOM acts as a bridge between web documents and programming, enabling developers to interact with and modify the content of a web page programmatically.

The DOM is incredibly important and key skill for developers because it allows them to create dynamic and interactive web applications. By accessing and manipulating the DOM using JavaScript, developers can build applications that respond to user actions in real-time, update content dynamically, and create interactive user interfaces.


## Lessons
1. [Intro to the DOM](./Lessons/1.%20Intro%20to%20the%20DOM.md)
1. [DOM Events](./Lessons/2.%20DOM%20Events.md)
1. [Building a Simple Single-Page Site](./Lessons/3.%20Simple%20SPA.md)


## Exercises
1. [Modals](./Exercises/1.%20Modals.md)
1. [Carousels](./Exercises/2.%20Carousels.md)


## Cheatsheet
<img alt="DOM Cheatsheet" src="https://i.imgur.com/BJti28I.jpg" width="100%" />


## Licensing
1. All content is licensed under a CC­BY­NC­SA 4.0 license.
2. All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.

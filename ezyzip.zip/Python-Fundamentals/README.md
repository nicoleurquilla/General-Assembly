# Python Fundamentals
<img src="https://i.imgur.com/3eWYI69.jpg" width="100%" />


## What is Python?
Python is a versatile and beginner-friendly programming language known for its simplicity and readability. It was designed to emphasize code readability and ease of use, making it accessible to beginners and experienced programmers alike. It has a large standard library and a vast ecosystem of third-party libraries and frameworks that enable developers to build a wide range of applications. Python is widely used in web development, scientific computing, data analysis, artificial intelligence, automation, and more.

Python's versatility and ease of use make it an ideal choice for a variety of applications, from web development and scientific computing to automation and machine learning. Learning Python opens up numerous career opportunities and equips you with a valuable skillset in today's technology-driven world.


## Lessons
1. [Intro to Python](./Lessons/1.%20Intro%20to%20Python.md)
    - Group Exercise: [Translate JS to Python](./Exercises/1.%20JS%20to%20Python.md)
1. [Control Flow](./Lessons/2.%20Control%20Flow.md)
1. [Containers](./Lessons/3.%20Containers.md)
1. [Functions](./Lessons/4.%20Functions.md)
1. [Classes & OOP](./Lessons/5.%20Classes%20&%20OOP.md)
1. [Pip & Virtual Environments](./Lessons/6.%20Pip%20&%20Virtual%20Environments.md)


## Cheatsheets
- [General Python Cheatsheet (Codeacademy)](https://www.codecademy.com/learn/learn-python-3/modules/learn-python3-hello-world/cheatsheet)
- [General Python Cheatsheet (Devhints)](https://devhints.io/python)
- [General Python Cheatsheet (QuickRef)](https://quickref.me/python)


## Licensing
1. All content is licensed under a CC­BY­NC­SA 4.0 license.
1. All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.

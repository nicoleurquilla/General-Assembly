# React Likes
<img width="100%" src="https://i.imgur.com/VT8nzYu.png" />


## Background
The Facebook like button actually serves many purposes. It allows posters to feel validated, measure engagement, and allow other users to interact with posts. Addititionally, the like button is a significant power sharing tool, as more "likes" will make the post show up on friends' feeds, boosting the algorithm to ensure the post is seen and interacted with in order to continue the cycle of engagement. 

For this deliverable you'll create a simplified version of the like button. Your final product should function similarly to [this deployed version](https://react-likes.surge.sh/) of the component.


## Set Up
1. Open up this directory on your computer.
1. Scaffold a React app called `react-likes` using vite.
    - **NOTE:** This will create a new folder called `react-likes` and build the react app inside it.
1. `cd` into `react-likes`
1. Next, open the application in VS Code by typing `code .`
1. Back in the Terminal, type `npm i`, once everything installs run `npm run dev` to launch the development server



## Functionality Requirements
1. Create a components folder inside of the `src` directory.
2. Move the App component inside it's own folder in the `src/components` directory
3. Use the `useState` hook to add state called `totalLikes` to the App component to store the current number of likes.
4. Initialize the `totalLikes` state as `0`.
5. Create a new component called `Likes` in the `components` directory.
6. Add functionality to the `Likes` component so that when it renders it displays the number of `totalLikes`.
    - **HINT:** Use props to pass the value of `totalLikes` to the `Likes` component.
    - Create a commit that reads "Displaying total likes"
8. In your JSX, render two `button` elements, one that increments `totalLikes` and another that decrements `totalLikes`.
    - Create a commit message that reads "Added increment and decrement buttons"
9. Make it so that the `totalLikes` can never display a value less than `0`.
    - Make a final commit with a message that reads "Set floor on totalLikes".


## UI Requirements
1. The increment button must have a `+` as its text.
1. The decrement button must have a `-` as its text.
1. Render the `totalLikes` to the page in a `p` element.



## Helpful Resources
- [Passing Props to a Component](https://react.dev/learn/passing-props-to-a-component)
- [State Hook](https://react.dev/reference/react/useState#usestate)
- [Thinking in React](https://facebook.github.io/react/docs/thinking-in-react.html)
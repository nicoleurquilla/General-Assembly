# Carmen Sandiego
<img src="./carmen_banner.png" alt="Carmen Sandiego Banner" width="100%" />


## Where in the World is Carmen Sandiego?
We're going to use what we've learned already about searching with SQL commands, and apply it to chase down and capture an elusive and world-renowned thief, Carmen Sandiego. Follow the clues and use the documentation to figure out where Carmen is headed so we can catch her and bring her in.


## Requirements
- Write the SQL commands you used to answer the clues in the [`find_carmen.sql`](./find_carmen.sql) file. Make to sure to test your commands in the PSQL shell to ensure they work.
- From the terminal, create a new database called `carmen` and populate it using the `starter_code/world.sql` file:
```shell
# Enter PSQL shell
psql

# Create a database called carmen
CREATE DATABASE carmen;

# Connect to the carmen database and populate it
\c carmen
\i starter_code/world.sql
```
Then, use the clues below to create the appropriate SQL queries to help you find Carmen and then, tell us where she's heading!!


### The Clues
- **Clue #1:** We recently got word that someone fitting Carmen Sandiego's description has been traveling through Southern Europe. She's most likely traveling someplace where she won't be noticed, so find the least populated country in Southern Europe, and we'll start looking for her there.
- **Clue #2:** Now that we're here, we have insight that Carmen was seen attending language classes in this country's officially recognized language. Check our databases and find out what language is spoken in this country, so we can call in a translator to work with you.
- **Clue #3:** We have new news on the classes Carmen attended: our gumshoes tell us she's moved on to a different country, a country where people speak *only* the language she was learning. Find out which nearby country speaks nothing but that language.
- **Clue #4:** We're booking the first flight out: maybe we've actually got a chance to catch her this time. There are only two cities she could be flying to in the country. One is named the *same* as the country – that would be too obvious. We're following our gut on this one; find out what other city in that country she might be flying to.
- **Clue #5:** We're close! Our South American agent says she just got a taxi at the airport, and is headed towards the capital! Look up the country's capital, and get there pronto! Send us the name of where you're headed and we'll follow right behind you!
- **Clue #6:** Oh no, she pulled a switch: there are two cities with very similar names, but in totally different parts of the globe! She's headed to South America as we speak; go find a city whose name is *like* the one we were headed to, but doesn't end the same. Find out the city, and do another search for what country it's in. Hurry!
- **Clue #7:** She knows we're on to her: her taxi dropped her off at the international airport, and she beat us to the boarding gates. We have one chance to catch her, we just have to know where she's heading and beat her to the landing dock.

    Lucky for us, she's getting cocky. She left us a note, and I'm sure she thinks she's very clever, but if we can crack it, we can finally put her where she belongs – behind bars.

    > Our play date of late has been unusually fun –
    >
    > As an agent, I'll say, you've been a joy to outrun.
    >
    > And while the food here is great, and the people – so nice!
    >
    > I need a little more sunshine with my slice of life.
    >
    > So I'm off to add one to the population I find
    >
    > In a city of ninety-one thousand and now, eighty five.

- **Question 8:** Some of the entries have gotten a bit messed up. For example, the capital of Brazil is not `Brasï¿½lia`, rather, it is Brasília. Update this entry to the correct spelling. Record your update, in the `find_carmen.sql` file (below `I found Carmen`), and do a query for one row and copy paste it to show the update.

Update any other two entries that have gotten messed up.


## Additional Resources
- [PostgreSQL Tutorials](http://www.tutorialspoint.com/postgresql/)
- [PostgreSQL Official Documentation](http://www.postgresql.org/docs/)
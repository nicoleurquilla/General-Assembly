# NFL
<img src="./nfl_banner.png" alt="NFL Logo" width="100%" />


## Requirements
- Write the SQL commands you used to answer the clues in the [`nfl.sql`](./nfl.sql) file. Make to sure to test your commands in the PSQL shell to ensure they work.
- From the terminal, create a new database called `nfl` and populate it using the `starter_code/league.sql` file:
```shell
# Enter PSQL shell
psql

# Create a database called nfl
CREATE DATABASE nfl;

# Connect to the nfl database and populate it
\c nfl
\i starter_code/league.sql
```

**Extra Challenge**: Complete each part with a single SQL expression. For some queries, it will involve using joins or subqueries.


## Queries
Some queries may require more than one command (i.e. you may need to get information about a team before you can complete a query for players). Use the PSQL shell to ensure your commands are correct.

1.  List the names of all NFL teams
2.  List the stadium name and head coach of all NFC teams
3.  List the head coaches of the AFC South
4.  The total number of players in the NFL
5.  The team names and head coaches of the NFC North and AFC East
6.  The 50 players with the highest salaries
7.  The average salary of all NFL players
8.  The names and positions of players with a salary above 10_000_000
9.  The player with the highest salary in the NFL
10. The name and position of the first 100 players with the lowest salaries
11. The average salary for a DE in the nfl

### Joins & Subqueries
For the following queries you will need to query two tables at the same time. You may need to research commands using dot notation.

<details>
<summary><strong>Dot Notation Example</strong></summary>

> The names of all the players on the Buffalo Bills:   
```sql
SELECT players.name, teams.name
FROM players, teams
WHERE players.team_id=teams.id AND teams.name LIKE 'Buffalo Bills';
```
</details>
<br/>

13. The total salary of all players on the New York Giants
14. The player with the lowest salary on the Green Bay Packers
# PSQL Practice - Carmen Sandiego and NFL
<img src="./psql_banner.png" alt="PSQL Banner" width="100%" />


## Exercise 1: Carmen Sandiego
- **Objective:** This assignment will get you comfortable with queries. Start your SQL explorations here.
- **Instructions:** Follow the [README.md](./carmen/README.md) in the `carmen` folder and put your answers in `find_carmen.sql`.


## Exercise 2: NFL
- **Objective:**  This assignment will give you more practice with queries, and get you to deal with some more advanced parts of the SQL language. Start this after having completed Carmen Sandiego.
- **Instructions:** Follow the [README.md](./nfl/README.md) in the `nfl` folder and put your answers in the `nfl.sql` file.


## Licensing
1. All content is licensed under a CC­BY­NC­SA 4.0 license.
2. All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.

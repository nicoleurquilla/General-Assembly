# Python Containers & Function Practice
<img src="https://i.imgur.com/8c9ePzk.png" width="100%" />


## Setup
- `cd` into this folder of your cloned repo and code your answers in the `solutions.py` file
- Run the file by executing this command in the terminal:
  ```
  python3 solutions.py
  ```
  

## Part 1: Containers
### Exercise 1
- Create a list named `students` containing some student names (strings).
- Print out the second student's name.
- Print out the last student's name.


### Exercise 2
- Create a tuple named `foods` containing the same number of foods (strings) as there are names in the `students` list.
- Use a `for` loop to print out the string "[_food goes here_] is a good food".


### Exercise 3
- Using a `for` loop, print just the last two food strings from `foods`.

  > Hint:  Use the slice operator to select the last two foods


### Exercise 4
- Create a dictionary named `home_town` containing the keys of `city`, `state` and `population`.
- Print a string with this format:<br>"I was born in _city_, _state_ - population of _population_"


### Exercise 5
- Iterate over the _key: value_ pairs in `home_town` and print a string for each item, for example:<br>"city = Arcadia"<br>"state = California"<br>"population = 58000"


### Exercise 6
- Create an empty list named `cohort`.
- Using a `for` loop to iterate over the `students` list.
  > Hint: Use the `enumerate` function to provide both the index & student
- Within the `for` loop, add a dictionary to the `cohort` list that combines the student's name and the food in the `foods` list at the same index. Each dictionary will have this shape:
	```python
	{
	  'student': 'Tina',
	  'fav_food': 'Cheeseburger'
	}
	```
- Iterate over the `cohort` list, printing out each item (it's not necessary to format the dictionaries).


### Exercise 7
- Using the list of `students` and a list comprehension, assign to a variable named `awesome_students` a new list containing strings similar to this:<br>`["Tina is awesome!", "Fred is awesome!", "Wilma is awesome!"]`
- Iterate over the `awesome_students` list, printing out each string.


### Exercise 8
- Use a `for` loop to iterate over a list comprehension that filters the  `foods` tuple to only include food strings that contains the letter `a`.
- Within the `for` loop, print each food string.



## Part 2: Functions
> NOTE: To test your functions, be sure to call each function at least once and `print` the returned value.


### Exercise 9
- Write a function named `sum_to` that accepts a single integer, `n`, and returns the sum of the integers from 1 to `n`.
- For example:
	```python
	sum_to(6)  # returns 21
	sum_to(10) # returns 55
	```


### Exercise 10
- Write a function named `largest` that takes a list of numbers as an argument and returns the largest number in that list.
- For example:
	
	```python
	largest([1, 2, 3, 4, 0])  # returns 4
	largest([10, 4, 2, 231, 91, 54])  # returns 231
	```


### Exercise 11
- Write a function named `occurrences` that takes two string arguments as input and counts the number of occurrences of the second string inside the first string.
- For example:

	```python
	occurrences('fleep floop', 'e')   # returns 2
	occurrences('fleep floop', 'p')   # returns 2
	occurrences('fleep floop', 'ee')  # returns 1
	occurrences('fleep floop', 'fe')  # returns 0
	```

### Exercise 12
- Write a function named `product` that takes an *arbitrary* number of numbers, multiplies them all together, and returns the product.<br>(HINT: Review your notes on `*args`).
- For example:
	
	```python
	product(-1, 4) # returns -4
	product(2, 5, 5) # returns 50
	product(4, 0.5, 5) # returns 10.0
	```


### Exercise 13
- Write a function named `steps_to_zero` that accepts a non-negative integer as an argument, and returns the number of steps it took to reduce the integer to zero. If the current number is even, you have to divide it by 2, otherwise, you have to subtract 1 from it.
- For example:
	
	```python
	steps_to_zero(14) # returns 6
	```
	
	Explanation of above example:
	```
	Step 1) 14 is even; divide by 2 and obtain 7. 
	Step 2) 7 is odd; subtract 1 and obtain 6.
	Step 3) 6 is even; divide by 2 and obtain 3. 
	Step 4) 3 is odd; subtract 1 and obtain 2. 
	Step 5) 2 is even; divide by 2 and obtain 1. 
	Step 6) 1 is odd; subtract 1 and obtain 0.
	```


## Bonus: Working with Sets
1. Read through [this tutorial](https://realpython.com/python-sets/) on sets
1. Write a program that prompts the user to enter two lists of integers, and then creates two sets using those lists. 
1. The program should then perform the following operations on the sets and display the results:
    1. **Union:** Find the union of the two sets and print the resulting set.
    1. **Intersection:** Find the intersection of the two sets and print the resulting set.
    1. **Difference:** Find the difference between the two sets (elements that are in one set but not the other) and print the resulting set.
    1. **Subset:** Determine whether one of the sets is a subset of the other and print the result.

**Sample Input:**
```
Enter first list of integers: 1 2 3
Enter second list of integers: 2 3 4
```

**Sample Output:**
```
Union: {1, 2, 3, 4}
Intersection: {2, 3}
Difference: {1, 4}
Is the first set a subset of the second set? False
Is the second set a subset of the first set? False
```

**Starter Code:**
```py
# Prompt user to enter two lists of integers
list1 = input("Enter first list of integers: ").split()
list2 = input("Enter second list of integers: ").split()

# Convert lists to sets
# your code here...

# Perform set operations and display results
# your code here...
```
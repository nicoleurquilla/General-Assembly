# Python Control Flow Practice
<img src="https://i.imgur.com/yz2Syv9.png" width="100%"/>


## Setup and Instructions
1. If you have not yet pulled the Unit 3 deliverables from the classroom repository make sure to run this command:
    ```
    git pull upstream main
    ```
    Resolve any merge conflicts
1. `cd` into this folder of your cloned repo
1. Open the `app.py` file for the exercises that you will be working on.
1. Add your solution below each exercise's prompt.
1. After completing each exercise, you may comment out that exercise's code to ease completion of subsequent exercises.
1. Before submitting, uncomment ALL solutions.


## Licensing
1. All content is licensed under a CC­BY­NC­SA 4.0 license.
2. All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.

# GitPub
<img src="https://i.imgur.com/vM9hIQ4.png" width="100%">

In order to see how useful partials are and how exactly to use them, what we'll do is refactor code that doesn't use partials! You'll be able to see how partials help facilitate clean, organized code and allows developers to only look at pertinent information when reading a file.


## Set Up
- `cd` into this folder and run:
    ```
    npm i
    ```
    This will install all the node packages you need for this lab
- Run the `dev` script:
    ```
    npm run dev
    ```
- Look through the code and click through the GitPub pages - you'll notice there are several things that are or should be repeated throughout all pages of the app: 
    - The CSS & everything inside the HTML `<head>` 
    - The page header 
    - The page footer 


## Context
Now, consider the scenario where you want to make a change to the header. For example, let's say you want to add another link to the header navigation. Okay fine, all we have to do is add the link to the header on the `index.ejs`. 

But, wait, now go to the show page -- uh-oh. The link we just added is no longer there. Okay, fine, we'll just add the link on `show.ejs too`. But if we do that, what do you think will happen on the new page? The link won't be there, so we'd have to change it there too! 

Now pretend this is a large app with many different views that has the header on every single view - you'd have to make the change over and over again on every single view. That one simple change that should have only taken a few seconds took a much longer time. 

This is where partials come in super handy. They let you create reusable EJS that you only have to edit in _one place_ and it will update across all your pages where the partial is included.


## Your Tasks
You'll be creating partials for repetitive bits of code in the EJS of this application. Remeber to create a `partials` folder in the `views` directory to store all your partials!

### Step 1: Create the `<head>` Partial 
- Create an EJS partial to store all the code in the `<head>` tag of each page.
- Import the EJS partial into all the pages of the app:
    - `new.ejs`
    - `showDrinks.ejs` 
    - `showFood.ejs`

If you check each view in your browser, they should all now be styled! 


### Step 2: Creating the `<header>` Partial 
Alright, now let's clean up our files a bit so there's less repetition. We saw earlier that every single page has the `<header>`, so that's definitely a good candidate for a partial. Let's do the same thing we just did:
- Create an EJS partial to store all the code in the `<header>` tag of each page.
- Import the EJS partial into all the pages of the app:
    - `new.ejs`
    - `showDrinks.ejs` 
    - `showFood.ejs`


### Step 3: Creating the `<footer>` Partial 
You should be getting the hang of it now! Create and import a footer partial into all of your EJS pages


### Step 4: Add a Dynamic Tab Title
Review the [partials lesson](https://git.generalassemb.ly/SEBR-Tardigrade/Express-Fundamentals/blob/main/Lessons/5.%20EJS%20Partials.md) from earlier. How did we have a dynamic page title for all of our different pages?
- Pass data between your EJS files & routes into your partials to create a unique tab title for each page
- Make sure your food and drink pages all display the food or drink's name in the tab of your browser!

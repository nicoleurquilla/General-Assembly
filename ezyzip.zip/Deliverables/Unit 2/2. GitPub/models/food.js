const food = [
    {
        name: '(req, rEscargot)',
        price: 12,
        image: 'https://imgur.com/BRgv2rz'
    },
    {
        name: 'Nulltimate Nachos',
        price: 10,
        image: 'https://imgur.com/vKRbSHN'
    },
    {
        name: 'split() pea soup',
        price: 1,
        image: 'https://imgur.com/qd9jheG'
    },
    {
        name: 'CURLy Fries',
        price: 11,
        image: 'https://imgur.com/lEQ1AdY'
    },
    {
        name: 'Garlic NaN',
        price: 202,
        image: 'https://imgur.com/UEx7cYk'
    },
    {
        name: 'Baby Got BackEnd Ribs',
        price: 2,
        image: 'https://imgur.com/XbRMQ3g'
    },
    {
        name: 'Git Pull Pork Sandwich',
        price: 43,
        image: 'https://imgur.com/QZW3gJg'
    }
]

module.exports = food
/* Require modules
--------------------------------------------------------------- */
const path = require('path');
const express = require('express');
const livereload = require('livereload');
const connectLiveReload = require('connect-livereload');


/* Create the Express app
--------------------------------------------------------------- */
const app = express();


/* Import the data from the models folder
--------------------------------------------------------------- */
const drinks = require('./models/drinks')
const food = require('./models/food')


/* Configure the app (app.set)
--------------------------------------------------------------- */
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


/* Middleware (app.use)
--------------------------------------------------------------- */
// A function that will refresh the browser when nodemon restarts
const liveReloadServer = livereload.createServer();
liveReloadServer.server.once('connection', () => {
    // wait for nodemon to fully restart before refreshing the page
    setTimeout(() => {
        liveReloadServer.refresh('/');
    }, 100);
});

// Tell Express what middleware functions to run
app.use(express.static('public'))
app.use(connectLiveReload())


/* Mount routes
--------------------------------------------------------------- */
// Redirect the user to the "pub" page
app.get('/', (req, res) => {
    res.redirect('/pub')
})

// Display all food and drinks
app.get('/pub', (req, res) => {
    // Drinks: loop through each drink in the database in order to properly capitalize them all
    for (let drink of drinks) {
        // split name into every separate word
        let splitName = drink.name.split(' ')
        // loop through each individual word
        for (let i = 0; i < splitName.length; i++) {
            // split the word into its individual letters
            let splitWord = splitName[i].split('')
            // uppercase the first letter
            splitWord[0] = splitWord[0].toUpperCase()
            // rejoin the word
            splitName[i] = splitWord.join('')
        }
        // rejoin the words
        drink.name = splitName.join(' ')
    }

    // Render the data on the home page 
    res.render('home', {
        drinks: drinks,
        food: food,
        tabTitle: 'Main Branch'
    })
})

// Display an individual drink
app.get('/drinks/:id', (req, res) => {
    res.render('showDrinks', {
        drink: drinks[req.params.id]
    })
})

// Display an individual food
app.get('/food/:id', (req, res) => {
    res.render('showFood', {
        food: food[req.params.id]
    })
})

// Display a form to create a new drink or food
app.get('/new', (req, res) => {
    res.render('new')
})


/* Tell the app to 'listen' or run on the specified port
--------------------------------------------------------------- */
app.listen(3000, function () {
    console.log('Your app is running on port 3000...');
});
/* Require modules
--------------------------------------------------------------- */
const axios = require('axios')


/* Export API functions
--------------------------------------------------------------- */
module.exports = {
    getPokedex: async function () {
        // 1. Query the Pokedex endpoint
        const pokedex = await axios.get('https://pokeapi.co/api/v2/pokedex/2/')
        // 2. Iterate over all the pokemon in the pokedex to get the details URL
        const pokemonDetails = []
        for (let pokemon of pokedex.data.pokemon_entries) {
            // 3. Get each pokemon's details URL and send a request
            const url = pokemon.pokemon_species.url.replace('-species', '')
            const detailsRes = await axios.get(url)
            // 4. use only the data we need to optimize load time
            const detailsMini = {
                id: detailsRes.data.id,
                picture: detailsRes.data.sprites.other['official-artwork'].front_default,
                name: detailsRes.data.name,
                types: detailsRes.data.types
            }
            pokemonDetails.push(detailsMini)
        }
        return pokemonDetails
    },

    getPokemon: async function (id) {
        const res = await axios.get('https://pokeapi.co/api/v2/pokemon/' + id)
        return res.data
    }
}
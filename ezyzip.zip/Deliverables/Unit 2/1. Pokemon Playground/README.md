# Pokemon Playground
<img src="./banner.png" width="100%">


## Background
Now that you've learned about asynchronous JavaScript and APIs - it's time to put them both to use!! In this deliverable you'll be using 3 different endpoints from the [PokéApi](https://pokeapi.co/) to practice asynchronous axios requests. You'll use the DOM to populate an HTML file with data from the API.


## Set Up
- `cd` into `"Deliverables/Unit 2/1. Pokemon Playground/playground"` to access your starter code
- Open up the `index.html` in the browser using Live Server


## How to Complete this Deliverable
- Once you open up the `index.html` file with Live Server, you'll be presented with 9 questions. Each question will be answered using JavaScript code in the `app.js`
- You will use axios to query the PokeApi to answer each question. The response you get back from the PokeApi will be added to it's respective `<p>` tag using the DOM.
- Note that some questions may require to use the [PokeApi documentation](https://pokeapi.co/docs/v2)
- Questions will ask you for data that is nested in child objects and arrays. You may need to use loops to access and display the data you need. For example, to display all of [Ditto's](https://pokeapi.co/api/v2/pokemon/ditto) abilities you can access the ability object and loop over it like so:
    ```js
    axios.get('https://pokeapi.co/api/v2/pokemon/ditto')
        .then(res => {
            const answer = document.getElementById("part-1-answer-1")
            const abilities = res.data.abilities
            for (let item of abilities) {
                const p = document.createElement('p')
                p.innerText = item.ability.name
                answer.append(p)
            }
    })
    ```

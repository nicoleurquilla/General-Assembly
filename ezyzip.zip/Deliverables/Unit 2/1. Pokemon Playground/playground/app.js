/* SAMPLE AXIOS REQUEST
-----------------------------------------------------------
axios.get('https://pokeapi.co/api/v2/pokemon/ditto')
    .then(res => console.log(res.data))
----------------------------------------------------------- */


/* SAMPLE QUESTION & ANSWER
-----------------------------------------------------------
Part 3 - The Pokemon Endpoint (https://pokeapi.co/api/v2/pokemon)

Question 4: Display how many Pokemon this endpoint returns

Answer 4: axios.get('https://pokeapi.co/api/v2/pokemon')
                .then(res => {
                    const answer = document.getElementById("part-3-answer-4")
                    answer.innerText = res.data.count
                })
----------------------------------------------------------- */
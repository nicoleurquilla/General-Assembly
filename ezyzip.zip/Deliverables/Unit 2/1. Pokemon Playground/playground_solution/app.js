/* SAMPLE AXIOS REQUEST
-----------------------------------------------------------
axios.get('https://pokeapi.co/api/v2/pokemon/ditto')
    .then(res => console.log(res.data))
----------------------------------------------------------- */


/* SAMPLE QUESTION & ANSWER
-----------------------------------------------------------
Part 3 - The Pokemon Endpoint (https://pokeapi.co/api/v2/pokemon)

Question 4: Display how many Pokemon this endpoint returns

Answer 4: axios.get('https://pokeapi.co/api/v2/pokemon')
                .then(res => {
                    const answer = document.getElementById("part-3-answer-4")
                    answer.innerText = res.data.count
                })
----------------------------------------------------------- */



/* Part 1 - The Pokedex Endpoint (https://pokeapi.co/api/v2/pokedex/)
----------------------------------------------------------- */
// Question 1
axios.get('https://pokeapi.co/api/v2/pokedex/')
    .then(res => document.getElementById('part-1-answer-1').innerText = res.data.count)

// Question 2
axios.get('https://pokeapi.co/api/v2/pokedex/2/')
    .then(res => {
        const answer = document.getElementById('part-1-answer-2')
        answer.innerText = res.data.pokemon_entries.length
    })

// Question 3
axios.get('https://pokeapi.co/api/v2/pokedex/4/')
    .then(res => {
        const answer = document.getElementById('part-1-answer-3')
        const versionGroups = res.data.version_groups
        for (let versionGroup of versionGroups) {
            answer.innerText += (versionGroup.name + '\n')
            // const li = document.createElement('li')
            // li.innerText = versionGroup.name
            // answer.append(li)
        }
    })


/* Part 2 - The Location Area Endpoint (https://pokeapi.co/api/v2/location-area/)
----------------------------------------------------------- */
// Question 1
axios.get('https://pokeapi.co/api/v2/location-area/30/')
    .then(res => document.getElementById('part-2-answer-1').innerText = res.data.name)

// Question 2
axios.get('https://pokeapi.co/api/v2/location-area/trophy-garden-area/')
    .then(res => {
        const answer = document.getElementById('part-2-answer-2')
        answer.innerText = res.data.pokemon_encounters.length
    })

// Question 3
axios.get('https://pokeapi.co/api/v2/location-area/mt-coronet-exterior-snowfall/')
    .then(res => {
        const answer = document.getElementById('part-2-answer-3')
        const versionDetails = res.data.encounter_method_rates[0].version_details
        for (let versionInfo of versionDetails) {
            answer.innerText += (versionInfo.version.name + '\n')
        }
    })


/* Part 3 - The Pokemon Endpoint (https://pokeapi.co/api/v2/pokemon/)
----------------------------------------------------------- */
// Question 1
axios.get('https://pokeapi.co/api/v2/pokemon/wailmer')
    .then(res => {
        const answer = document.getElementById('part-3-answer-1')
        const abilities = res.data.abilities
        for (let item of abilities) {
            answer.innerText += (item.ability.name + '\n')
        }
    })

// Question 2
axios.get('https://pokeapi.co/api/v2/pokemon/squirtle')
    .then(res => {
        const answer = document.getElementById('part-3-answer-2')
        answer.innerText = res.data.moves.length
    })

// Question 3
document.getElementById('part-3-answer-3').innerText = 'Offset = 1280 and Limit = 1'
// Import the prompt-sync package that allows us to get user input
const prompt = require('prompt-sync')()

// Clear the console in between games
console.clear()


/* DEFINE SHIP CLASSES
---------------------------------------------------------------------------------- */
// A generic ship class that can be used to create the USS Tardigrade and enemy ships
class Ship {
    // Dynamically define each ship's properties
    constructor(name, hull, firepower, accuracy) {
        this.name = name
        this.hull = hull
        this.firepower = firepower
        this.accuracy = accuracy
    }
    // Attack Method: Fire on & damage an enenmy ship
    attack(enemy) {
        // Determine if the the attack hits the enemy ship by generartign anumber between 0 and 1
        let hitChance = Math.random()
        // If the random number is <= the ship's accuracy (this.accuracy)...
        if (hitChance <= this.accuracy) {
            // ...then damage the enemy ship
            enemy.hull -= this.firepower
            console.log(`${this.name}'s laser hit ${enemy.name} and did ${this.firepower} damage`)
        } else {
            // ...otherwise, our attack will miss the enemy ship
            console.log(`${this.name}'s laser missed`)
        }
    }
    // Is Alive Method: Determine if a ship is destroyed
    isAlive() {
        if (this.hull <= 0) {
            return false
        } else {
            return true
        }
    }
}

class AlienShip extends Ship {
    constructor(name) {
        super(name)
        this.hull = Math.floor((Math.random() * 4) + 3)
        this.firepower = Math.floor((Math.random() * 3) + 2)
        this.accuracy = Math.floor((Math.random() * 3) + 6) / 10
    }
}


/* INSTANTIATE (CREATE) SHIPS
---------------------------------------------------------------------------------- */
// The player's ship
const player = new Ship('SEB Tardigrade', 1, 1, .7)

// The alien fleet
const alienFleet = ['Quark', 'Zek', 'Kryn', 'Sol', 'Delta', 'Rana']
for (let i = 0; i < alienFleet.length; i++) {
    let shipName = alienFleet[i]
    alienFleet[i] = new AlienShip(shipName)
}


/* BUILD GAMEPLAY LOGIC
---------------------------------------------------------------------------------- */
// Introduce the game
console.log('SPACE BATTLE 🚀')
console.log(`You are piloting the ${player.name} and are suddenly attacked by a fleet of aliens! Will you make it out alive?\n\n`)
console.log('The alien fleet\'s stats:')
console.table(alienFleet)
console.log('Your stats:')
console.table(player)
console.log('\n')

// Ask the player if they want to start the game
let startGame = prompt('--> Would you like to start the game? Type "y" for yes, any other key for no: ')

// If the player wants to start the game, begin a round. Repeat rounds until the player restreats, dies, or wins
if (startGame.toLowerCase() === 'y') {

    // These varaibles determine if the for loop will continue to run (meaning the player advances through the rounds)
    let i = 0 // keep track of the round the user is on
    let continueGame = true // changes to 'false' when a player retreats

    // Begin a round if there are alien ships lieft, the player is alive, and the player wants to keep playing
    for (i; i < alienFleet.length && player.isAlive() && continueGame; i++) {
        // Every time a round starts clear the console and log the new stats
        console.clear()
        console.log(`ROUND ${i + 1} of ${alienFleet.length}`)
        console.log('------------')
        console.log(`Your opponent: ${alienFleet[i].name} (${alienFleet[i].hull} hull points)`)
        console.log(`You: ${player.name} (${player.hull} hull points)`)

        // Continue fighting the same alien while it and teh player are both alive
        while (player.isAlive() && alienFleet[i].isAlive() && continueGame) {
            // Make a new line in the terminal
            console.log('')

            // Ask the player if they want to attack or retreat
            let fireOrRetreat = prompt('--> Press "f" to fire, any other key to retreat: ')

            // If the user fires, attack the alien ship
            if (fireOrRetreat.toLowerCase() === 'f') {
                player.attack(alienFleet[i])

                // If the alien ship is alive, it can attack the player
                if (alienFleet[i].isAlive()) { alienFleet[i].attack(player) }

                // If the player retreats, the game ends
            } else {
                continueGame = false
            }
        }

        // Inform the player of the round's outcome
        if (player.isAlive() && alienFleet[i].isAlive() === false) {
            console.log(`\nYou destroyed ${alienFleet[i].name}!`)
        } else {
            console.log(`\nYou were destroyed by ${alienFleet[i].name}`)
        }
        console.log('--------------')
        console.log(`END OF ROUND ${i + 1}\n`)

        // Ask the user if they want to advance to the next round
        if (player.isAlive() && i < 5 && continueGame) {
            let nextRound = prompt('--> Press "f" to continue to the next round, any other key to retreat: ')
            if (nextRound.toLowerCase() !== 'f') {
                continueGame = false
            }
        }
    }

    // Display win or loss message
    console.log('GAME OVER')
    if (continueGame && player.isAlive()) {
        console.log('You win! You defeated the entire alien fleet 🥳')
    } else if (!continueGame) {
        console.log(`You destroyed ${i} of 6 alien ships`)
    } else {
        console.log('You lost, try again! :(')
    }

    // If the player chose not to start the game, say goodbye
} else {
    console.clear()
    console.log('See you next time!')
}
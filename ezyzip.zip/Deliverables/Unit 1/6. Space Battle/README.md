# &#x1F680; SPACE BATTLE
<img src="https://i.imgur.com/ad3Cw4V.png" width="100%" />

Today you will be using your knowledge of OOP, loops, and functions to build a rudimentary **space battle** game. The game will be programmed for, and played in the terminal (using the `prompt-sync` package install via `npm i prompt-sync`). You will need to use said package to get user input.

Today's task is to build a game that meets the specifications below. START SIMPLE. Break the problem down as far as you can and don't move on until the smallest piece works.

Once you've figured out the basics, it's up to you to make the game you want. Your game does not have to be elegant - the only thing that matters is that the game works as required.


## &#x1F47E; SPECIFICATIONS
### Build a game of battling alien spaceships using Javascript.
Earth has been attacked by a horde of aliens! You are the captain of the USS Schwarzenegger, on a mission to destroy every last alien ship.

There are six alien ships. The aliens exhibit strange behavior and attack one at a time: they will wait to see the outcome of a battle before deploying another alien ship. When squaring off with each alien ship, you get to attack first. After you have destroyed a ship, you have the option to make a hasty retreat.

A game round would look like this:
- You attack the first alien ship.
- If the ship survives, it attacks you.
- If you survive, you attack the ship again.
- If it survives, it attacks you again and so on.
- If you destroy the ship, you have the option to **attack** the next ship or to **retreat**
- If you retreat, the game is over, perhaps leaving the game open for further developments or options.
- You win the game if you destroy all of the aliens.
- You lose the game if you are destroyed.


### Ship Properties
- **hull** is the same as hitpoints. If hull reaches `0` or less, the ship is destroyed.
- **firepower** is the amount of damage done to the **hull** of the target with a successful hit.
- **accuracy** is the chance between 0 and 1 that the ship will hit its target.
- Every time the ship will attack, calculate the chance that the damage will hit the opposing ship using `Math.random()` 
- If the ship's accuracy is `0.8` - then if the number generated from `Math.random()` is less than or equal to `0.8` then the attack will be successful. If the value is greater than  `0.8` then the attack has missed. 
- Adjust the accuracy based on the specs for each ship:
 	- **Your spaceship, the USS Schwarzenegger** should have the following properties:
		- **hull** - `20`
		- **firepower** - `5`
		- **accuracy** - `.7`
	- **The alien ships** should each have the following _ranged_ properties determined randomly:
		- hull - between `3` and `6`
		- firepower - between `2` and `4`
		- accuracy - between `.6` and `.8`

		This means you could be battling six alien ships each with unique values. 

Example use of **accuracy** to determine a hit:

```javascript
if (Math.random() < alien[0].accuracy) {
	console.log('You have been hit!');
}
```

## &#x1F47E; SETUP
- Open up your local `Deliverables` repository
- `cd` into the  `6. Space Battle` directory
- touch `app.js`
- run `npm init -y` to initialize npm. This will set up your project to be able to install node packages.
- Run `npm i prompt-sync` to install the `prompt-sync` package. This package gets user input from the CLI.
- Test game using node app.js
- Use `console.log()` to send output to the user in the terminal.


## &#x1F47E; SUGGESTIONS FOR GETTING STARTED
- Read over the specifications. Make sure you understand them. If you do not understand them, try to clarify them for yourself.
- Plan the game. This is an act of simplification.
- Chekc out this excerpt from [these programming principles](http://www.artima.com/weblogs/viewpost.jsp?thread=331531):
	![](https://i.imgur.com/G8gyTJU.png)
- Use **pseudo code** to get a sketch of your game first.
- Often, beginning something is an act of **creative inspiration** to find the **simplest possible case**. The first step is not necessarily a matter of logical deduction. Once you have a few 'clues' you can follow the trail of crumbs to a logical conclusion.


### Actors and then actions
- A good rule of thumb is start with the **actors** and then the **actions**. What actors do we need? In this case, we need our spaceship and the alien spaceships. An action these ships can take is to attack something. Perhaps a ship object (an actor) could therefore have an **attack** method (an action). 
- A repeating action in the game is that these ships attack each other until one of them has been destroyed. This might necessitate a loop or multiple loops.


### Start simpler than the instructions suggest
Keep these five things in mind when planning and coding your game:
1. Begin even simpler than the specifications suggest. In this case, how about we just start with one alien ship instead of many alien ships, and get the code for one ship working first.
1. Root out any 'gotchas' that you really ought to foresee. In this case, will we really want nested loops -- one for a battle, one for iterating over aliens)? How will we exit one loop and then exit the parent loop? Perhaps keeping it to one loop somehow will help us avoid unnecessary difficulties.
1. When coding, form a solid and testable foundation before building upon it with more functionality. In this case, is there a bug where an alien can attack *after* it has been destroyed? Better fix that bug before increasing the complexity of the code.
1. When you have a piece of functionality tested and working, **commit it**. Try not to commit broken code. Unsure of when to commit? **Commit when something works**. You want to save working code.


## &#x1F47E; CODE QUALITY
From the beginning, you will be writing your code **for other developers.**

Having to read and understand another developer's code is common practice. Get used to it now! In the 'real world', you will be in a position where you inherit someone else's code-base and are told to 'fix it' or to add a feature to the code.

What does this mean for your coding practices? 
- Use proper and consistent indentation! On the job, your code immediately fails a code review if indentation is not perfect.
- What your code **does** should be self-evident.
- Use semantic variable and function names, and give your function names a verb.
- For code that is not self-evident, add comments.
- Your code should be as coherent to another developer as possible.


## &#x1F680; BONUS CHALLENGES
- The aliens send a random number of ships to attack Earth. Think of a reasonable range and implement it.
- Scientists have developed a super targeting computer for your lasers. You now are asked which of the aliens you would like to hit with your lasers.
- Scientists have improved your ship's shields. They don't work that consistently, and only improve your hit points by a random number each time
- Scientists have put missiles on your ship. You only have a limited number of them, but they do a lot of damage. You can say before each battle if you want to use one of your missles.
- The aliens have gained emotions and now can attack more than one at a time.
- Evil alien scientists have created an alien mega-ship. This mega-ship contains a number of "weapon pods" that each have their own individual hit points. These "weapon-pods" ( objects ) must all be destroyed before you can begin doing damage to the main ship, which also has its own hit points.
- When the game is over, prompt the user if they would like to play again, and make it so the user can play again with all the values set back to default.
- So far the entire game is just one battle, with many aliens. implement a game that consists of multiple battles where enemies respawn for a new battle at the end of the old battle. Keep track of points for the number of wins the player has.
- After every battle you are asked if you want to return to base and recharge your shields.
- Make the players and enemies stronger after each battle
- Distribute medals and power ups to the player depending on points



## &#x2B06; &#x2197; &#x27A1; CHEAT CODES
**Don't read the following steps if you want to figure this out on your own.** These are just suggestions, not answers, and will change the nature of the game that you would have made had you not read these.

<details>
<summary><strong>Testing out battle functionality:</strong></summary>
<hr>

- Make a `UssSchwarzenegger` object.
- Make a single alien ship object.
- Simulate a battle between your ship and a single alien ship first.
- Make a function that will attack a given target. The target can be an input to the function.
- Run the function and pass it the alien ship.
- Make it so the function reduces the target's hull by the firepower of the USS Schwarzenegger.
	
<hr>
</details>

<details>
<summary><strong>Game logic:</strong></summary>
<hr>
	
- Make a game object
- Make a function that will run and 'check win' for the health of the alien(s) and/or the USS Schwarzenegger. If the hull is 0 or less, display a message that the ship went kabloo-ey.
- Make it so the alien will only be hit if a Math.random call is below the accuracy threshold.
- Make a function for the alien ship to attack a target.
- At a status console log for the end of the round.
- If you make the alien ship go kabloo-ey, then the alien should not then be able to  attack you.
- Make it so the attacks will keep occuring until someone's hull is at 0. Isolate what it is that you want to repeat.

<hr>
</details>
	
<details>
<summary><strong>Building the ships:</strong></summary>
<hr>
	
- Consider how you might make many alien ships with objects, each one slightly different
	- hull between 3 and 6
	- firepower between 2 and 4
	- accuracy between 0.6 and 0.8
- Use `Math.random`
	```javascript
	this.hull = Math.floor(Math.random() * 4) + 3;
	this.firepower = Math.floor(Math.random() * 3) + 2;
	this.accuracy = (Math.floor(Math.random() * 3) + 6) / 10;
	```
- Make a loop that generates alien ships (objects). Push those constructed objects into a predefined array. Start with 6 ships (the loop should run 6 times).
- Try out the game with the first alien ship in the array.
- Run the battle with all ships in turn.

<hr>
</details>
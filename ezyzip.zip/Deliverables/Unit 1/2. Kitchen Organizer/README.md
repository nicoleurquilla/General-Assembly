# Kitchen Organizer
<img width="100%" src="https://i.imgur.com/KX1d2Pq.jpg">


## Set Up
1. During class today, we will have walked through how to set up your `Deliverables` repository. If you still need to set up, refer to this [markdown](https://git.generalassemb.ly/SEBR-Tardigrade/Cohort-Details/blob/main/Submitting%20Deliverables.md).
1. Navigate to the `Deliverables` folder on your computer and `cd` into the `Unit 1` directory. Then `cd` into the `2. Kitchen Organizer/kitchen` directory.
1. Using `mv`, `cp`, `rm`, `touch` and `mkdir`, reorganize the kitchen!

> **Hint**: You might have to Google how to use some of the commands we learned about! Check out resources like [this one](https://www.howtoforge.com/linux-mv-command/) and get in the habit of Googling ... it's at least 50% of a developer's job!


## Start Here
Your working directory will look like this in the beginning...
```
kitchen/
├── cans.txt
├── fridge
│   ├── diapers.txt
│   ├── freezer
│   │   ├── couch.txt
│   │   ├── frozenpeas.txt
│   │   └── icecream.txt
│   ├── milk.txt
│   └── trashcan
│       ├── banana-peels.txt
│       ├── chicken-bones.txt
│       ├── egg-shells.txt
│       └── sink
│           ├── clean-dishes.txt
│           ├── delete-me.txt
│           └── dirty-dishes.txt
└── pantry
    ├── cans.txt
    ├── cereal.txt
    └── crisper-drawer
        └── lettuce.txt
```


## End Here
When you're done running your terminal commands, it should look like this...
```
kitchen/
├── fridge/
│   ├── crisper-drawer/
│   │   ├── apples.txt
│   │   └── lettuce.txt
│   ├── freezer/
│   │   ├── frozenpeas.txt
│   │   └── icecream.txt
│   └── milk.txt
├── pantry/
│   ├── cans.txt
│   └── cereal.txt
├── sink/
│   ├── dirty-dishes.txt
│   └── drying-rack/
│       └── clean-dishes.txt
└── trashcan/
    ├── banana-peels.txt
    ├── chicken-bones.txt
    └── egg-shells.txt
```
  
## Submission
Remember, to submit your work you will run three commands in the terminal:
- **Add**: `git add -A`
    > This adds/stages all modified files to the queue
- **Commit**: `git commit -m "Organized the kitchen"`
    > This will save your queued files to your local repository's version history with a custom message
- **Push**: `git push`
    > This will push up any and all commits to your remote (online) repository. Once online, we'll be able to see your changes.
Once you follow these steps, your work will be submitted!


## Optional: `brew install tree`
Use tree to check what your current folder structure looks like. You can install it from the command line by running:
```bash
$ brew install tree
```

You can then run it by entering `tree` from the command line.

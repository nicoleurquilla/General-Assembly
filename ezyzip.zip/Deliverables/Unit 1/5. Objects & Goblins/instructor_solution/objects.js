console.clear()


/* PART 1
----------------------------------------------------------------- */
// Part 1 - Step 1
const setup = {
    computer: 'laptop',
    totalScreens: 2,
    hasMouse: true,
    hasLights: false
}
console.log('Part 1.1:', setup, '\n')

// Part 1 - Step 2
setup.totalScreens = 3
console.log('Part 1.2:', setup, '\n')

// Part 1 - Step 3
setup.clutter = ['drink', 'phone', 'wallet', 'sticky notes']
console.log('Part 1.3:', setup, '\n')

// Part 1 - Step 4
console.log('Part 1.4:')
for (let item of setup.clutter) {
    console.log('-', item)
}
console.log('')

// Part 1 - Step 5
setup.computer = {
    'screenSize': '4k',
    'OS': 'Manjaro Linux'
}
console.log('Part 1.5:', setup, '\n')

// Part 1 - Step 6
// console.log(setup.computer.screenSize, setup.computer.OS)
console.log('Part 1.6:')
for (let key in setup.computer) {
    console.log('-', setup.computer[key])
}
console.log('')

// Part 1 - Step 7
setup.computer.files = ['README.md', 'app.js', 'index.html', 'notes.txt']
console.log('Part 1.7:', setup, '\n')

// Part 1 - Step 8
console.log('Part 1.8:')
for (let item of setup.computer.files) {
    console.log('-', item)
}
console.log('')

// Part 1 - Setp 9
console.log('Part 1.9:')
const books = [
    { title: 'Pragmatic Programmer', author: 'David Thomas + Andrew Hunt' },
    { title: 'Clean Code', author: 'Robert Martin' },
    { title: 'You Don\'t Know JS', author: 'Kyle Simpson' }
]
for (let book of books) {
    console.log('-', book.title, 'by', book.author)
}
console.log('')

/* PART 2
----------------------------------------------------------------- */
// Part 2 - Step 1
const hero = {
    name: 'Leonidas',
    hitPoints: 50,
    attack: 10
}

// Part 2 - Step 2
const goblin = {
    name: 'Festus',
    hitPoints: 20,
    attack: 5
}

// Part 2 - Step 3
// console.log('Part 2.3')
// console.log(`> ${hero.name} starts off with ${hero.hitPoints} hit points`)
// hero.hitPoints -= goblin.attack
// console.log(`> The goblin attacked! ${hero.name} now has ${hero.hitPoints} hit points \n`)

// // Part 2 - Step 4
// console.log('Part 2.4')
// console.log(`> The goblin starts off with ${goblin.hitPoints} hit points`)
// goblin.hitPoints -= hero.attack
// console.log(`> ${hero.name} fought back! The goblin now has ${goblin.hitPoints} hit points`)

// Part 2 - Step 5
// console.log('Part 2.5:')
// console.log(`${hero.name} starts off with ${hero.hitPoints} hit points`)
// console.log(`The goblin starts off with ${goblin.hitPoints} hit points`)
// while (hero.hitPoints > 0 && goblin.hitPoints > 0) {
//     hero.hitPoints -= goblin.attack
//     console.log(`> The goblin attacked! ${hero.name} now has ${hero.hitPoints} hit points`)
//     goblin.hitPoints -= hero.attack
//     console.log(`> ${hero.name} fought back! The goblin now has ${goblin.hitPoints} hit points`)
// }


// Part 2 - Step 6
const attack = function (enemy) {
    enemy.hitPoints -= this.attack
    console.log(`> ${this.name} attacked! ${enemy.name} now has ${enemy.hitPoints} hit points`)
}

hero.attackEnemy = attack
goblin.attackEnemy = attack


// Part 2 - Step 7
console.log('Part 2.7:')
console.log(`${hero.name} starts off with ${hero.hitPoints} hit points`)
console.log(`The goblin starts off with ${goblin.hitPoints} hit points`)
while (hero.hitPoints > 0 && goblin.hitPoints > 0) {
    goblin.attackEnemy(hero)
    hero.attackEnemy(goblin)
}



/* PART 3
----------------------------------------------------------------- */
console.log('\nPart 3')
console.log('------')

const titan = {
    name: 'Leonidas ProMax',
    hitPoints: 50,
    attack: 10,
    attackEnemy: attack
}

// Loop ten times
for (let i = 1; i <= 10; i++) {
    // Create a creature
    const creature = {
        name: 'Creature ' + i,
        hitPoints: 20,
        attack: 5,
        attackEnemy: attack
    }

    // The creature fights the hero
    while (titan.hitPoints > 0 && creature.hitPoints > 0) {
        creature.attackEnemy(titan)
        titan.attackEnemy(creature)
    }

    // Log the completion of the battle
    if (creature.hitPoints <= 0) {
        console.log(`Battle ${i} complete!\n`)
    }
}

// Check the aftermath of the battle
if (titan.hitPoints > 0) {
    console.log('YOU WON!')
} else {
    console.log('YOU LOSE!')
}
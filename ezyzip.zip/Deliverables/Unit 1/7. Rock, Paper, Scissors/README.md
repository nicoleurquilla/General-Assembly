# Rock, Paper, Scissors Walkthrough

During the pre-work for this cohort you built a Rock, Paper, Scissors game. Now that you have a more complete understanding of the concepts briefly touched on in the pre-work you'll be able to build an even better Rock, Paper, Scissors!

# The Design Process
There's a sarcastic saying "You can save 5 hours of planning with 5 weeks of coding". In other words, a lack of upfront planning could lead to significantly more time spent on coding and potentially dealing with issues that could have been prevented through proper planning.

<p align="center"><kbd><img src="https://i.imgur.com/XT2fmPl.jpg" width="85%"></kbd></p>

In the image above, we see that creating a website as a product for consumers can be a long process that can involves several departments of a company, such as data analytics to get info about your target audience, marketing, and quality assurance. In this cohort we'll follow a simplified form of this design process for all your Unit Projects and some deliverables. 

<p align="center"><kbd><img src="https://i.imgur.com/rigfyKG.jpg" width="85%"></kbd></p>

In this rock, paper, scissors walkthrough, we'll go through each step of the design process you'll follow for your Unit Project (aside from actually publishing your site).


## 1. Concept: Define the Purpose and Goals
Before starting to code out your work, you'll need to clearly outline what it is exactly we're trying to accomplish. We'll have two types of goals, MVP goals and stretch goals.


### MVP Goals (What you must meet to complete the deliverable)
MVP goals are goals that when met will give us MVP, or our Minimum Viable Product. Essentially, we are answering "what will give us the base functionality we are looking for?"

1. Display a welcome message with the rules of Rock, Paper, Scissors
1. The user will click on an image to select either rock, paper, or scissors
1. After the user makes their selection the site randomly chooses an option, displays what was chosen, and determines the outcome of the match.
1. Allow the user to play again.
1. Store the number of wins and losses the user has at the top of the screen.


### Stretch Goals (Bonus)
Stretch goals are targets or objectives that go beyond the initial or expected aims of a project. These are designed to to challenge you and give your site additional useful features/functionality. **Stretch goals should only be worked on after MVP is met.** For this deliverable, you can work on these features as a bonus if you have enough time!

1. Create a button that when clicked will toggle between a "dark mode" and a "light mode". Consider how you might be able to use and manipulate CSS variables to accomplish this.
1. Look up the [`localStorage` object](https://developer.mozilla.org/en-US/docs/Web/API/Window/localStorage) and store the win/loss stats in it so the user can continue to keep track of their score each time they come back to the site. Allow the user to clear the stats by creating a button that clears `localStorage` when clicked.
1. Rather than displaying just wins, losses, and ties - display the choice that was made that resulted in that outcome. For example, in the "Wins" box, display a tally of how many times using rock resulted in a win.


## 2. Wireframes
Wireframes, or mockups,  serve as a blueprint for a website or app, providing a visual guide that outlines the structure and layout of key elements. They help beginners and designers plan the user interface, ensuring a clear and efficient design before investing time in detailed graphics and coding. Below is an example wireframe with different layouts mocked up for various screen sizes.

<p align="center"><kbd><img src="https://i.imgur.com/omjjcVo.png" width="85%"></kbd></p>

For this deliverables, the wireframes have been done for you. These wireframes will be referred to when working on the final CSS for the site. Below are three dropdowns each containing a mock up of what your rock, paper, scissors game will look like various points in the user's time on the site.

<ol>
    <li>
        <details>
            <summary><strong>Welcome Screen:</strong> This is the first screen the user will see when they navigate to the site</summary>
            <p align="center"><kbd><img src="https://i.imgur.com/FaZdzus.png" width="95%"></kbd></p>
        </details>
    </li>
    <li>
        <details>
            <summary><strong>Selection Screen:</strong> On this screen the user will be able to select rock, paper, or scissors. They are also able to view their score and re-open the rules modal if they want.</summary>
            <p align="center"><kbd><img src="https://i.imgur.com/a187GiB.png" width="95%"></kbd></p>
        </details>
    </li>
    <li>
        <details>
            <summary><strong>Result Screen:</strong> After the user selects rock, paper, or scissors, the outome of the match will be displayed. In addition to viewing their score and re--opening the rules modal, users will be able to return to the Selection Screen and play again.</summary>
            <p align="center"><kbd><img src="https://i.imgur.com/2SWv3XP.png" width="95%"></kbd></p>
        </details>
    </li>
</ol>


## 3. Coding
Now that we have clear objectives of what we want to accomplish, and an idea of what we want our site to look like, building our project will be much simpler! Now we can simply focus on writing code that gives us the outcome we planned.

Similar to how we first focused on what we want the application to **do** and then focused on what we wanted it to **look like**, when you're coding you should first implement functionality (basic structure and logic) and then implement the final stylized product (CSS).


### Set Up
1. Make sure you are in the correct folder of your local clone of the Deliverables repository before setting up your files. You should be here in your terminal:
    ```
    "[whatever your file path is to the repo]/Deliverables/7. Rock, Paper, Scissors"
    ```
1. Once you are in the correct location in your terminal, type `code .` to open up VS Code. 
1. Next, create the following three files:
    - `index.html`: Add your basic HTML boilerplate
    - `styles.css`: This will be empty for now
    - `app.js`: This will also be empty for now

<hr>


### Basic Site Structure
We're going to build a "rough draft" of the site, with a very basic UI. When building this simple UI all we care about is if:
- There are buttons we can add event listeners to
- We have all the elements JS will be manipulating/modifying

Once these elements exist, we can create ***all*** the JS logic we need to test our app's functionality.

1. First, ensure you have all the HTML boilerplate and that your CSS and JS files are linked to the HTML:
    ```html
    <!DOCTYPE html>
    <html lang="en">

    <head>
        <!-- Meta tags provide info about your site used by search engines and the browser -->
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!-- Browser tab -->
        <title>Rock, Paper, Scissors</title>
        <link href="https://i.imgur.com/Jwh6ELP.png" rel="icon">

        <!-- Linked files -->
        <link href="styles.css" rel="stylesheet">
        <script src="app.js" defer></script>
    </head>

    <body>
    </body>

    </html>
    ```

1. Next, we'll create the HTML structure for the modal that will appear on our "Welcome Screen" as depicted in our [wireframe](#2-wireframes). In the body tag, add the following HTML:
    ```html
    <!-- Modal element: Displays the welcome message and instructions -->
    <div id="modal">
        <div class="modal-content">
            <h1>Enjoy a quick game of rock, paper, scissors! 😀</h1>
            <h2>
                To begin, simply click on either the rock, paper, or scissors picture to make your selection and battle
                the
                computer!
            </h2>
            <h3>Remember:</h3>
            <p><span>🪨 > ✂️</span> <span>✂️ > 📃</span> <span>📃 > 🪨</span></p>
            <button id="close-modal">Play</button>
        </div>
    </div>
    ```
    > We'll create the JS that will allow us to hide this `div` after we finish building out the rest of the HTML

    <details>
    <summary>👀 Your page should now look like this:</summary>
    <p align="center"><kbd><img src="https://i.imgur.com/uRMM3uC.png" width="95%"></kbd></p>
    </details>

1. Let's now focus on building the HTML elements we'll need for the "Selection Screen". Below the HTML for the modal, add the following:
    ```html
    <!-- Scoreboard element: Where win, ties, and losses are recorded -->
    <section class="scoreboard">
        <header>
            <h2>Rock</h2>
            <h2>Paper</h2>
            <h2>Scissors</h2>
        </header>
        <ul>
            <li id="wins">
                <h4>WINS</h4>
                <h1>0</h1>
            </li>
            <li id="ties">
                <h4>TIES</h4>
                <h1>0</h1>
            </li>
            <li id="losses">
                <h4>LOSSES</h4>
                <h1>0</h1>
            </li>
        </ul>
    </section>

    <!-- Choices element: Where the user selects rock, paper, or scissors -->
    <section id="choices">
        <button class="fighter" id="rock">Rock</button>
        <button class="fighter" id="paper">Paper</button>
        <button class="fighter" id="scissors">Scissors</button>
        <h2>Choose your fighter!</h2>
    </section>
    ```

    <details>
    <summary>👀 Your page should now look like this:</summary>
    <p align="center"><kbd><img src="https://i.imgur.com/wPgjfgH.png" width="95%"></kbd></p>
    </details>

1. We can now create the elements for the final screen, the "Result Screen". Below the code you added in the previous step, create this HTML:
    ```html
    <!-- Results element: Where the outcomes of a match are displayed, and the "Play Again" button -->
    <section id="results">
        <div id="player-choice">
            <img src="#">
            <h3>YOU PICKED</h3>
        </div>

        <div id="result-message">
            <h1>YOU WIN</h1>
            <button id="restart">PLAY AGAIN</button>
        </div>

        <div id="cpu-choice">
            <img src="#">
            <h3>CPU PICKED</h3>
        </div>
    </section>

    <!-- Button to open the modal -->
    <footer>
        <button id="open-modal">RULES</button>
    </footer>
    ```

    <details>
    <summary>👀 Your page should now look like this:</summary>
    <p align="center"><kbd><img src="https://i.imgur.com/i4jNGtL.png" width="95%"></kbd></p>
    </details>

1. For now let's just add simple borders around the `#modal`, `.scoreboard`, `#choices`, `#results`, and `.footer` elements so we can better distinguish between them until we add all of our styling at the end of the design process. In `styles.css`:
    ```css
    #modal {
        border: 2px solid green;
    }

    .scoreboard {
        border: 2px solid purple;
    }

    #choices {
        border: 2px solid red;
    }

    #results {
        border: 2px solid blue;
    }

    footer {
        border: 2px solid purple;
    }
    ```
    We can use the border colors as a visual guide to what elements will appear where:
    - Everything outlined in green will appear on the Welcome Screen
    - Everything outlined in red will appear on the Selection Screen
    - Everything outlined in blue will appear on the Result Screen
    - Everything outlined in purple will appear on both the Selection and Result Screens
    
    <br>
    <details>
    <summary>👀 Your page should now look like this:</summary>
    <p align="center"><kbd><img src="https://i.imgur.com/s3SeKzO.png" width="95%"></kbd></p>
    </details>

<hr>


### Full Functionality
Luckily for us rock, paper, scissors is a pretty simple game. Unlike Space Battle, the gameplay itself won't be too complex. Here's what a psuedo-coded version of the actual game logic would look like:
```js
// This object will store the player's results
const stats = {
    wins: 0,
    ties: 0,
    losses: 0
}

// Execute the round when the user makes a choice
someHTML.addEventListener('click', /* game logic here*/)

// Event Handler Step 1: determine what choice the player selected
// Event Handler Step 2: have the computer randomly select an option
// Event Handler Step 3: create an if..else statement that will determine who won
// Event Handler Step 4: display the Result Screen and hide the Selection Screen
// Event Handler Step 5: modify the scoreboard to reflect the win/loss/tied game totals
```
The only other JS we need aside from the above is two event listeners to open and close the modal!

1. Let's start off with the easiest piece of this, which would simply accessing the various HTML elements we'll be manipulating. All the HTML that our JS will need to interact with has been given an `id` attribute, which is pretty convenient. However, it may get a bit tedious writing out code like this for ***every*** HTML element we need to access:
    ```js
    const someEl = document.querySelector('#some-id')
    ```
    What if we created a function with a shorter name that executed the above code? Especially if our function's name was one character long, we'd save oursleves quite a bit of typing! At the top of your `app.js` define this function:
    ```js
    /* Create a function called `$` for selecting an HTML element
    --------------------------------------------------------------------- */
    function $(cssSelector) {
        return document.querySelector(cssSelector)
    }
    ```
    Now whenever we want to select an element all we need to do is:
    ```js
    $('#scoreboard')
    ```
    Short and sweet!

1. Using our new function, let's access all the HTML elements we'll be manipulating and save them each to a variable. Add this code to `app.js`:
    ```js
    /* All HTML elements we need to manipulate (in the order they appear in index.html)
    --------------------------------------------------------------------- */
    const modal = $('#modal')
    const closeModal = $('#close-modal')
    const wins = $('#wins')
    const ties = $('#ties')
    const losses = $('#losses')
    const choiceScreen = $('#choices')
    const rockBtn = $('#rock')
    const paperBtn = $('#paper')
    const scissorsBtn = $('#scissors')
    const resultScreen = $('#results')
    const playerChoiceEl = $('#player-choice img')
    const resMsg = $('#result-message')
    const restart = $('#restart')
    const cpuChoiceEl = $('#cpu-choice img')
    const openModal = $('#open-modal')
    ```
    > You can test these variables out by typing any of them in the browser console! 
    > 
    > For example, type out `openModal` in the console and the HTML element will be returned to you.

1. Now that we have all of our HTML elements selected and saved to variables, we can begin to manipulate them and add event listeners. Let's start off by giving our modal open and close capabilities by adding this code to `app.js`:
    ```js
    /* Create event listeners for opening and closing the modal
    --------------------------------------------------------------------- */
    // Opening the modal
    openModal.addEventListener('click', () => modal.style.display = 'block')
    // Closing the modal
    closeModal.addEventListener('click', () => modal.style.display = 'none')
    ```
    That's it! The modal functionality is completely finished 🥳 Try testing it out!
    
    > When the modal is open, we can consider ourselves to be on the "Welcome Screen". Adding the CSS later so that the modal covers the rest of the page content will make this more evident.

1. We will also need to build the `stats` object that will store the result of each round:
    ```js
    /* This object will store a tally of each result the player gets
    --------------------------------------------------------------------- */
    const stats = {
        wins: 0,
        ties: 0,
        losses: 0
    }
    ```

1. Our next step is to create the event handler that we pseudocoded earlier:
    ```js
    /* Build the gameplay logic, which will be executed when the user clicks on a fighter
    --------------------------------------------------------------------- */
    function play(event) {
        // Step 1. Determine which fighter was clicked on by using the event object
        const playerChoice = event.target.id
        
        // Step 2. The computer will select a fighter using a random index between 0 and 2
        const cpuChoice = ['rock', 'paper', 'scissors'][Math.floor(Math.random() * 3)]

        // Step 3. Determine if the player won, lost, or tied
        let outcome

        if (playerChoice === cpuChoice) {
            stats.ties++
            outcome = 'TIE GAME'
        } else if (
            (playerChoice === 'rock' && cpuChoice === 'scissors') ||
            (playerChoice === 'paper' && cpuChoice === 'rock') ||
            (playerChoice === 'scissors' && cpuChoice === 'paper')
        ) {
            stats.wins++
            outcome = 'YOU WON!'
        } else {
            stats.losses++
            outcome = 'YOU LOST 😓'
        }

        // Step 4.1: Hide the Selection Screen
        choiceScreen.style.display = 'none'

        // Step 4.2: Modify the Result Screen
        if (playerChoice === 'rock') {
            playerChoiceEl.src = 'https://i.imgur.com/volQsQG.png'
        } else if (playerChoice === 'paper') {
            playerChoiceEl.src = 'https://i.imgur.com/kD6m2W9.png'
        } else {
            playerChoiceEl.src = 'https://i.imgur.com/om0NMTC.png'
        }

        resMsg.children[0].innerText = outcome

        if (cpuChoice === 'rock') {
            cpuChoiceEl.src = 'https://i.imgur.com/volQsQG.png'
        } else if (cpuChoice === 'paper') {
            cpuChoiceEl.src = 'https://i.imgur.com/kD6m2W9.png'
        } else {
            cpuChoiceEl.src = 'https://i.imgur.com/om0NMTC.png'
        }

        // Step 4.3: Display the Result Screen
        resultScreen.style.display = 'block'


        // Step 5: Modify the scoreboard to reflect the win/loss/tied game totals
        wins.children[1].innerText = stats.wins
        ties.children[1].innerText = stats.ties
        losses.children[1].innerText = stats.losses
    }
    ```
    > Remember, an *event handler* is the the callback function passed to the `.addEventListener` method. The `.addEventListener` method passes the [*event object*](https://developer.mozilla.org/en-US/docs/Web/API/Event) as an argument to the event handler. In the `play` function the parameter `event` is a placeholder for the event object.

1. Take a few minutes to look over the code from the previous step and read the comments. What do you expect to change on the page when this function is run? Let's see if you're right! 

    Add the event handler to a click event listener on each `.fighter` element:
    ```js
    rockBtn.addEventListener('click', play)
    paperBtn.addEventListener('click', play)
    scissorsBtn.addEventListener('click', play)
    ```
    Now click on a button to see if the page is behaving as you expected! If it's not behaving as you expected, take a moment to figure out why 🤔

1. It looks like there's only a few things we need to work out before adding the final CSS:
    
    - The Result Screen should be hidden when the user first opens the site, since they haven't yet played a game. To resolve this all we need to do is add this bit of CSS:
        ```css
        #results {
            border: 2px solid blue; /* you already should have this */
            display: none; /* we're adding this */
        }
        ```
    - The Selection Screen, once gone won't come back! We still need to add an event listener to the *PLAY AGAIN* button so that it hides the Result Screen and displays the Selection Screen. Add this code to your `app.js`:
        ```js
        /* Allow the user to play agin by clicking on the "Play Again" button
        --------------------------------------------------------------------- */
        restart.addEventListener('click', () => {
            resultScreen.style.display = 'none'
            choiceScreen.style.display = 'block'
        })
        ```


### Congratulations, you now have a fully functional rock, paper, scissors game!
<p align="center"><kbd><img src="https://media2.giphy.com/media/5K7ngCtszoxxbaBieC/giphy.gif?cid=ecf05e47y8wxtg0nt4l7f7nambnna9ykowlmvgh7g5nezhsb&ep=v1_gifs_search&rid=giphy.gif&ct=g"></kbd></p>


### ...but you're not done yet!
<p align="center"><kbd><img src="https://media3.giphy.com/media/k74OUg6bPJKy2JmyoS/giphy.gif?cid=ecf05e47wu7xry7sna978k9pxfh63dgqhx0r78f8sbxxpghf&ep=v1_gifs_search&rid=giphy.gif&ct=g"></kbd></p>

<hr>


### Final CSS: Match the UI and the Wireframes
Now that the game works, let's make it enjoyable to use and follow match the design the [wireframes](#2-wireframes) laid out

1. First, let's replace the simple Rock, Paper, Scissors buttons with images. As long as the `<img>` elements have the same class and id attributes we won't lose any functionality. 👍

    In your `index.html` replace this:
    ```html
    <button class="fighter" id="rock">Rock</button>
    <button class="fighter" id="paper">Paper</button>
    <button class="fighter" id="scissors">Scissors</button>
    ```
    with this new code:
    ```html
    <img class="fighter" id="rock" src="https://i.imgur.com/volQsQG.png">
    <img class="fighter" id="paper" src="https://i.imgur.com/kD6m2W9.png">
    <img class="fighter" id="scissors" src="https://i.imgur.com/om0NMTC.png">
    ```

    <details>
    <summary>👀 Your page should now look like this:</summary>
    <p align="center"><kbd><img src="https://i.imgur.com/VT4ri0Z.png" width="95%"></kbd></p>
    </details>

    <br>
    <details>
    <summary>🚨 If your images aren't loading expand this box 🚨</summary>
    
    1. Check to make sure you copied the links correctly
    1. Check your browser console for any error messages. You may see a message like this:
        ```
        Failed to load resource: the server responded with a status of 403 ()
        ```
    1. This is known difficulty with imgur, and can typically be solved by adding this `<meta>` tag to the `<head>` element in your HTML:
        ```html
        <meta name="referrer" content="no-referrer">
        ```
    1. If you're still running into problems, check out [this stackoverflow issue](https://stackoverflow.com/questions/43895390/imgur-images-returning-403) thread and try some of the fixes.
    1. If none of those fixes work, you can always download the images directly into your project folder and use the image file paths instead of their URLs.
    </details>
    <br>

1. Next, get rid of all of the borders we originally added into the CSS. This should now be your only remaining CSS:
    ```css
    #results {
        display: none;
    }
    ```

1. Let's now add into our CSS the colors used in the wireframes. We'll save them into global variables, to make the styling process smoother.
    ```css
    :root {
        --light-gray: #adadad;
        --dark-gray: #212121;
        --green: #009688;
        --yellow: #ffe599;
        --red: #ea9999;
    }
    ```
    > You can change the shades of these colors if you want!

1. The rest of the styling will be up to you! Now that you have the colors and images you need, the rest you can do on your own! Refer to the wireframes to make your site resemble the mockup screens. As you compare the wireframes to your site consider the following:
    - Layout: Would `display: flex;` or `position: absolute;` help me acheive any of the screen layouts?
    - Borders: What elements have a visible border? Are corners rounded?
    - Backgrounds: What elements are colored differently, and which CSS variable coudl I sue to acheive that color?
    - Sizing: How are the elements (especially the images and font) sized to make the site easily readable?


### 🙌 Good luck! You got this! 🙌

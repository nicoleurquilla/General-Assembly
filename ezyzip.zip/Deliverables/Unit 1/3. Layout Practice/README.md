# CSS Layout Practice: Flexbox & Grid
<img src="https://i.imgur.com/qsSi07H.png">

For this deliverable you will be using the mock-up below to create and style a web page using CSS Grid and Flexbox. ***Note that you can use flexbox inside grid cells!***

## Set Up
1. Open up your local `Deliverables` repository
1. `cd` into the  `3. Layout Practice` directory
1. Create the following files
  1. `index.html`
  1. `styles.css`
1. Link the CSS file to the HTML file
1. Commit frequently!


## Your Task
<img src="https://i.imgur.com/N4RdHqp.jpg" width="100%">

- Choose either the vertical or horizontal "profile card" above to reproduce using HTML and CSS.
- Use a combination of Flexbox and CSS Grid to layout the individual elements as close as possible - it does not have to be perfect!


## Hints
- Be sure to start with a bit of CSS reset:
  ```css
  * {
    box-sizing: border-box;
  }

  body {
    margin: 0;
    font-family: Helvetica;
  }
  ```
- Use the _Digital Color Meter_ application that comes with the Mac to "pick" the colors from the screen. If not on mac, open this repo in Firefox and use the color picker available in the developer tools.
- Elements can be made to appear circular by using `border-radius: 50%;`.
- For the rating scale with the stars, feel free to use this image tag:
	```html
	<img src="https://i.imgur.com/iUpkmhs.png">
	```	
- You can ignore the "phone" & "conversation" icons, just set the background colors of the "box".


## Bonus
As a bonus, reproduce both the vertical and horizontal versions!
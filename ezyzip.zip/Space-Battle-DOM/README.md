# &#x1F680; Space Battle DOM
<img src="https://i.imgur.com/ad3Cw4V.png" width="100%" />

## &#x1F47E; Intro
This exercise is a code-along with your instructor! Make sure you have the VS Code [Live Share extension](https://marketplace.visualstudio.com/items?itemName=MS-vsliveshare.vsliveshare) installed, which should have been done during Installfest.

This will be the first browser mini-game that you'll make! To keep it simple, all the HTML, CSS, and images have been provided for you. All you will need to worry about is using the DOM to make your game interactive!


## &#x1F47E; Set Up
1. To get the starter code for this exercise, simply clone down this repository by running the following command in your terminal:
    ```
    git clone https://git.generalassemb.ly/SEBR-Tardigrade/Space-Battle-DOM.git
    ```
 1. `cd` into the folder you just cloned down and run the `index.html` file using Live Server.
 1. Your browser should now have a window open that looks like this:
    
    <p align="center"><kbd><img width="95%" alt="inital Screen" src="https://i.imgur.com/kasMiN7.jpg"></kbd></p>
 
 1. Take a moment to explore the HTML and CSS:
    - How is the page structured?
    - How are things being styled? 
    - Is there a hidden image somewhere?
 1. Follow along with your instructor as you build out the JS game logic for Space Battle!


## &#x1F47E; Completed Code
The final code for this exercise will be in the `game` folder on the [solutions branch](https://git.generalassemb.ly/SEBR-Tardigrade/Space-Battle-DOM/tree/solutions) of this repository

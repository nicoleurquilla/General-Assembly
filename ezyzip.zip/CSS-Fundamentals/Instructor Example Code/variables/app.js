/* Computed Styles vs. Element Style Object
---------------------------------------------------- */
const myHTML = document.querySelector('.container')
console.log(myHTML.style.backgroundColor)
console.log(getComputedStyle(myHTML).getPropertyValue('background-color'))


/* Using Computed Styles to Get CSS Variables
---------------------------------------------------- */
// Select the root element
const root = document.querySelector(':root')
// Get the CSS stylesheet styles
const rootStyles = getComputedStyle(root)
// Get the global CSS variable by it's name
console.log(rootStyles.getPropertyValue('--primary-color'))


/* Using Elment Style Object to Set CSS Variables
---------------------------------------------------- */
root.style.setProperty('--primary-color', '#1e90ff')
console.log(rootStyles.getPropertyValue('--primary-color'))


/* Add event listeners & handlers to each color button individually
---------------------------------------------------- */
// const greenBtn = document.querySelectorAll('button')[0]
// const blueBtn = document.querySelectorAll('button')[1]

// greenBtn.addEventListener('click', () => {
//     return root.style.setProperty('--primary-color', '#85c985')
// })

// blueBtn.addEventListener('click', () => {
//     return root.style.setProperty('--primary-color', '#1e90ff')
// })



/* Add event listeners & handlers to each color button using a loop
---------------------------------------------------- */
// Select the button elements
const btns = document.querySelectorAll('button')

// loop over the buttons
for (let btn of btns) {
    // Change the value of `color` depening on each button's innerText
    let color;
    if (btn.innerText === 'Pistachio') {
        color = '#85c985'
    } else {
        color = '#1e90ff'
    }

    // Add an event listener to each button that will change the value of `---primary-color` to whatever `color` is set to by the condition above
    btn.addEventListener('click', () => {
        return root.style.setProperty('--primary-color', color)
    })
}
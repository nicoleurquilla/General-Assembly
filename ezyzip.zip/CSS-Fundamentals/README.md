# CSS Fundamentals
<img width="100%" src="https://i.imgur.com/D5RMpDv.jpg" />


## What is CSS?
CSS is a web technology used to layout and style HTML documents. It works alongside HTML to define how elements should be styled and displayed on a website. With CSS, you can customize the colors, fonts, spacing, and other visual aspects of your web pages. The latest version, CSS3, can also provide some stylistic behaviors using CSS animations!

It allows for consistent styling across multiple web pages, making it easier to maintain a cohesive design throughout a website. With CSS, you can create responsive layouts that adapt to different screen sizes, providing a seamless experience on desktops, tablets, and mobile devices.

By mastering CSS, you gain the ability to customize the look and feel of websites, create professional designs, and make your web content visually engaging and accessible to users. Like most skills related to development, your CSS skills will continually develop over time with each front-end project you're involved with.


## Lessons
1. [Intro to CSS](./Lessons/1.%20Intro%20to%20CSS.md)
1. [Layouts: Flexbox & Grid](./Lessons/2.%20Flexbox%20&%20Grid.md)
1. [Selector Deep Dive](./Lessons/3.%20Selector%20Deep%20Dive.md)
    - [Instructor Example Code](./Instructor%20Example%20Code/selectors/)
1. [Variables](./Lessons/4.%20Variables.md)
    - [Instructor Example Code](./Instructor%20Example%20Code/variables/)
1. [Responsive Design](./Lessons/5.%20Responsive%20Design.md)
1. [Intro to Frameworks](./Lessons/6.%20Intro%20to%20Frameworks.md)
1. [Bootstrap Basics](./Lessons/7.%20Bootstrap%20Basics.md)
    - [Instructor Example Code](#)
1. [Transitions & Animations](./Lessons/8.%20Transitions%20&%20Animations.md)
    - [Instructor Example Code](./Instructor%20Example%20Code/transitions/)


## Labs
1. [Media Query Markups](./Labs/1.%20Media%20Query%20Markups.md)
1. [Page Transitions](./Labs/2.%20Page%20Transitions.md)


## Cheatsheet
![CSS Vertical Cheatsheet](https://i.imgur.com/DybOsRd.jpg)

# Git & GitHub Fundamentals
<img src="https://i.imgur.com/VlXf8Sw.jpg" width="100%">


## What is Git?
Git is a version control system that allows developers to track changes in their codebase and collaborate with others efficiently. It helps manage the entire lifecycle of a project, from creating, editing, and organizing files to tracking changes and merging contributions from multiple people.

With Git, developers can create "snapshots" of their code at different points in time, making it easy to revert to previous versions if needed. Git enables branching, allowing developers to work on separate features or experiments without interfering with the main codebase.


## What is GitHub?
GitHub is a web-based platform that provides a hosting service for Git repositories. It enhances the power of Git by offering additional features and functionality. Developers can use GitHub to store their Git repositories online, making them accessible from anywhere and allowing for easy sharing with others.

GitHub also serves as a hub for open-source projects, enabling developers to contribute to public projects and collaborate with a global community. It fosters social coding, facilitates project management, and makes it easier for developers to showcase their work to potential employers or clients.


## Lessons
1. [Intro to Git](./Lessons/1.%20Intro%20to%20Git.md)
1. [Intro to GitHub](./Lessons/2.%20Intro%20to%20GitHub.md)
1. [Deploying to GitHub Pages](./Lessons/3.%20GitHub%20Pages.md)
1. [Getting Started with GitHub Campus](./Lessons/4.%20GitHub%20Campus.md)
1. [Working in Teams: Workflows](./Lessons/5.%20Team%20Workflows.md)


## Cheatsheet
<img alt="GitHub Education Cheatsheet Page 1" src="https://i.imgur.com/BUcnY64.png" width="100%">

<img alt="GitHub Education Cheatsheet Page 2" src="https://i.imgur.com/XXgSIFB.png" width="100%">

# Happy Fun Ball
<p align="center"><img src="https://i.imgur.com/5ciD1Jb.jpg"></p>


## Git Review
So far, you have been using git to get code (pull) from a remote repository (on github), writing your own code, tracking it with git, and moving (push) the code from your computer (local version) to github.

When using git locally (on your computer), you have been running the commands in Terminal (Command line).

A git command has a minimum of 1 argument.

Git commands are always executed by first typing `git`

The first argument is the command (or verb), like
- `git init` (initialize a new git repository)
- `git push` (send the code to a remote location)

The second(+) argument gives the first argument context (when needed)
- `git add .` (add all files in this directory)
- `git pull origin main` (get all files from the url that has an alias of `origin`, from the branch `main`)

Lastly, flags can be added
- `git remote -v` (git show remote(s) and be verbose(give more detail))

Here is a table of our commonly used git commands that we've used in this course so far:

| git | Argument | Flag(s)/Additional arguments | Description |
|:---:|:-----------:|:-------:|:-----------:|
| git | init |  |  Initializes a new repository|
| git | add | `.` or filename | Takes untracked files and adds them to the staging area so that they can be committed   |
| git | commit | -m 'some message'  |  Takes a snapshot of files in the staging area/ saves this version of them as a commit|
| git | remote | -v |  Shows the remote repositories associated with the local repository. Most repositories have an alias for their urls like `origin` or `upstream`|
| git | pull | upstream main |  Gets files from a url with an alias of `upstream` from its branch `main`|
| git | push | origin dev |  Sends files to a url with an alias of `origin` to its branch `dev`|
| git | log| --oneline |  Shows a log of commits of a repo (--oneline shows a truncated message)_`q` to exit_|
| git | status |  |  Shows the state of files in a repo (untracked, modified, staged)|

[Link to a more complete list of git commands](https://education.github.com/git-cheat-sheet-education.pdf)

Note: `fork` is not on this list because `fork` is not a git command; it is github-specific for copying a repository on github to a new location on github.

### Git VCS - Branches and Merging
Git is a VCS (Version Control System). There are a few popular ones, but git ends up being a top choice because of its branching and merging feature.

If we think back to our past projects, when we wanted to implement some major changes to our code and failed our popular options were to
- `⌘Z` throughout our files and hope for the best
- Comment out a ton of code and hope to restore the functionality of our code to a previous version
- Seriously contemplate coding out our project from scratch again
- Curl up into a ball and hope the code would revert via magic

[Git's about page has 4 great reasons why it works so well for individuals and large teams.](https://git-scm.com/about)

- **Frictionless Context Switching** - Switch between branches, whenever! No worries!
- **Role-Based Codelines** - Have many versions of your code - Production, Development, Day-to-Day etc.
- **Feature Based Workflow** - Create a new branch for each feature
- **Disposable Experimentation** - if a branch doesn't work out, you can just walk away or toss it. It has no impact on the working code

While this is all very useful, Git requires changing the way we are used to working on projects. Which means it takes some time and practice to learn to use Git.



### Git Branch Commands
To be able to use branches, we will have to learn some new Git commands

| git | Argument | Flag(s)/Additional arguments | Description |
|:---:|:-----------:|:-------:|:-----------:|
| git | branch |  |  Lists branches |
| git | branch | branch_name |  Creates a new branch |
| git | checkout | branch_name | Switches branches |
| git | checkout | -b new_branch_name  |  Creates a new branch and switches to that branch|
| git | diff |  |  Let's you see the changes that you have made (before `git add`)|

Even though these are just five new commands, it is going to take some practice to master them. Let's get started!

Note: You may have noticed that `git merge` is missing - we will be merging our branches via github, so we will not use this command.


## Scenario
You have been hired by Wacky Products Incorporated. They are just weeks away from starting a global marketing campaign for their new hot product Happy Fun Ball and they want a top-notch web page to be launched as soon as possible.

Mysteriously, the entire dev team has lapsed into comas and it is up to you to save the project.

As a professional developer, you will do whatever it takes to finish this project! Everything, BUT work directly on the main branch!


## Setup
### Setup Part 1 - Get the files
#### In the Browser
- Fork Happy-Fun-Ball (make a copy of this remote repository to your GitHub Enterprise account)
- Navigate to YOUR version on YOUR github repo
- Click on the Code button to display a URL, and copy the URL to the clipboard
- REMEMBER: This should be from YOUR repo (the link to be copied should be `https://git.generalassemb.ly:YOUR USERNAME/Happy-Fun-Ball.git`)

#### In the Command Line
- Navigate to a your code directory and then clone the forked repo:
    ```
    git clone https://git.generalassemb.ly:YOUR USERNAME/Happy-Fun-Ball.git
    ```
- The above command should create a new folder inside your current directory and make copy of everything in the Happy Fun Ball remote repository, locally (on your computer) and initialize git. Let's check:
    - `cd Happy-Fun-Ball` into the cloned directory and then
    - `ls` to check that these files are in your folder
        - `index.html`
        - `main.css`
        - `README.md`
        - `hfb.png`
    - `git status` should return an output like this:
        ```
        On branch main
        Your branch is up-to-date with 'origin/main'.
        nothing to commit, working tree clean
        ```
  - `git remote -v` - to check your remote set up which should return an output like this:
      ```
      origin    https://git.generalassemb.ly:YOUR USERNAME/Happy-Fun-Ball.git (fetch)
      origin    https://git.generalassemb.ly:YOUR USERNAME/Happy-Fun-Ball.git (push)
      ```


### Setup Part 2 - Make a Dev Branch
#### In the Command Line
- To make a new branch AND checkout the new branch (we will call our new branch "dev")
- Run `git checkout -b dev`. It will return a message like this:
    ```
    Switched to a new branch 'dev'
    ```
- Run the `ls` command. `index.html` & `main.css`, etc. - should still be there
- Run a `git status` to confirm everything looks like it should:
    ```
    On branch dev
    nothing to commit, working tree clean
    ```
- The dev branch only exists on your computer. Push up the dev branch to GitHub by running `git push origin dev`. Your output will look like this:
    ```
    * [new branch]      dev -> dev
    ```


#### In the Browser
- See your new branch on github (it should be there, refresh if you don't see it. If you still don't see it, let me know and we'll trouble shoot)
It will be a new message along the top of github OR from clicking the `Branch: main` button

  ![pull-down menu](https://i.imgur.com/oIptMUM.png)



#### In the Command Line
- `code .`open the files in Vs Code
- `open index.html` open index.html in the browser (remember you can do `open i` and then press `tab` to autocomplete index.html)


### Setup Part 3 - Organize yourself
- We are going to be going between the browser, the CLI, and VS Code frequently. Be sure you can work efficiently and effectively by setting up a good workflow! 
- Start by organizing your browser, CLI, and VS Code so that you can easily switch between them (remember to use Spectacle). Close extra tabs and browser windows.
- Take a couple minutes to get familiar with the code you'll be working on.


## New Feature - Link the HTML and CSS
Your first new feature!  Working in `index.html`, you will add a link to `main.css`, then you will merge it into the dev branch, and then into main.


### New Feature Part 1 - Make a New Branch
#### In the Command Line
- Let's make a new branch specifically for our new feature
- Run `git branch` - to check that you are on the `dev` branch. This command will show all the branches and highlight the one you are on. 

     ![example output of `git branch`](https://i.imgur.com/2bKy3zL.png)

- Run `git checkout -b link-files`. This will create a new branch (a copy of the branch we are switching from, in this case: `dev`) called `link-files` and check it out.


### New Feature Part 2 - Work on New Feature
#### VS Code - index.html :
- In the index.html - between the` </title>` and `</head>` tags, let's insert a link to our css :
- `<link rel="stylesheet" href="main.css">`
- `⌘S` - Save our changes in VS Code


#### Browser - index.html:
- `⌘R` - Reload our browser view of the `index.html`
- The CSS should now be loaded into our `index.html`


### New Feature Part 3 - Feature Completed! Use Git to Track/Add it
#### In the Command Line
- `git status`
- `git add index.html`
- `git commit -m 'index.html and main.css linked'`
- `git push origin link-files`  (Remember: `origin`and `link-files` can be autocompeletd by using `tab`)


### New Feature Part 4 - Merge New Feature into Dev Branch
#### In the Browser
- Check github to see that the new branch is there 

    ![github new branch screenshot](https://i.imgur.com/YtFNJEk.png)

- You will either have a yellow bar with your branch name and a green `compare & pull request`or you will have to choose the `Pull requests` tab (the yellow bar does not always appear. It does not automatically mean that something is wrong)
    - Note: if you do not get the yellow bar, you will have slightly different navigation to complete this step, a detailed outline is down below in the *New Feature Part 6: Merge Dev Branch into Main* section.
- Push the `Compare & pull request button` that is on the right of the yellow bar
- Select **YOUR** fork (click on `base fork: Krafalski/hfb` and then scroll to your username/fork), wait for the page to update to the next screenshot image:

    ![choose your fork](https://i.imgur.com/TIoeuRd.png)

- Select `base:dev` and `compare: link-files`

    ![selecting your base and compare](https://i.imgur.com/KPNeb9p.png)

    ![github pull request](https://i.imgur.com/AW5kmXJ.png)

- Wait a moment to let github tell you if there are any merge conflicts

    ![image of able to merge](https://i.imgur.com/Q3BzVry.png)


- All clear! Go ahead and press the `Create pull request` button, wait a moment and you should see a green `Merge pull request` button about midway down.

    ![Merge pull request view](https://i.imgur.com/MlXlXg3.png)

- Press the button, then the button will change to say `Confirm merge` press it again to confirm the merge!

    ![image of a successful merge on github](https://i.imgur.com/QFpGVAQ.png)

    **Note:** When you work on a team it is unlikely that you would merge your own pull requests


### New Feature Part 5 - Get the Latest Remote Version of Dev, Locally
#### In the Command Line
- Run `git checkout dev` (Notice: no `-b`)
- Run `git pull origin dev`
- Check VS Code (`index.html` has the link to CSS)
- Your browser view (`index.html` is displaying with CSS loaded - remember to `⌘R`/refresh your browser to be sure you are seeing the updated version)
- If everything looks good, let's merge these changes into the main branch


### New Feature Part 6 - Merge Dev Branch into Main
#### In the Command Line
- Run `git pull origin main`. This should come back as clean but it is a good habit to pull before you push. The expected output:
    ```From github.com:Krafalski/hfb
    * branch            main     -> FETCH_HEAD
    Already up-to-date.
    ```
- Run `git push origin dev` (this should also come back as clean - since we have changed nothing in our code), it is good to get in the habit of checking yourself often!

#### In the Browser
- If you are still on the merge page, navigate back to the main view
- Open the `Pull Requests` tab
- On the right select the green `New pull request` button
- Select **YOUR** fork (click on `base fork: Krafalski/hfb` and then scroll to your username/fork), wait for the page to update to the next screenshot image:

    ![choose your fork](https://i.imgur.com/TIoeuRd.png)

- Wait for the page to update so you can
- Compare `base: main` to `compare: dev`
- Wait to be sure there are no conflicts
- Green `Create pull request` button
- New screen that lets you add comments, midway to the right press green `Create pull request` button
- green `Merge Pull Request` button
- green `Confirm Pull Request` button

#### In the Command Line
- Run `git checkout main`
- Run `git pull origin main`


#### In VS Code
- Check to make sure everything has updated as expected (`index.html` has link to css and when you refresh the browser, the CSS still loads)


### New Feature - Update the colors
 Work on a new feature: Working in the `main.css` file, you will update the colors of the Happy Fun Ball web page


#### In the Command Line
- Before we begin, let's make a new branch specifically for our new feature:
  - Check that you are on the dev branch **
  - `git branch` will list all your branches and have a `*` next to the branch you are on. Then:
  - `git checkout dev`
  - `git checkout -b color-updates`


  ** GOTCHA: Branches can be created off any other branch. Be sure you are on the branch that you want to branch off of before creating a new branch!

#### VS Code - index.html:
- You probably noticed that index.html had a typo! On (or around) line 19 `class="pr"` should actually be `class="price"`.
- Let's update that! (Remember `⌘S`/save) Now, it's not really our task, or our file to work on, but we're just being proactive and  helpful! What could possibly be wrong with that?

#### In the Command Line
- Let's go ahead and
- `git status`
- `git add index.html` and
- `git commit -m 'fixed typo in index.html'`, there! We added our changes and put in a descriptive commit message. We are undoubtedly awesome.


#### VS Code - main.css:
- Now let's update the colors in the `body`, let's change `color` (font color), and `background-color` to whatever our heart desires. [Go ahead and use hexadecimal colors, rgb, hsl or some of the standard web colors.]( http://htmlcolorcodes.com/color-names/)

Make changes here in main.css ![main.css](https://i.imgur.com/1WY4xj8.png)
- When we've found the colors we like, we can go ahead and
- ``⌘S`/save`


#### In the Command Line
- `git status` - see the status of our files
- `git diff` - see what we have changed
- `git add main.css` and
- `git commit -m 'updated colors'`
- `git log --oneline` -see our commits so far (`q` to exit)


## See Branching in Action
#### In the Command Line
- `git checkout dev` (Notice: no `-b`)

#### VS Code - main.css:
- See that our changes are gone

#### Browser - index.html:
- Refresh the page and see that the page has reverted to the original version
- Let's get back to our changes!


#### In the Command Line
- `git checkout color-updates` (remember you can use `tab` to autocomplete branch names too!)

Go through VS Code and the browser to see that your changes have come back


#### VS Code - main.css:
- Let's make one more color change, now that we are on our color-updates branch. `.price` change the color from orange, to whatever color you want
- Can't find `.price`?
- `⌘F` will open a find/replace tab at the bottom of VS Code and let you look for `.price`
- `esc` to close the find/replace tab
- make your changes (we are changing the color of elements with the class of `price`)
- `⌘S` -Remember to save your file
- Refresh your browser to see your changes


## Starting on a New Feature When We Haven't Finished Our Previous One
There was an error! The price of Happy Fun Ball is supposed to be $24.95, not $14.95!
<br>

Let's make a new branch off of the dev branch to hotfix this major problem! **

#### In the Command Line
- `git checkout dev`<br>
- Oops! We forgot to `git add .` & `git commit -m''`. You'll see an error message like this:
    ```
    error: Your local changes to the following files would be overwritten by checkout:
        main.css
    Please commit your changes or stash them before you switch branches.
    Aborting
    ``````
- To correct this run:
    - `git add .`
    - `git commit -m 'changed .price color'`
- Now we should be able to run `git checkout dev` without any issues
- Next, run `git checkout -b price-fix` to make a new branch off of dev (and automatically be switched to the new branch) **


#### VS Code - index.hmtl:
- Update the price of happy fun ball from `$14.95` to `$24.95` (~ line 19 of `index.html`)
- `⌘S`/save


#### In the Command Line
- `git add index.html`
- `git commit -m 'fixed price of Happy Fun Ball in index.html'`
- `git pull origin dev` (this should come back clean, but it is good practice to pull before pushing)
- `git push origin price-fix` to create a new branch on github

** GOTCHA:  Branches can be created off any other branch. Be sure you are on the branch that you want to branch off of before creating a new branch!


## Merging Our New Feature into the Dev branch
#### In the Browser
- See our new branch (either a message will pop up or use the left side pull down to see)

    ![github screenshot](https://i.imgur.com/mgEzi40.png)

- Select the `Pull requests` tab
- On the right side, push the `New pull request` button
- Select `base: dev` and `compare: price-fix`
- Wait a moment to let github tell you if there are any merge conflicts

    ![github all clear](https://i.imgur.com/L72S16y.png)

- All clear! Go ahead and press the `Create pull request` button
- A new screen will appear, enter a message if you like, otherwise push the `Create pull request button`
- `merge pull request` button, wait a moment, then go ahead and confirm the merge! (Note: when you work on a team, it is unlikely that you would merge your own pull requests)

    ![Merge Pull Request message and button](https://i.imgur.com/2yUuGmq.png)


## Going Back to Our Updated Colors Feature
- Whew! That was exciting! It's nice to be back to working on this feature. We know there were changes to the `dev` branch, so let's get them


#### In the Command Line
- `git checkout color-updates`
- `git pull origin dev` - to pull down your changes from the remote to your local copy. You'll get an error message like this:
    ```
    ERROR! Merge conflict! Example output:

    * branch            dev -> FETCH_HEAD
    c1df4fd..cc1ba3e  dev        -> origin/dev
    Auto-merging index.html
    CONFLICT (content): Merge conflict in index.html
    Automatic merge failed; fix conflicts and then commit the result.
    ```


## Merge Conflict (and Resolution)!
#### VS Code - index.html :
- View the conflict in VS Code

  ![index.html file](https://i.imgur.com/itPVnM1.png)

- Delete  everything between (including these lines as well) `<<<<<<< HEAD` and `========`.

- What you'll be deleting should be all of this:
    ```
    <<<<<<< HEAD
        <h3 class="price">Only $14.95</h3>
    =======
    ```

- This conflict is our doing, let's get rid of our mistake from working in index.html when we were only supposed to be working in main.css and keep the change made from the price-fix branch

- Now that we've removed the conflict let's finish cleaning up the conflict and remove the line `>>>>>>> 3b73c340f2c158a80ce20828fd94ad83ea60b444`
    - ****Note:** your numbers/letters after the `>>>>>>>` should be different
- Let's also clean up any extra white space
- Save the file


#### In the Command Line
- Run `git add index.html`
- Run `git commit -m 'fixed merge conflict'`
- Run `git push origin color-updates`
- We fixed the merge conflict! Now we can continue working on our project


## Finishing and Merging Your Color Updates
#### VS Code main.csss:
- Make your final updates to `main.css`


#### In the Command Line
- `git add main.css`
- `git commit -m 'updated colors'`
- `git push origin color-updates`


#### In the Browser
- Pull Request
- Compare `base: dev` to `compare: color-updates`
- Wait to be sure there are no conflicts
- Create Pull Request
- Merge Pull Request
- Confirm Pull Request


#### In the Command Line
- `git checkout dev`
- `git pull origin dev`


#### VS Code index.html/main.css :
- Take the time to review that the changes to the dev branch that you wanted are there and there are no errors or bugs
- **Only working code should ever be merged to main!**

- If everything is ok, go ahead and merge the changes to main
- If you made changes, remember to
- `git add` and
-  `git commit -m ''`


#### In the Command Line
- `git pull origin dev` (yes, we _just_ did this, but it is a good habit to do a pull before doing a push. It is ok if git tells you `Already up-to-date` )
- `git push origin dev` (it is ok if git tells you that `Everything up-to-date`)


#### In the Browser
- Pull request
- Compare `base: main` to `compare: dev`
- Wait to be sure there are no conflicts
- Create Pull Request
- Merge Pull Request
- Confirm Pull Request
- Check to see that your changes have been successfully made to the main branch


## Submit Your Final Product
As we've done before, submit your repo by creating a pull request to the classroom repo.

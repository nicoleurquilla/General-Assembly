# Internet Fundamentals
<img src="https://i.imgur.com/71101Rh.png" width="100%" />


## How Does the Internet Work?
At its core, the internet operates on a client-server model. The client, typically a user's computer or device, sends requests to servers, which are powerful computers that store and deliver information. The servers respond to these requests by sending back the requested data. This client-server relationship forms the foundation of how information is accessed and shared on the internet. Websites, web applications, and other online services are built using this model, where the client (such as a web browser) sends requests to servers and receives responses containing the requested content.

By understanding how the internet works, web developers are able to build and leverage tools to speed up development, optimize performance, and save money by ensuring connections are made properly and only allowing serves to send needful information to clients.


## Lessons
1. [Intro to Full-Stack Development & HTTP](./Lessons/1.%20Intro%20to%20Full-stack%20%26%20HTTP.md)
1. [APIs & AJAX](./Lessons/2.%20APIs%20%26%20AJAX.md)
1. [REST APIs & CRUD](./Lessons/3.%20REST%20APIs%20%26%20CRUD.md)


## Additional Resources
- [MDN Docs: How the Internet Works](https://developer.mozilla.org/en-US/docs/Learn/Common_questions/How_does_the_Internet_work)
- [How the Internet Works in 5 Minutes](https://www.youtube.com/watch?v=7_LPdttKXPc)


## Licensing
1. All content is licensed under a CC­BY­NC­SA 4.0 license.
2. All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.

# MEN Stack - Part 1 (Index, Show, and Seed Routes)
<img src="https://i.imgur.com/2ARbclT.png" width="100%"/>


## Intro: The MEN Stack
Full stack apps are often referred to by abbreviations of the technologies used within the app. The app we'll build today is known as a MEN Stack app. The MEN stack is comprised of:
- **M**ongoDB/Mongoose
- **E**xpress.js
- **N**ode.js


## Background
As a budding full-stack devloper, you've just got a new client that needs you to build their website! Your client is a pet adoption service that connects pet lovers across North America with pets in need of adoption. Today, we'll be setting up this application, and building out the **index**, **show**, and **seed** routes.


## 1. Create a Route Table
Let's create a route table that will define and describe what each route in our application is doing. 

|       **URL**   | **REST Route** | **HTTP Verb** | **CRUD Action** |   **EJS View(s)**   | **Created Yet?**  |
| --------------- | -------------- | ------------- | --------------- | ------------------- | ----------------- |
| /               |                | GET           | read            | home.ejs            | NO                |
| /pets           | index          | GET           | read            | pet-index.ejs       | NO                |
| /pets/:id       | show           | GET           | read            | pet-details.ejs     | NO                |
| /pets/new       | new            | GET           |                 | new-pet.ejs         | NO                |
| /pets           | create         | POST          | create          |                     | NO                |
| /pets/:id/edit  | edit           | GET           | read            | edit-pet.ejs        | NO                |
| /pets/:id       | update         | PATCH/PUT     | update          |                     | NO                |
| /pets/:id       | destroy        | DELETE        | delete          |                     | NO                |
| /seed           |                | GET           | delete & create |                     | NO                |
| /about          |                | GET           |                 | about.ejs           | NO                |
| /*              |                | GET           |                 | 404.ejs             | NO                |


## 2. Set Up File Structure
<ol>
    <li>Create the application folder by running:
        <pre><code>mkidr furever-friends</code></pre>
    </li>
    <li><code>cd</code> into <code>furever-friends</code> and run the following:
        <pre><code>cd furever-friends &amp;&amp; touch server.js .env</code></pre>
    </li>
    <li>Scaffold a MVC app by running:
        <pre><code>mkdir models views views/partials controllers public public/assets public/styles</code></pre>
    </li>
    <li>
        <details>
            <summary>Inside <code>models</code> create the following files:</summary>
            <ol type="i">
                <li><code>index.js</code>: Connects to the database. Contains all the exported models and seed data.</li>
                <li><code>pet.js</code>: Creates the Pet model.</li>
                <li><code>seed.js</code>: Contains the initial, or seed data.</li>
            </ol>
        </details>
    </li>
    <li>
        <details>
            <summary>Inside <code>controllers</code> create the following files:</summary>
            <ol type="i">
                <li><code>pets.js</code>: Contains all the routes for any URI starting with <code>pets/</code></li>
            </ol>
        </details>
    </li>
    <li>
        <details>
            <summary>Inside <code>views</code> create the following files:</summary>
            <ol type="i">
                <li><code>home.ejs</code>: The landing page of the application, will display featured pets.</li>
                <li><code>pet-index.ejs</code>: The view for the <strong>index</strong> route. Will display all pets.</li>
                <li><code>pet-details.ejs</code>: The view for the <strong>show</strong> route. Will display all details for a specific pet.</li>
                <li>Inside <code>views/partials</code> create the following files:
                    <ol type="a">
                        <li><code>head.ejs</code>: The standard boilerplate code that can be re-used across all pages in the <code>&lt;head&gt;</code> tag.</li>
                        <li><code>nav.ejs</code>: The navigation menu that will be reused across most pages.</li>
                        <li><code>footer.ejs</code>: The same footer will be resused across all pages on the site.</li>
                    </ol>
                </li>
            </ol>
        </details>
    </li>
    <li>
        <details>
            <summary>Inside <code>public/styles</code> create the following files:</summary>
            <ol type="i">
                <li><code>main.css</code>: The main styles for the site, and the styles for the EJS partials will be contained in this file.</li>
                <li><code>home.css</code>: Contains styles specific to the <em>home</em> page.</li>
                <li><code>pet-index.css</code>: Contains styles specific to the <em>pet-index</em> page.</li>
                <li><code>pet-details.css</code>: Contains styles specific to the <em>pet-details</em> page.</li>
            </ol>
        </details>
    </li>
    <li>Initialize NPM by running:
        <pre><code>npm init -y</code></pre>
    </li>
    <li>Install required dependencies by running:
        <pre><code>npm i express ejs mongoose dotenv livereload connect-livereload</code></pre>
        <p>You'll notice that we installed two new dependencies, <code>livereload</code> and <code>connect-livereload</code>. These will allow our application to auto-refresh the browser everytime <code>nodemon</code> reloads.</p>
    </li>
</ol>



## 3. Configure `.env` Variables
Inside the `.env` file at the root of the application, add the following code replacing the `MONGODBURI` value with your connection string.

```shell
PORT=3000
MONGODBURI='your connection string here'
```

## 4. Create the `Pet` Model
<ol>
<li>
<details>
<summary>First, we need to connect our Express app to MongoDB. In <code>models/index.js</code>:</summary>

```js
// Require the Mongoose package & your environment configuration
const mongoose = require('mongoose');
require('dotenv').config()

// Connect to MongoDB Atlas
mongoose.connect(process.env.MONGODBURI);
const db = mongoose.connection

db.on('connected', function () {
    console.log(`Connected to MongoDB ${db.name} at ${db.host}:${db.port}`);
});
```
</details>
</li>

<li>
<details>
<summary>Next, we need to build the Pet schema and export it as a Mongoose model:</summary>

```js
// Require the Mongoose package
const mongoose = require('mongoose');

// Create a schema to define the properties of the pets collection
const petSchema = new mongoose.Schema({
    name: { type: String, required: true },
    age: { type: Number, min: 0, required: true },
    breed: { type: String, default: 'Unknown' },
    species: { type: String, enum: ['Dog', 'Cat'], required: true },
    city: { type: String, required: true },
    state: { type: String, maxLength: 2, required: true },
    photo: { type: String, required: true },
    description: { type: String, required: true },
    isFeatured: { type: Boolean, default: false },
    dateAdded: { type: Date, default: Date.now }
});

// Export the schema as a Monogoose model. 
// The Mongoose model will be accessed in `models/index.js`
module.exports = mongoose.model('Pet', petSchema);
```
</details>
</li>

<li>
<details>
<summary>Now we can access the Pet model inside <code>models/index.js</code>:</summary>

```js
module.exports = {
    Pet: require('./pet')
}
```
</details>
</li>
</ol>


## 5. Build `server.js`
<ol>
<li>
<details>
<summary>Add this code to your <code>server.js</code> file:</summary>

```js
/* Require modules
--------------------------------------------------------------- */
require('dotenv').config()
const path = require('path');
const express = require('express');
const livereload = require("livereload");
const connectLiveReload = require("connect-livereload");


/* Require the db connection, models, and seed data
--------------------------------------------------------------- */
const db = require('./models');


/* Create the Express app
--------------------------------------------------------------- */
const app = express();


/* Configure the app to refresh the browser when nodemon restarts
--------------------------------------------------------------- */
const liveReloadServer = livereload.createServer();
liveReloadServer.server.once("connection", () => {
    // wait for nodemon to fully restart before refreshing the page
    setTimeout(() => {
        liveReloadServer.refresh("/");
    }, 100);
});


/* Configure the app (app.set)
--------------------------------------------------------------- */
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


/* Middleware (app.use)
--------------------------------------------------------------- */
app.use(express.static('public'))
app.use(connectLiveReload());


/* Mount routes
--------------------------------------------------------------- */
app.get('/', function (req, res) {
    res.send('Furever Friends')
});


/* Tell the app to listen on the specified port
--------------------------------------------------------------- */
app.listen(process.env.PORT, function () {
    console.log('Express is listening to port', process.env.PORT);
});
```
</details>
</li>

<li>
<details>
<summary>Use <code>nodemon</code> to run your app. Your terminal output should look like this:</summary>

```bash
[nodemon] 2.0.21
[nodemon] to restart at any time, enter `rs`
[nodemon] watching path(s): *.*
[nodemon] watching extensions: js,mjs,json
[nodemon] starting `node server.js`
Express is listening to port 3000
Mongoose is connected to <whatever your connection string is>
```

When you open the browser up to `localhost:3000` you should see a simple message that says "Furever Friends"
</details>
</li>
</ol>


## 6. Create a `seed` Route
We've seen that its possible to seed your Mongo database by adding Mongoose methods to your `models/seed.js` file. Today we'll discover a new way to go about it. We'll create a route that when accessed by the browser, will execute Mongoose methods and seed your database.

<ol>
<li>
<details>
<summary>First, we need to create the seed data. In <code>models/seed.js</code> add the following:</summary>

```js
const pets = [
    {
        name: "Buddy",
        age: 2,
        breed: "Golden Retriever",
        species: "Dog",
        city: "New York",
        state: "NY",
        photo: "https://3.bp.blogspot.com/-AI2fhTCbWQ4/T26wCp9yk3I/AAAAAAAACTI/6O88_7A0txo/s1600/golden-retriever-picture.jpg",
        description: "Buddy is a friendly dog who loves to play fetch.",
        isFeatured: false,
        dateAdded: "2022-11-01T10:00:00.000Z"
    },
    {
        name: "Whiskers",
        age: 1,
        breed: "Siamese",
        species: "Cat",
        city: "Los Angeles",
        state: "CA",
        photo: "https://www.mystart.com/blog/wp-content/uploads/shutterstock_262571516-e1520615420194.jpg",
        description: "Whiskers is a playful cat who loves to nap in the sun.",
        isFeatured: false,
        dateAdded: "2022-11-03T10:00:00.000Z"
    },
    {
        name: "Max",
        age: 3,
        breed: "Labrador Retriever",
        species: "Dog",
        city: "Chicago",
        state: "IL",
        photo: "https://www.mybestfrienddogcare.co.uk/wp-content/uploads/2019/12/My-Best-Friend-64-scaled.jpg",
        description: "Max is a loyal and energetic dog who loves to run and play.",
        isFeatured: true,
        dateAdded: "2022-11-05T10:00:00.000Z"
    },
    {
        name: "Mittens",
        age: 1,
        breed: "Domestic Shorthair",
        species: "Cat",
        city: "Houston",
        state: "TX",
        photo: "https://cdn2-www.cattime.com/assets/uploads/gallery/european-shorthair-cat-breed-pictures/european-shorthair-cat-breed-pictures-8.jpg",
        description: "Mittens is a cuddly cat who loves to be petted.",
        isFeatured: false,
        dateAdded: "2022-11-07T10:00:00.000Z"
    },
    {
        name: "Rocky",
        age: 4,
        breed: "Boxer",
        species: "Dog",
        city: "New York",
        state: "NY",
        photo: "https://animalsbreeds.com/wp-content/uploads/2015/01/Boxer-3.jpg",
        description: "Rocky is a protective dog who loves to play with his toys.",
        isFeatured: true,
        dateAdded: "2022-11-09T10:00:00.000Z"
    },
    {
        name: "Milo",
        age: 2,
        breed: "Persian",
        species: "Cat",
        city: "Los Angeles",
        state: "CA",
        photo: "https://catcuddles.com/images/white-persian-cat.jpg",
        description: "Milo is a calm and curious cat who loves to explore.",
        isFeatured: false,
        dateAdded: "2022-11-11T10:00:00.000Z"
    },
    {
        name: "Daisy",
        age: 5,
        breed: "Beagle",
        species: "Dog",
        city: "Chicago",
        state: "IL",
        photo: "https://animalsbreeds.com/wp-content/uploads/2014/07/Beagle.jpg",
        description: "Daisy is a friendly and outgoing dog who loves to meet new people.",
        isFeatured: true,
        dateAdded: "2022-11-13T10:00:00.000Z"
    }
]

// Export the seed data to `models/index.js`
module.exports = pets
```
</details>
</li>

<li>
<details>
<summary>Access the seed data in <code>models/index.js</code>:</summary>

```js
// Export models and seed data to `server.js`
module.exports = {
    Pet: require('./pet'),
    seedPets: require('./seed')
}
```
</details>
</li>

<li>
<details>
<summary>Create the seed route in <code>server.js</code>:</summary>

```js
/* Mount routes
--------------------------------------------------------------- */
app.get('/', function (req, res) {
    res.send('Furever Friends')
});
// When a GET request is sent to `/seed`, the pets collection is seeded
app.get('/seed', function (req, res) {
    // Remove any existing pets
    db.Pet.deleteMany({})
        .then(removedPets => {
            console.log(`Removed ${removedPets.deletedCount} pets`)
            // Seed the pets collection with the seed data
            db.Pet.insertMany(db.seedPets)
                .then(addedPets => {
                    console.log(`Added ${addedPets.length} pets to be adopted`)
                    res.json(addedPets)
                })
        })
});
```

Now, when we naviagte to `localhost:3000/seed` in the browser, our database will be seeded and we'll recieve a JSON response of the newly created documents.
</details>
</li>
</ol>


## 7. Create the `pets` Controller
In order to keep our code organized, we can create a controller that will handle all routing for any URI that begins with `/pets`. We'll add several routes to this controller over the next few days, but for now we will just be adding an `index` and a `show` route.

<ol>
<li>
<details>
<summary>Add this code to <code>controllers/pets.js</code></summary>

```js
/* 
---------------------------------------------------------------------------------------
NOTE: Remember that all routes on this page are prefixed with `localhost:3000/pets`
---------------------------------------------------------------------------------------
*/


/* Require modules
--------------------------------------------------------------- */
const express = require('express')
const router = express.Router()


/* Require the db connection, and models
--------------------------------------------------------------- */
const db = require('../models')


/* Routes
--------------------------------------------------------------- */
// Index Route (GET/Read): Will display all pets
router.get('/', function (req, res) {
    db.Pet.find({})
        .then(pets => res.json(pets))
})


// Show Route (GET/Read): Will display an individual pet document
// using the URL parameter (which is the document _id)
router.get('/:id', function (req, res) {
    db.Pet.findById(req.params.id)
        .then(pet => res.json(pet))
        .catch(() => res.send('404 Error: Page Not Found'))
})


/* Export these routes so that they are accessible in `server.js`
--------------------------------------------------------------- */
module.exports = router
```
</details>
</li>

<li>Now we need to tell <code>server.js</code> to look in this file every time a <code>pets</code> route is hit.</li>

<li>
<details>
<summary>Near the top of <code>server.js</code>:</summary>

```js
/* Require the routes in the controllers folder
--------------------------------------------------------------- */
const petsCtrl = require('./controllers/pets')
```
</details>
</li>

<li>
<details>
<summary>Below the other routes in <code>server.js</code>:</summary>

```js
// This tells our app to look at the `controllers/pets.js` file 
// to handle all routes that begin with `localhost:3000/pets`
app.use('/pets', petsCtrl)
```
</details>
</li>
</ol>

Great! All our routes are now connected to the `server.js` file. We'll edit these routes to display EJS files in a bit, but first we need to configure our `package.json` file.


## 8. Configure `package.json` For Live Reload
When we initially set up our application, we installed `livereload` and `connect-livereload`. As mentioned, these will allow our application to auto-refresh the browser everytime `nodemon` reloads.

To get nodemon to restart when EJS or CSS files are modified we can add some arguments like this:
```bash
nodemon server.js -e css,ejs,js,json
```
The `-e` flag tells nodemon which file extensions to look out for to trigger a restart. By default, it looks out for `js` and `json` files. Here, we told it to also watch for `ejs` and `css` changes.

However, to avoid having to type this out and remember the extensions every time we run nodemon, we're going to create an NPM command in our `package.json` file. In the `scripts` object edit it to look like this:
```json
"scripts": {
    "test": "echo \"Error: no test specified\" && exit 1",
    "start": "node server.js",
    "dev": "nodemon server.js -e css,ejs,js,json"
  },
```

Now we can execute this command in the terminal to run nodemon with our custom configurations:
```bash
npm run dev
```
This tells npm to run the `dev` script we just made, which executes the `nodemon server.js -e css,ejs,js,json` command.


## 9. Build Views
Now that we've got our application all configured and routes built, it's time to build the views! 

### EJS Partials:
<ul>
<li>
<details>
<summary><code>head.ejs</code></summary>

```html
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><%= title %></title>
<link rel="stylesheet" href="/styles/main.css">
```
</details>
</li>

<li>
<details>
<summary><code>nav.ejs</code></summary>

```html
<header>
    <h1>Furever Friends</h1>
    <nav>
        <ul>
            <li><a href="/">Home</a></li>
            <li><a href="/pets">Adopt</a></li>
            <li><a href="#">My Applications</a></li>
        </ul>
    </nav>
</header>
```
</details>
</li>

<li>
<details>
<summary><code>footer.ejs</code></summary>

```html
<footer>
    <h2>&copy; 2023 Furever Friends</h2>
    <nav>
        <ul>
            <li><a href="/">Home</a></li>
            <li><a href="/pets">Adopt</a></li>
            <li><a href="#">My Applications</a></li>
        </ul>
    </nav>
</footer>
```
</details>
</li>
</ul>


### EJS Pages
<ul>
<li>
<details>
<summary><code>home.ejs</code></summary>

```html
<!DOCTYPE html>
<html lang="en">

<head>
    <%- include('./partials/head.ejs', {title: 'Furever Friends'}) %>
    <link rel="stylesheet" href="/styles/home.css">
</head>

<body>
    <%- include('./partials/nav.ejs') %>

    <main>
        <section class="hero">
            <h2>Find Your New Best Friend</h2>
            <a href="/pets" class="btn">Adopt Now!</a>
        </section>

        <section class="about">
            <h2>About Us</h2>
            <p>Furever Friends is a non-profit organization dedicated to finding loving homes for animals in need. We
                work with shelters and rescue groups across the country to help connect pets with their new families.
            </p>
            <a href="/about" class="btn">Learn More</a>
        </section>

        <section class="featured-pets">
            <h2>Featured Pets</h2>
            <ul class="pet-grid">
                <% for (let pet of pets) { %>
                <li>
                    <figure>
                        <img src="<%= pet.photo %>" alt="Kitten">
                    </figure>
                    <figcaption>
                        <div class="featured-info">
                            <h3><%= pet.name %></h3>
                            <p>Age: <%= pet.age %> yr(s)</p>
                        </div>
                        <a href="/pets/<%= pet._id %>" class="btn">Learn More</a>
                    </figcaption>
                </li>
                <% } %>
            </ul>
        </section>
    </main>

    <%- include('./partials/footer.ejs') %>
</body>

</html>
```
</details>
</li>

<li>
<details>
<summary><code>pet-index.ejs</code></summary>

```html
<!DOCTYPE html>
<html lang="en">

<head>
    <%- include('./partials/head.ejs', {title: 'Furever Friends'}) %>
    <link rel="stylesheet" href="/styles/pet-index.css">
</head>

<body>
    <%- include('./partials/nav.ejs') %>

    <section class="hero">
        <h2>Available Pets</h2>
        <h3>Will you be the forever home and provide love to one of these special animals?</h3>
    </section>

    <main>
        <section class="listings">
            <ul>
                <% for (let pet of pets) { %>
                <li>
                    <figure>
                        <img src="<%= pet.photo %>">
                        <figcaption>
                            <h4><%= pet.name %></h4>
                            <p><%= pet.breed %>, <%= pet.age %> year(s) old, <%= pet.state %></p>
                            <a href="/pets/<%= pet._id %>">Learn More</a>
                        </figcaption>
                    </figure>
                </li>
                <% } %>
            </ul>
        </section>
    </main>

    <%- include('./partials/footer.ejs') %>
</body>

</html>
```
</details>
</li>

<li>
<details>
<summary><code>pet-details.ejs</code></summary>

```html
<!DOCTYPE html>
<html lang="en">

<head>
    <%- include('./partials/head.ejs', {title: `${pet.name} | Furever Friends`}) %>
    <link rel="stylesheet" href="/styles/pet-details.css">
</head>

<body>
    <%- include('./partials/nav.ejs') %>

    <div>
        <img src="<%= pet.photo %>">
        <h2 class="pet-name"><%= pet.name %></h2>
        <section>
            <p><strong>Age:</strong> <%= pet.age %></p>
            <p><strong>Breed:</strong> <%= pet.breed %></p>
            <p><strong>Species:</strong> <%= pet.species %></p>
            <p><strong>Location:</strong> <%= `${pet.city}, ${pet.state}` %></p>
            <p><strong>Description:</strong> <%= pet.description %></p>
        </section>
    </div>

    <%- include('./partials/footer.ejs') %>
</body>

</html>
```
</details>
</li>
</ul>


## 10. Adding Styles - Static Assets
Now that we've built out the EJS files, let's add the CSS to our static assets.

<ul>
<li>
<details>
<summary><code>main.css</code></summary>

```css
/* Reset styles for cross-browser consistency */
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    scrollbar-color: #333;
    scrollbar-width: 10px;
}

*::-webkit-scrollbar {
    visibility: hidden;
    width: 10px;
}

*::-webkit-scrollbar-thumb {
    background-color: #333;
    border-radius: 2px;
}

/* General styles */
body {
    font-family: Arial, sans-serif;
    font-size: 16px;
    line-height: 1.5;
    color: #333;
    background-color: #f7f7f7;
    min-height: 100vh;
}

a {
    color: #333;
    text-decoration: none;
}

a:hover {
    text-decoration: underline;
}

/* Header styles */
header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #fff;
    padding: 1rem;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
}

h1 {
    font-size: 2.5rem;
}

h1 a:hover {
    text-decoration: none;
}

nav ul {
    display: flex;
    list-style: none;
}

nav li:not(:last-child) {
    margin-right: 1rem;
}

nav a {
    font-size: 1.2rem;
}

/* Hero section styles */
.hero {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    background-color: #e8f1f2;
    height: 40vh;
}

.hero h2 {
    font-size: 3rem;
    margin-bottom: 1rem;
    text-align: center;
}

.hero h3 {
    font-size: 2rem;
    text-align: center;
}

.hero h4 {
    font-size: 1.5rem;
    text-align: center;
}

.btn {
    display: inline-block;
    padding: 1rem 2rem;
    font-size: 1.2rem;
    background-color: #333;
    color: #fff;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.btn:hover {
    background-color: #555;
}

/* Footer styles */
footer {
    text-align: center;
    padding: 1rem;
    background-color: #333;
    width: calc(100vw - 1rem);
}

footer * {
    color: #fff;
}

footer ul {
    justify-content: center;
}
```
</details>
</li>

<li>
<details>
<summary><code>home.css</code></summary>

```css
/* About section styles */
.about {
    background-color: #fff;
    padding: 2rem;
}

.about h2 {
    font-size: 2rem;
    margin-bottom: 1rem;
}

.about p {
    margin-bottom: 1rem;
}

/* Featured pets section styles */
.featured-pets {
    background-color: #f7f7f7;
    padding: 2rem;
}

.featured-pets h2 {
    font-size: 2rem;
    margin-bottom: 1rem;
}

.pet-grid {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    list-style: none;
    margin-top: 2rem;
}

.pet-grid li {
    width: calc(33% - 1rem);
    min-width: 300px;
    margin-bottom: 2rem;
    background-color: #fff;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1);
    border-radius: 5px;
    overflow: hidden;
}

figure {
    height: 70%;
}

.pet-grid img {
    height: 100%;
    width: 100%;
    object-fit: cover;
}

figcaption {
    height: 30%;
    padding: 1rem 2rem 0 2rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.featured-info h3 {
    font-size: calc(1em + 0.5vw);
}

.featured-info p {
    font-size: calc(0.5rem + 0.5vw);
}
```
</details>
</li>

<li>
<details>
<summary><code>pet-index.css</code></summary>

```css
/* Main content styles */
main {
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

.listings {
    margin-top: 50px;
}

.listings h1 {
    margin-bottom: 20px;
    text-align: center;
}

.listings ul {
    list-style: none;
    padding: 0;
}

.listings li {
    margin-bottom: 40px;
    border: 2px solid #ccc;
    padding: 20px;
    border-radius: 4px;
    position: relative;
    text-align: center;
}

.listings li img {
    max-width: 100%;
    height: auto;
}

figcaption {
    text-align: left;
}

.listings li h4 {
    font-size: 24px;
    margin-bottom: 10px;
}

.listings li p {
    font-size: 16px;
    margin-bottom: 10px;
}

.listings li a {
    background-color: #333;
    color: #fff;
    font-size: 18px;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    position: absolute;
    bottom: 20px;
    right: 20px;
    text-decoration: none;
}

.listings li a:hover {
    background-color: #555;
}
```
</details>
</li>

<li>
<details>
<summary><code>pet-details.css</code></summary>

```css
div {
    max-width: 800px;
    margin: 0 auto;
    text-align: center;
    border: 1px solid #ccc;
    padding: 20px;
    margin: 4vh auto;
    box-shadow: 2px 2px 5px #ccc;
}

img {
    width: 60%;
    min-width: 300px;
    height: 30%;
    min-height: 150px;
    object-fit: cover;
    margin-bottom: 10px;
}

.pet-name {
    font-size: 32px;
    margin-bottom: 10px;
}

section {
    text-align: left;
    margin: 0 20%;
}

p {
    font-size: 18px;
    margin-bottom: 10px;
}

strong {
    font-weight: bold;
}

.featured {
    background-color: #ffd700;
}

/* Style Action Buttons */
.actions {
    margin-top: 1rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.btn a {
    color: #fff;
}
```
</details>
</li>
</ul>


## 11. Render the EJS files with Routes
Let's take a look at our views! Set up your routes to render the EJS files.

<ul>
<li>
<details>
<summary><code>server.js</code></summary>

```js
/* Mount routes
--------------------------------------------------------------- */
app.get('/', function (req, res) {
    db.Pet.find({ isFeatured: true })
        .then(pets => {
            res.render('home', {
                pets: pets
            })
        })
});
```
</details>
</li>

<li>
<details>
<summary><code>controllers/pets.js</code></summary>

```js
// Index Route (GET/Read): Will display all pets
router.get('/', function (req, res) {
    db.Pet.find({})
        .then(pets => {
            res.render('pet-index', {
                pets: pets
            })
        })
})

// Show Route (GET/Read): Will display an individual pet document
// using the URL parameter (which is the document _id)
router.get('/:id', function (req, res) {
    db.Pet.findById(req.params.id)
        .then(pet => {
            res.render('pet-details', {
                pet: pet
            })
        })
        .catch(() => res.send('404 Error: Page Not Found'))
})
```
</details>
</li>
</ul>

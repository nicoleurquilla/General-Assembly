# Furever Friends - MEN Stack Walkthrough
<img src="https://i.imgur.com/XVAEXF9.jpg" width="100%">


## The MEN Stack
Full stack apps are often referred to by abbreviations of the technologies used within the app. The app you'll build during this multi-part exercise is known as a MEN Stack app. The MEN stack is comprised of:
- **M**ongoDB/Mongoose
- **E**xpress.js
- **N**ode.js

This walkthrough can be split up across three days and pairs with the multi-part [Express Store deliverable](https://git.generalassemb.ly/SEIR-Phoenix/DLVR-Express-Store).

Refer to the solutions branch of this repo for the finished code for each part.


## Background
As a budding full-stack devloper, you've just got a new client that needs you to build their website! Your client is a pet adoption service that connects pet lovers across North America with pets in need of adoption.


## Create a Route Table
Let's create a route table that will define and describe what each route in our application will do:

|       **URL**   | **REST Route** | **HTTP Verb** | **CRUD Action** |   **EJS View(s)**   |
| --------------- | -------------- | ------------- | --------------- | ------------------- |
| /               |                | GET           | read            | home.ejs            |
| /pets           | index          | GET           | read            | pet-index.ejs       |
| /pets/:id       | show           | GET           | read            | pet-details.ejs     |
| /pets/new       | new            | GET           |                 | new-pet.ejs         |
| /pets           | create         | POST          | create          |                     |
| /pets/:id/edit  | edit           | GET           | read            | edit-pet.ejs        |
| /pets/:id       | update         | PATCH/PUT     | update          |                     |
| /pets/:id       | destroy        | DELETE        | delete          |                     |
| /seed           |                | GET           | delete & create |                     |
| /about          |                | GET           |                 | about.ejs           |
| /*              |                | GET           |                 | 404.ejs             |

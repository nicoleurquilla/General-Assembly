# MEN Stack - Part 2 (All Other RESTful Routes for Pets)
<img src="https://i.imgur.com/2ARbclT.png" width="100%"/>


## Background
Yesterday we learned about MVC architecture and REST APIs. We scaffolded our project, created our database, and built three routes. Now that we laid the groundwork, today we can focus on building the rest of routes and making our app full CRUD!


## Set Up
To get the code from where we left off yesterday, you can use the local copy of your code or you can you clone this repository. 

If you clone the repository make sure you open up VS Code in the correct folder:
```
cd Furever-Friends/part-2
code .
```

You'll also need to install all the dependencies. You can do this by running:
```
npm i
```

Make sure you edit the `MONGODBURI` environment variable so that it points to your `furever-friends` MongoDB Atlas database.


## 1. Update the Route Table
Let's update our route table from yesterday. We already have a `home`, `index`, and `show` route.

|       **URL**   | **REST Route** | **HTTP Verb** | **CRUD Action** |   **EJS View(s)**   | **Created Yet?**  |
| --------------- | -------------- | ------------- | --------------- | ------------------- | ----------------- |
| /               |                | GET           | read            | home.ejs            | YES               |
| /pets           | index          | GET           | read            | pet-index.ejs       | YES               |
| /pets/:id       | show           | GET           | read            | pet-details.ejs     | YES               |
| /pets/new       | new            | GET           |                 | new-pet.ejs         | NO                |
| /pets           | create         | POST          | create          |                     | NO                |
| /pets/:id/edit  | edit           | GET           | read            | edit-pet.ejs        | NO                |
| /pets/:id       | update         | PATCH/PUT     | update          |                     | NO                |
| /pets/:id       | destroy        | DELETE        | delete          |                     | NO                |
| /seed           |                | GET           | delete & create |                     | YES               |
| /about          |                | GET           |                 | about.ejs           | NO                |
| /*              |                | GET           |                 | 404.ejs             | NO                |


## 2. Add Body Parser Middleware
When making `POST/PUT/PATCH` HTTP requests, the **request body** will define what data is getting created or edited. In Express, similar to how the `request` object has a `params` object, it also has a `body` object. The key value pairs from a body object are typically created using an HTML form. When we build our *new* and *edit* forms we''ll see how the input fields and values build that object. 
Postman allows us to send requests with body objects without needing to build an HTML form, so it expedites route testing.

However, to use Postman or a regular HTML form, it is important to tell Express how to parse the `request.body` object. We can can do that by using some native body parser middleware. Add teh following to `server.js` beneath the other middleware:
```js
// Body parser: used for POST/PUT/PATCH routes: 
// this will take incoming strings from the body that are URL encoded and parse them 
// into an object that can be accessed in the request parameter as a property called body (req.body).
app.use(express.urlencoded({ extended: true }));
```

If you'd like to learn more about the HTTP request body, you can refer to [this link](https://greenbytes.de/tech/webdav/draft-ietf-httpbis-p1-messaging-26.html#rfc.section.3.3).


## 3. Build the Remaining Routes
Typically when you build an Express app, the first step is to build *all* of your routes before working on any views/CSS. Our newly installed tool, Postman, will help us test our routes without us needing to build out forms or views first.

<ol>
<li>
<details>
<summary><strong>REST: New route</strong></summary>

In `controllers/pets.js`:
```js
// New Route (GET/Read): This route renders a form 
// which the user will fill out to POST (create) a new location
router.get('/new', (req, res) => {
    res.send('You\'ve hit the new route!')
})
```

**IMPORTANT NOTE:** Make sure this route is placed above your show route, otherwise it will not run! JavaScript will think that `/new` is a value for `/:id` and runt he show route if it is above the new route.

Test this route in Postman to see if it works.
</details>
</li>

<li>
<details>
<summary><strong>REST: Create route</strong></summary>

In `controllers/pets.js`:
```js
// Create Route (POST/Create): This route receives the POST request sent from the new route,
// creates a new pet document using the form data, 
// and redirects the user to the new pet's show page
router.post('/', (req, res) => {
    db.Pet.create(req.body)
        .then(pet => res.json(pet))
})
```
Notice how this route is similar to the index route, but rather than running on `GET` request it will run on `POST` requests.

When testing this out in Postman, make sure of the following: 
- You're making a `POST` request and not a `GET` request.
- You've added a `x-www-form-urlencoded` body whose key-value pairs match your data validation in the Mongoose pet schema (i.e. It includes required fields, respects minimum values, etc.)
</details>
</li>

<li>
<details>
<summary><strong>REST: Edit route</strong></summary>

In `controllers/pets.js`:
```js
// Edit Route (GET/Read): This route renders a form
// the user will use to PUT (edit) properties of an existing pet
router.get('/:id/edit', (req, res) => {
    db.Pet.findById(req.params.id)
        .then(pet => res.send('You\'ll be editing pet ' + pet._id))
})
```

When testing this out in Postman, make sure you've included an id for the URL parameter.
</details>
</li>

<li>
<details>
<summary><strong>REST: Update route</strong></summary>

In `controllers/pets.js`:
```js
// Update Route (PUT/Update): This route receives the PUT request sent from the edit route, 
// edits the specified pet document using the form data,
// and redirects the user back to the show page for the updated location.
router.put('/:id', (req, res) => {
    db.Pet.findByIdAndUpdate(
        req.params.id,
        req.body,
        { new: true }
    )
        .then(pet => res.json(pet))
})
```

When testing this out in Postman, make sure of the following:
- You're making a `PUT` request and not a `GET` request.
- You've added a `x-www-form-urlencoded` body whose key-value pairs match your data validation in the Mongoose pet schema (i.e. It includes required fields, respects minimum values, etc.)
- You've included an id for the URL parameter
</details>
</li>

<li>
<details>
<summary><strong>REST: Destroy route</strong></summary>

In `controllers/pets.js`:
```js
// Destroy Route (DELETE/Delete): This route deletes a pet document 
// using the URL parameter (which will always be the pet document's ID)
router.delete('/:id', (req, res) => {
    db.Pet.findByIdAndDelete(req.params.id)
        .then(pet => res.send('You\'ve deleted pet ' + pet._id))
})
```

Test this route in Postman and check the index route to see if the specified pet was deleted. Make sure you've included an id for the URL parameter
</details>
</li>

<li>
<details>
<summary><strong>Non-REST: About route</strong></summary>

In `server.js`:
```js
app.get('/about', function (req, res) {
    res.send('You\'ve hit the about route')
});
```

Test this route in Postman to see if it works.
</details>
</li>

<li>
<details>
<summary><strong>Non-REST: Catch-all route</strong></summary>

In `server.js`:
```js
// The "catch-all" route: Runs for any other URL that doesn't match the above routes
app.get('*', function (req, res) {
    res.send('404 Error: Page Not Found')
});
```

**IMPORTANT NOTE:** Make sure this route is placed below all other routes! It matches every possible URL pattern, so it must come last in order to allow JavaScript to check all the other URL patterns first.

Test this route in Postman to see if it works.
</details>
</li>
</ol>

We've now built all our routes! Postman is a very useful tool to test out routes that require paramaters, request bodies, and more without us needing to build out HTML that captures that data. You'll see below how it would be much more complex to try and debug a route after building out its HMTL form.


## 4. Build Views
Now that we've built out the back-end functionality of our routes, we can create and render views for them.

### Non-REST Views
Let's first create the more simple, non-REST views for Furever Friends.

<ul>
<li>
<details>
<summary><code>about.ejs</code></summary>

Create a file in `views` called `about.ejs` with this code:
```html
<!DOCTYPE html>
<html lang="en">

<head>
    <%- include('./partials/head.ejs', {title: `About Furever Friends`}) %>
    <link rel="stylesheet" href="/styles/about.css">
</head>

<body>
    <%- include('./partials/nav.ejs') %>

    <main>
        <section class="hero">
            <h2>About Us</h2>
            <h4><i>Helping pets find their happily ever after, one adoption at a time</i></h4>
        </section>

        <section class="content">
            <h2>Our Mission</h2>
            <p>Furever Friends is a non-profit organization dedicated to rescuing and finding homes for pets in need.
                Our
                mission is to create a world where every pet has a loving and permanent home. We believe that every pet
                deserves to be loved and cared for, and we work tirelessly to make that a reality.</p>
            <p>At Furever Friends, we understand the importance of finding the perfect match between a pet and their new
                family. We take the time to get to know each pet in our care, including their personality, behavior, and
                any
                special needs they may have. We also carefully screen and interview potential adopters to ensure that
                they
                are committed to providing a loving and responsible home for their new pet.</p>
            <p>We are proud to have found homes for thousands of pets over the years, and we will continue to work
                tirelessly to rescue and find homes for pets in need.</p>
            <h2>Our Values</h2>
            <ul>
                <li>Compassion: We believe in treating all animals with kindness and respect.</li>
                <li>Responsibility: We are committed to providing the highest standard of care for every pet in our
                    care.
                </li>
                <li>Integrity: We operate with transparency and honesty in all of our interactions with our community.
                </li>
                <li>Collaboration: We believe that working together with our community is the key to achieving our
                    mission.
                </li>
            </ul>
        </section>
    </main>

    <%- include('./partials/footer.ejs') %>
</body>

</html>
```
</details>
</li>

<li>
<details>
<summary><code>404.ejs</code></summary>

Create a file in `views` called `404.ejs` with this code:
```html
<!DOCTYPE html>
<html lang="en">

<head>
    <%- include('./partials/head.ejs', {title: 'Furever Friends'}) %>
    <link rel="stylesheet" href="/styles/404.css">
</head>

<body>
    <div class="glassy">
        <h1>Page Not Found</h1>
        <p>Sorry, the page you're looking for cannot be found.</p>
        <a href="/">Go to Furever Friends Homepage</a>
    </div>
</body>

</html>
```
</details>
</li>
</ul>


### REST Views
Now let's create the Edit and New forms! 

HTML forms are designed to capture the data in the form, attach it to the request body, and then make a `GET` or `POST` request. Since we're going to be using a form to update and delete data, we need to install an NPM package called `method-override`. This will allow us to attach a query string to the URL that the HTML form makes a `POST` request to, and intercept it and convert it into a `PUT`, `PATCH`, or `DELETE` request.

Run this command in the terminal to install method-override:
```
npm i method-override
```

Now add the method-override package to `server.js`:
```js
const methodOverride = require('method-override');
```

Next we add method-override middleware that will watch for any requests that have a URL query string like `?_method=<HTTP method here>`:
```js
// Allows us to interpret POST requests from the browser as another request type: DELETE, PUT, etc.
app.use(methodOverride('_method'));
```

Now that we have method-override set up, we can create our forms! The `<input>` elements' `name` attribute will become the keys for our `request.body` object, and the input value will become the value for the respective key in the `request.body` object.


<ul>
<li>
<details>
<summary><code>new-form.ejs</code></summary>

Create a file in `views` called `new-form.ejs` with this code:
```html
<!DOCTYPE html>
<html lang="en">

<head>
    <%- include('./partials/head.ejs', {title: 'Add a Listing | Furever Friends'}) %>
    <link rel="stylesheet" href="/styles/pet-form.css">
</head>

<body>
    <%- include('./partials/nav.ejs') %>

    <section class="hero">
        <h2>Create a Listing</h2>
        <h4><i>Helping pets find their happily ever after, one adoption at a time</i></h4>
    </section>

    <form method="POST" action="/pets">
        <!-- Name input -->
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>
        <br>
        <!-- Age input -->
        <label for="age">Age:</label>
        <input type="number" id="age" name="age" min="0" required>
        <br>
        <!-- Breed input -->
        <label for="breed">Breed:</label>
        <input type="text" id="breed" name="breed" value="Unknown">
        <br>
        <!-- Species input -->
        <label for="species">Species:</label>
        <select id="species" name="species" required>
            <option value="Dog">Dog</option>
            <option value="Cat">Cat</option>
        </select>
        <br>
        <!-- City input -->
        <label for="city">City:</label>
        <input type="text" id="city" name="city" required>
        <br>
        <!-- State input -->
        <label for="state">State or province:</label>
        <select id="state" name="state">
            <optgroup label="United States">
                <option value="AL">Alabama</option>
                <option value="AK">Alaska</option>
                <option value="AZ">Arizona</option>
                <option value="AR">Arkansas</option>
                <option value="CA">California</option>
                <option value="CO">Colorado</option>
                <option value="CT">Connecticut</option>
                <option value="DE">Delaware</option>
                <option value="DC">District of Columbia</option>
                <option value="FL">Florida</option>
                <option value="GA">Georgia</option>
                <option value="HI">Hawaii</option>
                <option value="ID">Idaho</option>
                <option value="IL">Illinois</option>
                <option value="IN">Indiana</option>
                <option value="IA">Iowa</option>
                <option value="KS">Kansas</option>
                <option value="KY">Kentucky</option>
                <option value="LA">Louisiana</option>
                <option value="ME">Maine</option>
                <option value="MD">Maryland</option>
                <option value="MA">Massachusetts</option>
                <option value="MI">Michigan</option>
                <option value="MN">Minnesota</option>
                <option value="MS">Mississippi</option>
                <option value="MO">Missouri</option>
                <option value="MT">Montana</option>
                <option value="NE">Nebraska</option>
                <option value="NV">Nevada</option>
                <option value="NH">New Hampshire</option>
                <option value="NJ">New Jersey</option>
                <option value="NM">New Mexico</option>
                <option value="NY">New York</option>
                <option value="NC">North Carolina</option>
                <option value="ND">North Dakota</option>
                <option value="OH">Ohio</option>
                <option value="OK">Oklahoma</option>
                <option value="OR">Oregon</option>
                <option value="PA">Pennsylvania</option>
                <option value="RI">Rhode Island</option>
                <option value="SC">South Carolina</option>
                <option value="SD">South Dakota</option>
                <option value="TN">Tennessee</option>
                <option value="TX">Texas</option>
                <option value="UT">Utah</option>
                <option value="VT">Vermont</option>
                <option value="VA">Virginia</option>
                <option value="WA">Washington</option>
                <option value="WV">West Virginia</option>
                <option value="WI">Wisconsin</option>
                <option value="WY">Wyoming</option>
            </optgroup>
            <optgroup label="Canada">
                <option value="AB">Alberta</option>
                <option value="BC">British Columbia</option>
                <option value="MB">Manitoba</option>
                <option value="NB">New Brunswick</option>
                <option value="NL">Newfoundland and Labrador</option>
                <option value="NS">Nova Scotia</option>
                <option value="ON">Ontario</option>
                <option value="PE">Prince Edward Island</option>
                <option value="QC">Quebec</option>
                <option value="SK">Saskatchewan</option>
                <option value="NT">Northwest Territories</option>
                <option value="NU">Nunavut</option>
                <option value="YT">Yukon</option>
            </optgroup>
        </select>
        <br>
        <!-- Photo input -->
        <label for="photo">Photo (URL):</label>
        <input type="text" id="photo" name="photo" required>
        <br>
        <!-- Description input -->
        <label for="description">Description:</label>
        <textarea id="description" name="description" required></textarea>
        <br>
        <input type="submit" value="Create Pet">
    </form>

    <%- include('./partials/footer.ejs') %>
</body>

</html>
```
</details>
</li>

<li>
<details>
<summary><code>edit-form.ejs</code></summary>

Create a file in `views` called `edit-form.ejs` with this code:
```html
<!DOCTYPE html>
<html lang="en">

<head>
    <%- include('./partials/head.ejs', {title: `Edit ${pet.name} | Furever Friends`}) %>
    <link rel="stylesheet" href="/styles/pet-form.css">
</head>

<body>
    <%- include('./partials/nav.ejs') %>

    <section class="hero">
        <h2>Edit a Listing</h2>
        <h4><i>Helping pets find their happily ever after, one adoption at a time</i></h4>
    </section>

    <form method="POST" action="/pets/<%= pet._id %>?_method=PUT">
        <!-- Name input -->
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<%= pet.name %>" required>
        <br>
        <!-- Age input -->
        <label for="age">Age:</label>
        <input type="number" id="age" name="age" min="0" value="<%= pet.age %>" required>
        <br>
        <!-- Breed input -->
        <label for="breed">Breed:</label>
        <input type="text" id="breed" name="breed" value="<%= pet.breed %>">
        <br>
        <!-- Species input -->
        <label for="species">Species:</label>
        <select id="species" name="species" required>
            <% if (pet.species === "Dog") { %>
            <option value="Dog" selected>Dog</option>
            <option value="Cat">Cat</option>
            <% } else { %>
            <option value="Dog">Dog</option>
            <option value="Cat" selected>Cat</option>
            <% } %>
        </select>
        <br>
        <!-- City input -->
        <label for="city">City:</label>
        <input type="text" id="city" name="city" value="<%= pet.city %>" required>
        <br>
        <!-- State input -->
        <label for="state">State or province:</label>
        <select id="state" name="state">
            <optgroup label="United States">
                <option value="AL">Alabama</option>
                <option value="AK">Alaska</option>
                <option value="AZ">Arizona</option>
                <option value="AR">Arkansas</option>
                <option value="CA">California</option>
                <option value="CO">Colorado</option>
                <option value="CT">Connecticut</option>
                <option value="DE">Delaware</option>
                <option value="DC">District of Columbia</option>
                <option value="FL">Florida</option>
                <option value="GA">Georgia</option>
                <option value="HI">Hawaii</option>
                <option value="ID">Idaho</option>
                <option value="IL">Illinois</option>
                <option value="IN">Indiana</option>
                <option value="IA">Iowa</option>
                <option value="KS">Kansas</option>
                <option value="KY">Kentucky</option>
                <option value="LA">Louisiana</option>
                <option value="ME">Maine</option>
                <option value="MD">Maryland</option>
                <option value="MA">Massachusetts</option>
                <option value="MI">Michigan</option>
                <option value="MN">Minnesota</option>
                <option value="MS">Mississippi</option>
                <option value="MO">Missouri</option>
                <option value="MT">Montana</option>
                <option value="NE">Nebraska</option>
                <option value="NV">Nevada</option>
                <option value="NH">New Hampshire</option>
                <option value="NJ">New Jersey</option>
                <option value="NM">New Mexico</option>
                <option value="NY">New York</option>
                <option value="NC">North Carolina</option>
                <option value="ND">North Dakota</option>
                <option value="OH">Ohio</option>
                <option value="OK">Oklahoma</option>
                <option value="OR">Oregon</option>
                <option value="PA">Pennsylvania</option>
                <option value="RI">Rhode Island</option>
                <option value="SC">South Carolina</option>
                <option value="SD">South Dakota</option>
                <option value="TN">Tennessee</option>
                <option value="TX">Texas</option>
                <option value="UT">Utah</option>
                <option value="VT">Vermont</option>
                <option value="VA">Virginia</option>
                <option value="WA">Washington</option>
                <option value="WV">West Virginia</option>
                <option value="WI">Wisconsin</option>
                <option value="WY">Wyoming</option>
            </optgroup>
            <optgroup label="Canada">
                <option value="AB">Alberta</option>
                <option value="BC">British Columbia</option>
                <option value="MB">Manitoba</option>
                <option value="NB">New Brunswick</option>
                <option value="NL">Newfoundland and Labrador</option>
                <option value="NS">Nova Scotia</option>
                <option value="ON">Ontario</option>
                <option value="PE">Prince Edward Island</option>
                <option value="QC">Quebec</option>
                <option value="SK">Saskatchewan</option>
                <option value="NT">Northwest Territories</option>
                <option value="NU">Nunavut</option>
                <option value="YT">Yukon</option>
            </optgroup>
        </select>
        <br>
        <!-- Photo input -->
        <label for="photo">Photo (URL):</label>
        <input type="text" id="photo" name="photo" value="<%= pet.photo %>" required>
        <br>
        <!-- Description input -->
        <label for="description">Description:</label>
        <textarea id="description" name="description" required><%= pet.description %></textarea>
        <br>
        <input type="submit" value="Edit Pet">
    </form>

    <%- include('./partials/footer.ejs') %>
</body>

</html>
```
</details>
</li>

<li>
<details>
<summary><code>pet-details.ejs</code></summary>

Add this element inside the `div` in `pet-details.ejs`:
```html
<section class="actions">
    <button class="btn"><a href="/pets/<%= pet._id %>/edit">Edit</a></button>
    <form method="POST" action="/pets/<%= pet._id %>?_method=DELETE">
        <input class="btn" type="submit" value="Delete" />
    </form>
</section>
```
</details>
</li>
</ul>


## 5. Adding Styles - Static Assets
<ul>
<li>
<details>
<summary><code>about.css</code></summary>

Create a file in `public/styles` called `about.css` with this code:
```css
/* Center the main content */
main {
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
    background-color: white;
}

/* Style the content section */
.content {
    margin-top: 50px;
    line-height: 1.5;
}

.content h2 {
    font-size: 36px;
    margin-bottom: 20px;
}

.content p {
    margin-bottom: 20px;
}

.content ul {
    list-style-type: none;
    margin-left: 0;
    padding-left: 0;
}

.content li:before {
    content: "✓ ";
    color: #004080;
    font-weight: bold;
    margin-right: 10px;
}
```
</details>
</li>

<li>

<details>
<summary><code>404.css</code></summary>

Create a file in `public/styles` called `404.css` with this code:
```css
body {
    background: url(../assets/404.png) no-repeat center center fixed;
    background-size: cover;
    display: flex;
    justify-content: center;
    align-items: center;
}

.glassy {
    text-align: center;
    background-color: rgba(255, 255, 255, 0.5);
    padding: 3rem;
    backdrop-filter: blur(5px);
    border-radius: 2rem;
    height: 90vh;
    width: 60vw;
    min-height: 300px;
    min-width: 300px;
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    align-items: center;
}

h1 {
    font-size: calc(36px + 2vw);
}

p,
a {
    font-size: calc(20px + 0.5vw);
    text-decoration: none;
    margin-top: 2rem;
}

a {
    margin-top: auto;
}
```
</details>
</li>

<li>
<details>
<summary><code>pet-form.css</code></summary>

Create a file in `public/styles` called `pet-form.css` with this code:
```css
.hero {
    height: 20vh;
    min-height: 175px;
    margin-bottom: 2rem;
}

form {
    width: 60%;
    min-width: 300px;
    margin: 0 auto 2rem auto;
}

label {
    display: inline-block;
    margin-bottom: 5px;
    font-weight: bold;
}

input[type="text"],
input[type="number"],
input[type="email"],
input[type="tel"],
textarea,
select {
    width: 100%;
    padding: 10px;
    margin-bottom: 20px;
    border-radius: 5px;
    border: 1px solid #ccc;
    box-sizing: border-box;
}

textarea {
    height: 100px;
}

input[type="submit"] {
    background-color: #333;
    color: #fff;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    transition: all 0.3s ease;
}

input[type="submit"]:hover {
    background-color: #fff;
    color: #333;
    border: 1px solid #333;
}
```
</details>
</li>
</ul>


## 6. You Do: Render the EJS files with Routes
1. Look through the routes that we've created and determine which routes will render EJS files, and which routes will redirect the user to a different page.
    - What will the new route render or redirect to?
    - What will the create route render or redirect to?
    - You can refer to the route table for help
1. Currently, we have no link to the new route. Where would be a good place to create this link?


## Bonus
The `edit-pet.ejs` file currently renders the form with pre-poulated values. However, the State/Province `select` element does not. How could you keep your code DRY and conditionally assign a `selected` attribute to the option that represents the pet's current State/Province?

# CLI Fundamentals
<p align="center"><kbd><img src="https://i.imgur.com/dZTqU21.png" width="90%" /></kbd</p>


## What is the CLI?
The Command Line Interface (CLI) is a text-based interface used to interact with a computer's operating system. Unlike graphical user interfaces (GUIs) that rely on visual elements and mouse interactions, the CLI allows users to execute commands by typing text-based instructions. It provides a direct and efficient way to interact with a computer, perform various tasks, and manage files and programs.

The CLI is incredibly important, especially for developers and system administrators, because it offers powerful control and flexibility over a computer's operations. The CLI enables automation, scripting, and batch processing, making it ideal for repetitive tasks and managing large-scale systems. It also provides a consistent interface across different operating systems, allowing users to leverage their skills on various platforms. 

Learning the CLI is a valuable skill as it enhances productivity, enables deeper system understanding, and empowers users to perform advanced tasks efficiently!


## Lessons
1. [CLI Intro](./Lessons/1.%20CLI%20Intro.md)


## Labs
1. [Star Wars Episode X](./Labs/Star%20Wars%20Episode%20X.md)


## Cheatsheet
![Commands Cheatsheet](https://i.imgur.com/vzEiEAp.png)

![Shortcuts Cheatsheet](https://i.imgur.com/ayjGekf.png)


## Licensing
1. All content is licensed under a CC­BY­NC­SA 4.0 license.
2. All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.

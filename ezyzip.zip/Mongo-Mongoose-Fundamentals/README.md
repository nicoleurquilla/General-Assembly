# Mongo & Mongoose Fundamentals
<img src="https://i.imgur.com/dlp1j0Q.png" width="100%">


## What is MongoDB?
MongoDB is a popular database that is designed to handle large amounts of unstructured or semi-structure data, making it highly scalable and efficient for modern applications. MongoDB provides a simple yet powerful way to store, retrieve, and manipulate data. It's data is stored in BSON (Binary JSON), which is familiar to JS objects and therefore more beginner friendly than SQL databases.


## What is Mongoose?
Mongoose is an Object-Data Mapping (ODM) library for MongoDB, which simplifies the interaction with MongoDB by providing a straightforward way to define models, schemas, and relationships between data. Mongoose acts as a bridge between your application and the MongoDB database, allowing you to define schemas to enforce data structure and validation rules.


## How Do They Work Together?
By combining MongoDB and Mongoose, developers can build scalable and flexible applications that can handle a variety of data types and scale as the application grows. MongoDB provides the database backend with its high-performance and scalable nature, while Mongoose adds a layer of convenience and structure to work with MongoDB in a more organized and intuitive way.


## Lessons
1. [Getting Set Up with MongoDB Atlas](./Lessons/1.%20Set%20Up%20MongoDB%20Atlas.md)
1. [Intro to MongoDB](./Lessons/2.%20Intro%20to%20MongoDB.md)
1. [CRUD with Mongosh](./Lessons/3.%20CRUD%20with%20Mongosh.md)
1. [Atomic Operators](./Lessons/4.%20Atomic%20Operators.md)
1. [Intro to Mongoose](./Lessons/5.%20Intro%20to%20Mongoose.md)
1. [Mongoose Relationships](./Lessons/6.%20Mongoose%20Relationships.md)


## Labs
1. [Intergalactic Bounty Hunters](./Labs/1.%20Intergalactic%20Bounty%20Hunters.md)


## Licensing
1. All content is licensed under a CC­BY­NC­SA 4.0 license.
2. All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.

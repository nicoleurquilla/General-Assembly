/* Require the db connection and models
--------------------------------------------------------------- */
const db = require('./models');
const restaurant = require('./models/restaurant');


/* CRUD Operations
--------------------------------------------------------------- */
// Create a user
// db.User.create({ name: 'Jane Smith' })
//     .then(user => console.log(user))

// // Create a restaurant
// db.Restaurant.create({
//     name: 'Jurassic Tacos',
//     cuisine: 'street tacos'
// })
//     .then(restaurant => console.log(restaurant))

// Create a review
// db.Restaurant.findByIdAndUpdate(
//     '659d6016170c324cec34234e',
//     {
//         $push: {
//             reviews: {
//                 title: 'Fake street tacos',
//                 content: 'Not as good as the real thing, have lots of weird kinds of tacos.',
//                 reviewer: '659d6016170c324cec34234d'
//             }
//         }
//     },
//     { new: true }
// )
//     .then(restaurant => console.log(restaurant))

// Create another user
// db.User.create({ name: 'Sisi Suzuki' })
//     .then(user => console.log(user))

// Create another restaurant
// db.Restaurant.create({
//     name: 'Astro Burger',
//     cuisine: 'fast food'
// })
//     .then(restaurant => console.log(restaurant))

// Jane Smith reviews Astro Burger
// db.Restaurant.findByIdAndUpdate(
//     '659d67f8f215b1f08fbc4caf', // Astro Burger ID
//     {
//         $push: {
//             reviews: {
//                 title: 'Excellent food',
//                 content: 'Best burger ever. Get the Texas Bacon Cheeseburger',
//                 reviewer: '659d6016170c324cec34234d' // Jane Smith ID
//             }
//         }
//     },
//     { new: true }
// )
//     .then(() => console.log('Jane Smith left a review for Astro Burger'))

// Sisi Suzuki reviews Astro Burger
// db.Restaurant.findByIdAndUpdate(
//     '659d67f8f215b1f08fbc4caf', // Astro Burger ID
//     {
//         $push: {
//             reviews: {
//                 title: 'Decent food, great shakes',
//                 content: 'Huge fan of the shakes, definitely my new go-to shake stop.',
//                 reviewer: '659d67f8f215b1f08fbc4cae' // Sisi Suzuki ID
//             }
//         }
//     },
//     { new: true }
// )
//     .then(() => console.log('Sisi Suzuki left a review for Astro Burger'))

// Sisi Suzuki reviews Jurassic Tacos
// db.Restaurant.findByIdAndUpdate(
//     '659d6016170c324cec34234e', // Jurassic Taco ID
//     {
//         $push: {
//             reviews: {
//                 title: 'Fun atmosphere',
//                 content: 'Really enjoy the ambiance and busy nature of the place',
//                 reviewer: '659d67f8f215b1f08fbc4cae' // Sisi Suzuki ID
//             }
//         }
//     },
//     { new: true }
// )
//     .then(() => console.log('Sisi Suzuki left a review for Jurassic Tacos'))


// Read a review
// db.Restaurant.find({})
//     .then(restaurants => {
//         const flatList = []
//         for (let restaurant of restaurants) {
//             flatList.push(...restaurant.reviews)
//         }
//         console.log(flatList)
//     })

// db.Restaurant.findById(
//     '659d6016170c324cec34234e', // Jurassic Taco ID
//     { name: true, reviews: true, _id: false }
// )
//     .then(reviews => console.log(reviews))

// db.Restaurant.find(
//     {
//         'reviews.reviewer': '659d67f8f215b1f08fbc4cae' // Sisi Suzuki ID
//     },
//     { 'reviews.$': true, _id: false }
// )
//     .then(restaurants => {
//         // format query results to appear in one array,
//         // rather than an array of objects containing arrays
//         const flatList = []
//         for (let restaurant of restaurants) {
//             flatList.push(...restaurant.reviews)
//         }
//         console.log(flatList)
//     })

// db.Restaurant.findOne(
//     {
//         'reviews._id': '659d62e221b237e46d414b24' // Jane Smith's Jurassic Taco review
//     },
//     { 'reviews.$': true, _id: false }
// )
//     .then(restaurant => {
//         // format query results to appear in one object,
//         // rather than an object containing an array of one object
//         console.log(restaurant.reviews[0])
//     })

// Update a specific review
// db.Restaurant.findOneAndUpdate(
//     {
//         'reviews._id': '659d62e221b237e46d414b24' // Jane Smith's Jurassic Taco review
//     },
//     {
//         $set: {
//             'reviews.$.title': 'Okay food',
//             'reviews.$.content': 'The food is alright, but isn\'t accurately advertised'
//         }
//     },
//     { new: true },
//     { 'reviews.$': true, _id: false }
// )
//     .then(restaurant => {
//         // format query results to appear in one object,
//         // rather than an object containing an array of one object
//         console.log(restaurant.reviews[0])
//     })

// Delete a review
db.Restaurant.findOneAndUpdate(
    {
        'reviews._id': '659d68a33f128ce71a672cc9' // Sisi Suzuki's Astro Burger review
    },
    {
        $pull: {
            reviews: { _id: '659d68a33f128ce71a672cc9' }
        }
    },
    { new: true }
)
    .then(restaurant => console.log(restaurant))
// Require the Mongoose package and reviewSchema
const mongoose = require('mongoose')
const reviewSchema = require('./review.js')

// Create a schema to define the properties of the restaurants collection
const restaurantSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
        },
        cuisine: {
            type: String,
            required: true,
        },
        // the reviews array can only accept objects that match the criteria specified
        // in the reviewSchema. In other words, the reviews array can only accept reviews
        reviews: [reviewSchema]
    },
    { timestamps: true }
);

// Export the schema as a Mongoose model. 
// The Mongoose model will be accessed in `models/index.js`
module.exports = mongoose.model('Restaurant', restaurantSchema);

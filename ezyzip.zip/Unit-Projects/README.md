<img width="100%" src="https://i.imgur.com/CYx9Es5.png" />


# How to Use this Repo
This repository will be the hub of the project lifecycle each unit. Make sure to refer back to it frequently and to carefully read all instructions on issue templates, project markdowns, and elsewhere.


## Unit Project Folders
At the root of this repo are 4 unit project folders that each will contain a README of instructions for the respective project as well as a gallery of student work that will be updated following project presentations. Additionally, each folder contains the rubric that will be used to score your project.

Some unit project folders (such as Unit 3) may contain additional markdowns that will serve to aid you in the development process.


## Project READMEs
Located inside each unit project folder, you'll find a README that breaks down the expectations for that unit's project. Not only does a README describe what the project will be, but it contains a checklist of criteria and a timeline of deliverables that you will need to meet. As you're working on a unit project, refer to the criteria daily to ensure you are on track to meet all requirements & deliverables.


## [Issue Templates](https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/issues/new/choose)
Unlike the other repositories in this cohort's GitHub organization, this repo has an [`issues` tab](https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/issues). Throughout each project week, you will create a new issue in order to submit the following:
- **Project proposals**: this contains your proposed plan for your project including wireframes (mockups), user stories, and goals. A member of the instructional team will aprrove or deny your proposal.
- **Project troubleshooting**: each one of these issue types will cost you a metaphorical "token" that you have a limited number of for every project. This issue is to be used for debugging purposes only. When you submit this issue, your pod leader will typically reach out to you and set a time to meet. Please note that all conceptual questions are free of charge and can be asked in the parking-lot channel or in standups.
- **Project submissions**: this will contain a link to your completed project's GitHub repo and live site. A member of the instructional team will close the issue and mark it as "graded" once they have finsihed scoring your project.


## Project Galleries
Following each of the presentations for each unit project, you will be able to refer to each unit project folder for a gallery of student projects, where you can view students' deployed sites, project repos, and Zoom recordings. 

These will be a great resource to turn to for ideas for future projects in later units and after the conclusion of the cohort. Additionally, the project galleries will serve as a yearbook of sorts to see you and your fellow classmates' growth throughout the cohort.


# Recurring Instructions For Each Unit Project
## Project Week Format
- No daily attendance on Zoom required **except for [daily stand up](https://geekbot.com/blog/daily-standup-meeting/)**. If you’re absent for a daily standup that will count as a full day absence, so please show up!
- You **are required** to be responsive on Slack to any instructor messages.
- Office hours can be found in the course schedule and classroom slack channel.


### Scrums/Standups
Twice a day, typically in the morning class AND in the afternoon after lunch, your group's instructor will lead a 10 minute scrum meeting to talk about progress and planning. 
- During the ***morning scrum***, each person should cover:
    - What was worked on the day before?
    - What will be worked on that day?
    - Any obstacles that could jeopardize project deadlines?
- During the ***afternoon scrum***, each person will: 
    - Screenshare their code and website to showcase what they did that day!
    - Discuss any wins they had!
  
    Afternoon scrums are also your place to get any suggestions (not debugging) on simple things such as UI/UX concerns. For example, you may ask other group members if they think your navbar would be more intuitive at the top or side of the page.


### In-person Support (Using Tokens)
You may use a token if the following are true:
- You are not able to find the solution in the cohort's repos.
- You are not able to find the solution online.

Each student will have a limited number of tokens (specified on the Project README) to ask questions regarding debugging/errors. Tokens are for filing a [GitHub issue](https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/issues/new?assignees=&labels=Pending&template=project-troubleshooting.md&title=BRIEF+ISSUE+DESCRIPTION) for a 1:1. If your tokens reach 0, you will not be able to ask instructors for further assistance.

Please be advised, the response may not be immediate as we may be helping other students. Do not DM the instructional team with issues as we will not be responding to any debugging issues via DM.


## Project Submissions
**_DO NOT FORK THIS REPOSITORY!_** Create a **new** repository on your personal GitHub account. Then, submit your project as an issue using [this template](https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/issues/new?assignees=&labels=Pending&template=project-submission.md&title=YOUR+FULL+NAME).

You must turn in something before presentations begin. However, you're welcome to (and should!) continue working on it after the cohort

With your submission please include any questions you'd like answered, or specific things on which you'd like us to focus when giving feedback.


## Project Presentations
All will present, even if you did not complete the requirements. If you do not show up for project presentations, your project will not be deemed as submitted and you will not be eligible for graduation.

During presentations, there should be **no working on your code** while others are presenting. This is your chance to ask others how they tackled their project and leave them some encouraging words in the social channel!

Be prepared to answer questions like:
- What would you do differently?
- What are you most proud of?
- How did you plan your project?
- What did you learn?

Your presentation should last from between 5-8 minutes and show off the following:
- Your project README on GitHub.com.
- Your deployed site, which should be linked on your README. Demonstrate how a user would naviagte your site as well as the responsiveness of your site.
- Your code files, especially where the bulk of the site's logic is.


## Suggestions for Success
- **Realistically plan out a project that will challenge you but be able to be complete within a week.** While you will have more than a week to complete this project, you want to hit MVP several days before submissions. This will allow you to focus on stretch goals and deployment without needing to worry about basic requirements.
- **Don't under estimate the value of planning!** Use tools like Trello or GitHub Projects and track your progress against milestones. Don't think of the working game as the goal. Think of the next milestone as the goal (e.g., getting my click handler to work, or getting the UI implemented). This will feel far less overwhelming and each successfully completed milestone will provide you with the motivation to tackle the next task!
- **Break the project down into different components** (data, presentation, views, style, DOM manipulation) and brainstorm each component/part individually. Use a whiteboard or notebook to capture your thoughts!
- **Use your Development Tools** (console.log, inspector, alert statements, etc) to debug and solve problems
- **Consult documentation resources** (MDN, etc.) to better understand what you’ll be getting into.
- **Make it work, make it good, make it fast.** Don't get hung up on only saving or writing code that is good code. Get it working first, even if it means writing bad or ugly code. Once it's working, come back and refactor!
- **Don’t be afraid to write code that you know you will have to remove later.** Create temporary elements (buttons, links, etc) that trigger events if real data is not available.
- **Commit early, commit often.** Don’t be afraid to break something because you can always go back in time to a previous version.


## Plagiarism
Take a moment to re-familiarize yourself with the [plagiarism policy](https://git.generalassemb.ly/SEBR-Tardigrade/Cohort-Details/blob/main/Plagiarism%20Policy.md).  

Projects give you an opportunity to apply the skills you're learning in a practical manner.  If you're struggling with something, that's okay!  In fact, that's why you're here -- if this was easy and you could do it already, you wouldn't be here. These assignments are similar to those you can expect when applying for a job, either in the form of a take-home coding challenge or an in-person technical interview. So lean in, get comfortable with being uncomfortable, and challenge yourself to complete this project on your own.

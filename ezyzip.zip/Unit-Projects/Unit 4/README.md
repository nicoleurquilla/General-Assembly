<img width="100%" src="https://i.imgur.com/CYx9Es5.png" />


# Project #4: Your Capstone MERN Project
**You’ve come a long way, and it's time to show it.** This will be your most advanced project to date. **Before you start working** on the planning for your project ensure that your project idea:
- Meets the minimum requirements
- Is reasonably scoped
- Is a good demonstration of your abilities as a full-stack developer


## Purpose 🧐
This project will allow you more deeply understand the MERN stack as well as demonstrating your mastery of SEI concepts. You want potential hiring managers and other engineers to take note of your skill and consider you above other potential applicants.


## &#x1F534; Requirements (mandatory to pass):
### Project Proposal - due Friday, Feb 23rd by 4:00 PM ET
1. Before starting to code, submit your proposal [here](https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/issues/new?assignees=&labels=Pending&template=project-proposal.md&title=Project+%23+-+Your+Name+-+Your+Squad+Lead) as an issue ticket on this repo.
1. **Your proposal must include a route table**. Make sure the route table includes all the routes you'll use for both of your models.
1. If you are planning on building an app with related schemas, upload an ERD with your proposal.
1. Your Pod Lead may meet with you to discuss your proposal.
1. When thinking of an app idea, try to frame the project in terms of trying to solve a "problem" and think about the purpose of the app, who would use it, etc. The problem doesn't have to be anything intense and can be something small and simple!
1. Your final result must match your proposal


### Workflow - to be followed throughout the course of the project
1. A git repository hosted on GitHub with frequent commits dating back to the very beginning of the project (**at least one commit is required per day of the project**).
1. A `README.md` file that includes the following sections:
    1. [ ] An embedded screenshot of the app
    1. [ ] List of the **technologies used**
    1. [ ] **Installation instructions** 
        - A set of step-by-step guidelines that help users properly install and set up your application (e.g. initializing NPM, creating a .env file, etc)
        - Keep your instructions beginner-friendly!
        - Here's a short article on keeping things simple: https://kentcdodds.com/blog/first-timers-only
    1. [ ] Your **user stories** – who are your users, what do they want and why?
    1. [ ] **Screenshots** of the application to let users know what to expect
    1. [ ] Descriptions of any **unsolved problems** or **major hurdles** you had to overcome
    1. [ ] Descriptions of next steps you have planned for your application
1. A link to your hosted project in the URL section of your Github repo (see below).
    ![URL section](https://media.giphy.com/media/WUsOlSNbPlE72OudJs/giphy.gif)


### Product Requirements (MVP - Minimum Viable Product)
1. A working full-stack application, built by you
1. Application must incorporate at least two models, or 1 model and a third-party API
1. Backend must be created with Express, Mongoose, and NodeJS
1. Back-end must contain routes that perform CRUD operations on a model or models. You don't need full CRUD on just one specific model, but all CRUD operations must be present throughout the back-end.
1. Front-end must be built with React and React Router, and contain 3 components (aside from the App component).
1. Front-end must communicate with the back-end API to Create, Read, Update, and Destroy resources (using either fetch or axios) - 
1. Uses CSS (i.e. media queries) to make the app appear professional and responsive across mobile, tablet, and desktop widths
1. Observe a consistent separation of concerns throughout the project
1. Use a technology not taught in class (i.e. SemanticUI), or a bonus concept (i.e. JWT)	
1. Hosted on Heroku


## &#x1F535; Possible Stretch Goals (*NOT* mandatory to receive a passing grade)
- Implement Mongoose relationships between your models
- Use [SASS](https://sass-lang.com/) or a new CSS framework to style your project
- Implement pagination in a gallery of cards or images
- Allow for upload of files using a tool like [multer](https://www.npmjs.com/package/multer)


## Deploying your Project
For anyone to be able to see and use your project, you must deploy it online somewhere. For this project, you will be deploying it on Heroku. On March 5th, we will walk through deployment of your MERN app. You are free to work on deployment before that date, but are not required to.


## Tokens
Each student will have **5 Tokens** to ask questions regarding debugging/errors. Tokens are for filing a [GitHub issue](https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/issues/new?assignees=&labels=Pending&template=project-troubleshooting.md&title=BRIEF+ISSUE+DESCRIPTION) for a 1:1. If your tokens reach 0, you will not be able to ask instructors for further 1:1 assistance.

Please be advised, the response may not be immediate as we may be helping other students. Do not DM the instructional team with issues as we will not be responding to any debugging issues via DM. 


## Checkpoints
1. Proposal is due February 23rd (4:00 PM ET)
1. Completion of Backend - February 27th 
1. Communication of Both Ends - February 28th
1. MVP - March 1st By Afternoon Standup
1. Your site should be deployed and working by March 5th
1. Final submissions and presentations are due March 6th


## Inspiration from Previous SEI Grads
- https://launchbreak.herokuapp.com/
- https://cryptosis-app.herokuapp.com/
- https://my-hero.herokuapp.com/
- https://wellness-app-7dccdb72987b.herokuapp.com/
- https://wordwise-f8f3ab93bd4f.herokuapp.com/


## Licensing
1. All content is licensed under a CC­BY­NC­SA 4.0 license.
2. All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.

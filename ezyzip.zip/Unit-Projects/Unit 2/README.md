<img width="100%" src="https://i.imgur.com/CYx9Es5.png" />


# Project #2: MEN-Stack CRUD App
For your second project, you'll be creating a full-stack application of your design using MongoDB/Mongoose, Express, NodeJS, EJS, and CSS.

Take the time to be creative, balance expectations, and deliver a portfolio-worthy application. Our biggest tip to you is to keep it simple, hit MVP, and then add any desired features/complexities after that point.

**You will be working individually for this project**, but we'll be guiding you along the process and helping as you go. Show us what you've got!


## Purpose
Gain vital experience build a full-stack application from scratch. Being able to approach this project without starter code, reviewing how we built MEN-stack apps in class, and then applying it on your own is the best way you can internalize the course material and make connections.

Additionally, being able to show off a full-stack multi-page application to hiring managers and other engineers is a great demonstration of the knowledge you gained during this bootcamp.


## &#x1F534; Requirements (mandatory to receive a passing grade)
### Project Proposal - due Friday Jan 12th by 4:00 PM ET
1. Before starting to code, submit your proposal [here](https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/issues/new?assignees=&labels=Pending&template=project-proposal.md&title=Project+%23+-+Your+Name+-+Your+Pod+Lead) as an issue ticket on this repo.
1. **Your proposal must include a route table**. Make sure the route table includes all the routes you'll use for both of your models.
1. If you are planning on building an app with related schemas, upload an ERD with your proposal.
1. Your Pod Lead may meet with you to discuss your proposal.
1. Your final result must match your proposal


#### Workflow - to be followed throughout the course of the project
1. A git repository hosted on Github with frequent commits dating back to the
  very beginning of the project (**at least one commit is required per day of the project**).
1. A `README.md` file that includes the following sections:
    1. [ ] An embedded screenshot of the app
    1. [ ] List of the **technologies used**
    1. [ ] **Installation instructions** 
        - A set of step-by-step guidelines that help users properly install and set up your application (e.g. initializing NPM, creating a .env file, etc)
        - Keep your instructions beginner-friendly!
        - Here's a short article on keeping things simple: https://kentcdodds.com/blog/first-timers-only
    1. [ ] Your **user stories** – who are your users, what do they want and why?
    1. [ ] **Screenshots** of the application to let users know what to expect
    1. [ ] Descriptions of any **unsolved problems** or **major hurdles** you had to overcome
    1. [ ] Descriptions of next steps you have planned for your application
1. A link to your hosted project in the URL section of your Github repo (see below).
    ![URL section](https://media.giphy.com/media/WUsOlSNbPlE72OudJs/giphy.gif)


#### Product Requirements (MVP - Minimum Viable Product)
1. A working full-stack application, built by you, using Node.js, Mongoose, Express, EJS, and CSS
1. Adhere to the **MVC** file structure: Models, Views, Controllers
1. Observe a consistent separation of concerns throughout the project
1. Create and use two distinct schemas. *They do not have to be related to one another.*
1. One of your schemas must be used to make a model with all 7 RESTful routes and full CRUD.
1. You application must be styled professionally and have responsive design.
1. Hosted on Heroku


## &#x1F535; Possible Stretch Goals (*NOT* mandatory to receive a passing grade)
- Incorporate the Use of a thrid-party API (Google maps, etc) in addition to your models
- Implement a Mongoose relationship between your models, or create a third model that is related to one or both of your exisiting models
- Use a new CSS framework like Skeleton or Materialize



## Make A New *GitHub.com* Repo
- :heavy_exclamation_mark: Make your new repo on [GitHub](https://github.com/)!
  	- We recommend that you name your repo appropriately (for example `portfolio`, and _**not**_ something like `unit-one-project`).

- :heavy_exclamation_mark: **Do not** begin your project within this class repo.

- :heavy_exclamation_mark: **Do not** clone your project into the class repo.

- :heavy_exclamation_mark: Any repo made in GitHub Enterprise will not be visible outside of GtiHub Enterprise, which is why it is crucial your projects are made with your actual GitHub.com account.


## Deploying your Project
For anyone to be able to see and use your project, you must deploy it online somewhere. For this project, you will be deploying it on Heroku. On Thursday, we will get everyone set up with Heroku and walk through deployment.


## Tokens
Each student will have **7 Tokens** to ask questions regarding debugging/errors. Tokens are for filing a GitHub issue for a 1:1. If your tokens reach 0, you will not be able to ask instructors for further assistance. The debugging channel will be your best friend with your second best friend being 'le google'. Conceptual questions do not cost any tokens, so please don't be afraid to ask questions, this is only for debugging issues/errors.


## Checkpoints
The following is a list of dates you can use as checkpoints to ensure you are on track. Only will the first and last checkpoints be formally submitted (your proposal and final product).
1. Proposal is due January 14th (4:00 PM ET)
1. All RESTful routes should be functioning by January 16th
1. All MVP requirements should be completed by January 18th
1. Your site should be deployed and working by January 19th
1. Final submissions and presentations are due January 22th


## Inspiration from Previous SEI Grads
MEN-Stack Applications from some previous SEI grads:
- https://pathfinder50.herokuapp.com/
- https://gregslist.herokuapp.com/
- https://brewski-buddy.herokuapp.com/
- https://fly-bin.herokuapp.com/
- https://virtual-vinyl-vault-f0611426aaeb.herokuapp.com/
- https://monitor-reviews-154641efa8e1.herokuapp.com/


## Useful Resources
- **[MDN Javascript Docs](https://developer.mozilla.org/en-US/docs/Web/JavaScript)**
- **[Heroku Documentation](https://devcenter.heroku.com/categories/reference)**
- **[Trello](trello.com)**


## Licensing
1. All content is licensed under a CC­BY­NC­SA 4.0 license.
2. All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.

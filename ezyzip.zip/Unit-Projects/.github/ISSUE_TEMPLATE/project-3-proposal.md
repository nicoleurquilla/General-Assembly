---
name: Project 3 Proposal
about: This issue is to be used for Project 3 submissions only
title: 'Project 3 Proposal - Your Group Name'
labels: Pending
assignees: ''
---


## GitHub Repository Link


## Pitch Deck Link


## Trello Board Link


## Wire Frames (if not in pitch deck)
> Copy and paste or drag and drop your images here


## ERD (if not in pitch deck)
> Copy and paste or drag and drop your images here


## Anything Else You'd Like Us to Know

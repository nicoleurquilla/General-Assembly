---
name: Project Proposal
about: This is the format to follow for all Unit Project proposals
title: 'Project # - Your Name - Your Pod Lead'
labels: Pending
assignees: ''

---

---
name: Project Proposal
about: Project [X] Proposal
title: Your Name - Your Squad Lead
---


## Wire Frames
> Copy and paste or drag and drop your images here


## GitHub Repository
> Link to your project's GitHub repository here


## User Stories
> Add multiple user stories following the _As a [type of user], I want [what the user wants], so that [what it helps accomplish]_ format.


## MVP Goals (How your specific project will look & behave in order to accomplish MVP)


## Stretch Goals (How your specific project look & behave *AFTER* you accomplish MVP)


## Anything Else You'd Like Us to Know

<img width="100%" src="https://i.imgur.com/CYx9Es5.png" />


# Project #1: Your Portfolio Site & Mini-Game
For your first project, you'll be creating a portfolio site using HTML, CSS and
JS! 

This is an opportunity to **be creative**, and work through some **tough, real-world programming challenges** as you build a frontend application from scratch.

**You will be working individually for this project**, but we'll be guiding you along the process and helping as you go. Show us what you've got!


## Purpose
What do you want people to find when they Google you? What do you want someone's first impression of you to be? Your portfolio is the portal to your professional online presence. It consolidates the content you've created on multiple platforms and presents it in a digestable form, making it easier for future employers to learn more about you.


## Sample User Stories to Get Started
- As a non-technical HR manager, I want to quickly see the skills and experience of a candidate, so that I can evaluate whether the candidate meets the requirements for an open position at my company.
- As a mid-level engineer, I want to view a junior developer's project and read their code, so that I can evaluate their coding skills.
- As a friend of the person who built this portfolio, I want to see what my friend has built so that I have an understanding of what they do as a developer and I can encourage them.


## &#x1F534; Requirements (mandatory to receive a passing grade)
### Project Proposal - due Decemeber 15th EOD
1. Before starting to code, submit your proposal [here](https://git.generalassemb.ly/SEBR-Tardigrade/Unit-Projects/issues/new?assignees=&labels=Pending&template=project-proposal.md&title=Project+%23+-+Your+Name+-+Your+Pod+Lead) as an issue ticket on this repo.

    Make sure to fill out all the sections!
1. Your Pod Lead may meet with you to discuss your proposal, and will approve or deny it.
1. Your final result must match your proposal


### Workflow - to be followed throughout the course of the project
1. A git repository hosted on Github with frequent commits dating back to the
  very beginning of the project (**at least one commit is required per day of the project**).
1. A `README.md` file that includes the following sections:
    1. [ ] An embedded screenshot of the app
    1. [ ] List of the **technologies used**
    1. [ ] **Installation instructions**
    1. [ ] Your **user stories** – who are your users, what do they want and why?
    1. [ ] **Screenshots** of the application to let users know what to expect
    1. [ ] Descriptions of any **unsolved problems** or **major hurdles** you had to overcome
    1. [ ] Descriptions of next steps you have planned for your application
1. A link to your hosted project in the URL section of your Github repo (see below).
    
    ![URL section](https://media.giphy.com/media/WUsOlSNbPlE72OudJs/giphy.gif)

> NOTE: README files are made using Markdown (files with a `.md` extension), which is a markup langauge like HTML. In fact, you can use HTML directly in markdown files!
>
> If you would like to learn more about formatting your README, you can read [this supplemental lesson](https://git.generalassemb.ly/SEI-CC/SEIR-12-13-21/blob/main/work/w01/d1/hw-markdown-intro.md).


### Product Requirements (MVP - Minimum Viable Product)
**YOUR WHOLE PROJECT MUST:**
1. Be built with HTML, CSS, and JavaScript in separate files
1. Implement responsive design - meaning the site is useable and readable on small and large screens
1. Have organized code: 
    - Consistently indented 
    - No "dead" (commented out) code
    - Sensibly named variables and functions
1. Hosted on Github Pages

**YOUR PORTFOLIO MUST:**
1. Contain the following sections or pages:
	- Home (greeting page)
	- Bio/About Me (your background)
	- Resume (past work experience)
	- Projects (this will link to your browser mini-game!)
	- Links (links to your GitHub, LinkedIn, and other sites you find interesting)
        - **TIP:** Possible implementation of this section could be a `<footer>` element.
1. Use JS to create one of the following interactive features:
    - A modal *OR*
    - A carousel *OR*
    - A color theme switcher

**YOUR MINI-GAME MUST:**
1. Be loaded/run from the "Projects" page/section of your Portfolio
1. Include win/loss logic and rander a win/loss message in HTML
1. Allow the user to play again once the game is finished.

> This mini-game should be very simple to implement. Suggested games are:
> - Wordle
> - Mastermind
> - Connect Four
> - Tic-Tac-Toe
> - Hangman
>
> This [example site](https://devlin-portfolio.herokuapp.com/games) has all of the games listed above if you need some inspiration.


## &#x1F535; Possible Stretch Goals (*NOT* mandatory to receive a passing grade)
- Create a complex user interface module (e.g. a carousel, modal, sticky nav, etc)
- Create an additional browser-based game (e.g. a quiz, choose your own adventure, battle game, etc)
- Research AJAX (covered later in this course) and create an app that displays interesting data from an external source (ask your instructor for a list of good sources)


## Make A New *GitHub.com* Repo
- :heavy_exclamation_mark: Make your new repo on [GitHub](https://github.com/)!
  	- We recommend that you name your repo appropriately (for example `portfolio`, and _**not**_ something like `unit-one-project`).

- :heavy_exclamation_mark: **Do not** begin your project within this class repo.

- :heavy_exclamation_mark: **Do not** clone your project into the class repo.

- :heavy_exclamation_mark: Any repo made in GitHub Enterprise will not be visible outside of GtiHub Enterprise, which is why it is crucial your projects are made with your actual GitHub.com account.


## Deploying your Project
For anyone to be able to see and use your project, you must deploy it online somewhere. For this project, you will be deploying it onto GitHub Pages. During project we will go over how to deploy your site to GitHub Pages.

<details><summary>Extra: want your own domain name?</summary>

You can also host your GitHub Pages with your own domain name. [Here is a walkthrough from namecheap, one web hosting service](https://www.namecheap.com/support/knowledgebase/article.aspx/9645/2208/how-do-i-link-my-domain-to-github-pages)

</details>


## Tokens
- Tokens are for filing a GitHub issue for a 1:1 debugging session with an instructor.
- Each student will have **8 Tokens** to ask questions regarding debugging/errors. If your tokens reach 0, you will not be able to ask instructors for any more 1:1 debugging. 
- The debugging channel will be still be open and free of charge! Your instructors will provide more general.vague support to get you pointed in the right direction. 
- Conceptual questions do not cost any tokens, so please don't be afraid to ask questions, this is only for debugging issues/errors.


## Reminder of Checkpoints
The following is a list of dates you can use as checkpoints to ensure you are on track. Only will the first and last checkpoints be formally submitted (your proposal and final product).
1. Proposal is due December 15th EOD
1. The MVP requirements for your Portfolio should be met by December 20th EOD
1. The MVP requirements for your mini-game should be met by December 21st EOD
1. Your whole site (Portfolio and Mini-game) should be deployed on GitHub Pages by December 22nd EOD
1. Final submission and presentations are due January 2nd BOD
	
	
## Inspiration from Previous SEI Grads
Personal websites from some previous SEI grads:
- https://www.tylerjconti.com/
- http://www.jim-creel.com/
- https://kkoorrbbiinn.github.io/Korbin-Portfolio-Repo/index.html
- http://adrianbautista.com/
- https://ellereyy.github.io/Portfolio-1/index.html
- https://robinahunter.github.io/Portfolio/index.html


## Useful Resources
- **[MDN Javascript Docs](https://developer.mozilla.org/en-US/docs/Web/JavaScript)**
- **[GitHub Pages](https://pages.github.com)**
- **[Trello](trello.com)**


# Licensing
1. All content is licensed under a CC­BY­NC­SA 4.0 license.
2. All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.

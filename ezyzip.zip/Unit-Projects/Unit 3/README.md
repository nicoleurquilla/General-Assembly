<img width="100%" src="https://i.imgur.com/CYx9Es5.png" />


# Project #3: Full-stack Django Group Project
You’ve already worked in small groups to accomplish various labs and exercises, but this time **we’re going to challenge you to work in a small team on a project.** This project will push you both technically and collaboratively!

You and your teammates together will architect, design, and collaboratively build a full-stack web app. With this project you'll be building an exciting full-stack app that uses the Python-based Django Web Framework.


## Purpose 🧐
You'll likely be working as part of a team in the workplace and **this project will provide you with that important team development experience.** However, working on a project as part of a team can be more challenging due to logistical reasons, differing opinions, etc.

During this project, your instructors are going to be evaluating your ability to:
- Listen to and respect other opinions
- Share and contribute your ideas with the team
- Form a consensus and compromise when opinions differ

In fact, **your ability to work in a team during this project is more important than the project itself!** 

As such, take time to review the [Working in Teams](./Working%20in%20Teams.md) markdown with your group. Understand that this is a professional environment and dictates workplace courtesy and respect. ***NO GROUP MEMBER IS MORE IMPORTANT THAN THE REST!***


## Requirements (mandatory to pass):
### Pitch Deck - presented by your team on February 2nd, 2024
Working in a team is going to require more upfront planning to ensure the team is "on the same page". As such, your project proposals will be much more formal than prior proposals. You will be building a [pitch deck](https://web.archive.org/web/20220201093530/https://pitchdeck.improvepresentation.com/what-is-a-pitch-deck) with your team. Your pitch deck must include:
- [ ] The application name.
- [ ] Your team members and their roles.
- [ ] The problem you are going to solve with your app.
- [ ] An ERD showing the attributes of each entity and the relationships between them. Refer to the Data Modeling lesson for assistance. This can be a link to an external document/site if needed.
- [ ] Wireframes of the main pages of functionality, e.g. Landing Page, Posts Index Page, Favorite Posts Page, Add Post Page, etc. This can be a link to an external document/site if needed.
- [ ] Parts 1-6 of this graphic. Parts 7-12 are optional.
  ![](https://i.imgur.com/NvA1B6Q.png)


For inspiration, check out decks made by previous SEI students:
- [Anamolies Anonymous](https://docs.google.com/presentation/d/1VUNM5WSZ2tstlcOgvoQ4le7Uxxos1Y5AM99pJdu4ZEQ/edit)
- [Brick by Brick](https://docs.google.com/presentation/d/1iw25GfGrGn2sBJFQAdsynni8KbFpGkx2DM-WkJ8OuWw/edit)
- [Mixzers](https://docs.google.com/presentation/d/1TV-kwUMiM6Mfa_iwTf093T6JxVQNdPMl03ckbUjTYMk/edit)
- [Pantry](https://docs.google.com/presentation/d/1WvHoN5MNaRembgcoog5p0GtivVCOZSzvfPyeevzy08g/edit)
- [Planit](https://docs.google.com/presentation/d/16olfyNWYzW1nNiw_iysfz85qe2UOq2HU-Au6Jr8vn2w/edit)


### Trello Board - due February 2nd, 2024
In addition to pitching your idea to the rest of the class, you will need to create and submit a Trello board. This will clearly outline the features/steps your group will implement throughout project week and assign tasks to specific team members. 

Your Trello board must contain **User Stories**, each moving from left to right in the following three lists in your board:
- Ice Box
- Current/MVP
- Completed

These user stories must follow this format: _As a \<user role\>, I want \<feature\>, because \<reason\>._ (the _reason_ is optional if it's blatantly obvious)


### Workflow - to be followed throughout the course of the project
1. **:heavy_exclamation_mark: Using Trello:**
    1. After all of the user stories that you can think of are defined in the Ice Box list, prioritize them your with your "wish list" items at the bottom. 
    1. After the prioritization, move the user stories for the MVP to the Current/MVP list. FYI, the MVP (Minimum Viable Product) in this case consists of the minimal user stories that will result in the project requirements being fulfilled.
    1. After the user story at the top of the Current/MVP list is implemented, move it to the Completed list.
    1. When there are no more user stories in the Current/MVP list - focus on ensuring that the app's features look polished!
    1. After the MVP's features look great and if time permits, the user story from the top of the Ice Box list may be implemented.  Ensure that each Ice Box user story's feature is polished before moving on to another user story in the Ice Box.
1. **:heavy_exclamation_mark: Using Git and GitHub:** 
    1. Your team must manage team contributions and collaboration using Git/GitHub team work-flow.  Here are some references:
        - [Team Workflow Video](https://www.youtube.com/watch?v=oFYyTZwMyAg)
        - [Cheat Sheet in Git & GitHub Repo](https://git.generalassemb.ly/SEIR-Phoenix/Git-GitHub-Fundamentals/blob/main/Lessons/5.%20Team%20Workflows.md)
        - [Understanding the GitHub Flow](https://guides.github.com/introduction/flow/)
    1. All team members need to have significant contributions to the project via daily git commits.
1. **:heavy_exclamation_mark: A `README.md` file that includes the following sections**:
    1. An embedded screenshot of the app
    1. List of the technologies used
    1. Installation instruction
        - A set of step-by-step guidelines that help users properly install and set up your application
        - Keep your instructions beginner-friendly!
    1. Descriptions of any unsolved problems or major hurdles your team had to overcome
    1. Links to your team's pitch deck, Trello board, wireframes, and ERD


### Make A New Repo
- :heavy_exclamation_mark: Make your new repo on [GitHub](https://github.com/)!
  	- We recommend that you name your repo appropriately (for example `portfolio`, and _**not**_ something like `unit-one-project`).

- :heavy_exclamation_mark: **Do not** begin your project within this class repo.

- :heavy_exclamation_mark: **Do not** clone your project into the class repo.

- :heavy_exclamation_mark: After your project proposal has been approved, [make a new github repo for your project](https://help.github.com/articles/create-a-repo/).

- :heavy_exclamation_mark: Any repo made in GitHub Enterprise will not be visible outside of GitHub Enterprise, which is why it is crucial your projects are made with your actual GitHub account.


### Product Requirements (MVP - Minimum Viable Product) - to be met by February 8th, 2024:
- [ ] Be a full-stack Django application.
- [ ] Connect to and perform data operations on a PostgreSQL database (the default SQLLite3 database is not acceptable).
- [ ] If consuming an API, have at least one data entity (model) in addition to the built-in `User` model. The related entity can be either a one-to-many (1:M) or a many-to-many (M:M) relationship.  
- [ ] If not consuming an API, have at least two data entities (models) in addition to the built-in `User` model.
- [ ] Have full CRUD data operations across any combination of the app's models (excluding the `User` model). For example, creating/reading/updating posts and creating/deleting comments qualifies as full CRUD data operations. 
- [ ] Be deployed online using Heroku. Presentations must use the deployed application.


### Stretch Goals (not mandatory):
Some possible ideas for stretch goals are:
- The ability to upload images to AWS S3
- Consuming an API (installation of the [Requests package](https://docs.python-requests.org/en/latest/user/quickstart/) will be necessary)
- Incorporating a CSS framework you haven't used before


### Project Presentations - due February 12th, 2024:
**Your entire team must participate in the presentation of the project.**

You will have approximately 15 minutes to present your project following these guidelines:
- [ ] **Introduce the Project:** by paraphrasing the README.	
- [ ] **Demonstrate the Project:**
    - Launch the project by clicking the link in the README.
    - Be sure to demo the qualifying CRUD data operations.	
- [ ] **Show/discuss your code:**
    - Show the "main" Django model.
    - Show the code for the main model's view.
    - Show your favorite Django template.
- [ ] **Share the experience:**
    - What was your biggest challenge? (besides Team Git Workflow)
    - What are your key learnings/takeaways?	
- [ ] **Q & A + Feedback**


## Team Member Roles
Below are two required roles each team must have as well as ideas for some optional roles. Your team is also welcome to create new roles and assign those to a team members, so long as the two require roles are also met.
- **Scrum Master (required):** Each team will be assigned a *scrum master* by the instructional team. The scrum master will be responsible for meeting with the instructional team in the morning and afternoon of project week to report on the team's progress. They will lead the team's individual standups, manage the Trello board, and submit any GitHub issues via tokens.
- **Git Guru (required):** the primary person for "owning"/managing the repo and GitHub team workflow (merging pull requests, etc.). They will create the repository, add the team members as collaborators, and oversee branch creation.
- **Database Manager (optional):** this person will be in charge of creating and managing the models, ERD, etc.
- **Designer (optional):** the person in charge of UI design/layout (wireframes) and styling.

Each team member must have at least 1 role that will allow them to make significant contributions to the project via daily commits.


## Project Week Format
### Scrums/Standups
Twice a day, typically at the beginning of class AND at the end of class, the instructors will lead a 15 minute scrum meeting with all the team scrum masters to talk about their respective team's progress and planning. 
- During the ***morning scrum***, each scrum master should cover:
    - What was worked on the day before?
    - What will be worked on that day?
    - Any obstacles that could jeopardize project deadlines?
- During the ***afternoon scrum***, each scrum master will: 
    - Screenshare their code and website to showcase what they did that day?
    - Discuss any wins they had!


### In-person Support
Use your team members! Teams are a great asset, and should be able to resolve all issues and obstacles you encounter.


### Tokens
You may use a token if the following are true:
- No one in your group is able to solve the issue.
- You are not able to find the solution in the cohort's repos.
- You are not able to find the solution online.

Each ***group*** will have **6 Tokens** to ask questions regarding debugging/errors. Tokens are for filing a GitHub issue for a 1:1. If your group's tokens reach 0, you will not be able to ask instructors for further assistance. 

The group's ***scrum master*** will be responsible for submitting the tokens. They must comminicate with the rest of the team before doing so. Fill out [this issue template](https://git.generalassemb.ly/SEIR-Phoenix/Unit-Projects/issues/new?assignees=&labels=Pending&template=project-troubleshooting.md&title=BRIEF+ISSUE+DESCRIPTION) to use a token.

Please be advised, the response may not be immediate as we may be helping other students. Do not DM the instructional team with issues as we will not be responding to any debugging issues via DM.


## Checkpoints
1. Proposal is due February 2nd (9:00 AM ET)
1. All MVP requirements should be completed by February 8th
1. Your site should be deployed and working by February 9th
1. Final submissions and presentations are due February 12th



## Licensing
1. All content is licensed under a CC­BY­NC­SA 4.0 license.
2. All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.

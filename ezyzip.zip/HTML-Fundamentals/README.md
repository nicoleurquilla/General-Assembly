# HTML Fundamentals
<img width="100%" src="https://i.imgur.com/aJnavCa.jpg" />

## What is HTML?
HTML, which stands for HyperText Markup Language, is the fundamental building block of the web. It is a simple and powerful language used to create the structure and content of web pages. Think of HTML as the skeleton of a webpage, defining the different elements and how they should be organized. It uses tags (enclosed in angle brackets) to mark up the different parts of a webpage, such as headings, paragraphs, images, links, and more. 

By using HTML, web developers can define the structure and layout of a webpage, making it readable by web browsers. It also allows for easy integration of other technologies like CSS (Cascading Style Sheets) for styling and JavaScript for interactivity. Without HTML, the web as we know it would not exist!

Learning HTML is a great starting point for anyone interested in web development, as it provides the essential knowledge to create and understand web pages. With HTML, you can bring your ideas to life on the internet and share information with the world.


## Lessons
1. [Intro to HTML](./Lessons/1.%20Intro%20to%20HTML.md)
1. [Building a Simple Multi-Page Site](./Lessons/2.%20Simple%20MPA.md)


## Cheatsheet
![HTML Cheatsheet](https://i.imgur.com/Y3KA5Hr.jpg)


## Licensing
1. All content is licensed under a CC­BY­NC­SA 4.0 license.
2. All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.

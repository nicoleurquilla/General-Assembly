# Express.js
<img src="https://i.imgur.com/U5JN8sm.png" width="100%" />


## What is Express?
Express.js is a popular web application framework that runs using Node.js. Express.js simplifies the process of building web applications by providing a set of tools and features that handle common web development tasks. With Express.js, you can easily create server-side applications, APIs, or even full-stack web applications using JavaScript.

Express.js is highly customizable and supports a wide range of plugins and extensions, making it suitable for projects of any size or complexity. By leveraging Express.js, developers can focus on building the core functionality of their web applications without getting lost in the low-level details of server-side development.


## Lessons
1. [MVC Architecture](./Lessons/1.%20MVC%20Architecture.md)
1. [Intro to Express](./Lessons/2.%20Intro%20to%20Express.md)
1. [Middleware](./Lessons/3.%20Middleware.md)
1. [URL Parameters](./Lessons/4.%20URL%20Parameters.md)
1. [EJS Partials](./Lessons/5.%20EJS%20Partials.md)
1. [Express & 3rd Party APIs](./Lessons/6.%203rd%20Party%20APIs.md)


## Labs
1. [Parameter Potpourri](./Labs/parameter-potpourri)
1. [Movie Match](./Labs/movie-match)


## Licensing
1. All content is licensed under a CC­BY­NC­SA 4.0 license.
2. All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.

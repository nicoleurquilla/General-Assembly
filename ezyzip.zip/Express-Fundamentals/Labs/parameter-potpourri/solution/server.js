// Imports
const express = require("express");
const app = express();

/* GREETINGS TASK
-------------------------------------------------------------- */
app.get('/greeting/:name', (req, res) => {
    res.send(`What's up ${req.params.name}?`)
})

/* TIP CALCULATOR
-------------------------------------------------------------- */
app.get('/tip/:total/:tipPercentage', (req, res) => {
    // convert the URL params to integere data types
    const subTotal = parseInt(req.params.total)
    const tipPercentage = parseInt(req.params.tipPercentage)
    const billTotal = subTotal + (subTotal * (tipPercentage / 100))
    res.send(`${billTotal}`)
})

/* MAGIC 8 BALL
-------------------------------------------------------------- */
app.get('/magic/:question', (req, res) => {
    const answers = ["It is certain", "It is decidedly so", "Without a doubt", "Yes definitely", "You may rely on it", "As I see it yes", "Most likely", "Outlook good", "Yes", "Signs point to yes", "Reply hazy try again", "Ask again later", "Better not tell you now", "Cannot predict now", "Concentrate and ask again", "Don't count on it", "My reply is no", "My sources say no", "Outlook not so good", "Very doubtful"]

    const randIdx = Math.floor(Math.random() * answers.length)

    res.send(`
    <h3>Your question: ${req.params.question}?</h3>
    <br>
    <h3>Your answer: ${answers[randIdx]}</h3>
    `)
})

/* FIBONACCI PART 1
-------------------------------------------------------------- */
app.get('/fibonacci/:num', (req, res) => {
    let initialNum = 0
    let nextNum = 1
    let sum = 1

    const input = parseInt(req.params.num)

    if (input === 0) {
        return res.send("Sweet, Fibonacci number!")
    }

    while (sum <= input) {
        console.log("Before incrementation:", initialNum, nextNum, sum)

        if (sum === input) {
            return res.send("Sweet, Fibonacci number!")
        }

        sum = initialNum + nextNum
        initialNum = nextNum
        nextNum = sum

        console.log("After incrementation:", initialNum, nextNum, sum, ' \n')
    }

    return res.send("I can tell this ain't a fibonacci number. Wack.")
})


/* FIBONACCI PART 2
-------------------------------------------------------------- */
app.get('/fibonacci-index/:num', (req, res) => {
    let initialNum = 0
    let nextNum = 1
    let sum = 1

    const input = parseInt(req.params.num)

    if (input === 0) {
        return res.send('0')
    }

    for (let i = 1; i < input; i++) {
        sum = initialNum + nextNum
        initialNum = nextNum
        nextNum = sum
    }

    return res.send(`${sum}`)
})


// Set express app to listen on port 3000
app.listen(3000, () => {
    console.log("Server is listening!!!")
});
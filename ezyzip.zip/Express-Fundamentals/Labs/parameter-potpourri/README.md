# Parameter Potpourri
<img src='https://i0.wp.com/www.cutertudor.com/wp-content/uploads/2021/11/homemadepotpourri5.jpg?resize=1024%2C576&ssl=1' width='100%'>


## Learning Objectives
* Practice setting up express applications.
* Practice creating custom routes.
* Practice using parameters from a request.


## Setup
* In your `~/code` folder, create a new directory `parameter-potpourri` or whatever you would like it to be named.
* `cd` into the folder you just created.
* Create a file named `server.js`. 
* Run the command **`npm init -y`** this command will create the file `package.json`.
* Install express by running the command `npm i express`.
* In your `server.js` file set up an Express app:
  ```js
  const express = require("express");
  const app = express();

  app.listen(3000, () => {
    console.log("Server is listening!!!")
  });
  ```
* Make sure your app is working by running the command `nodemon server.js` in your terminal. You should see something like this:
  ```sh
  [nodemon] 1.18.11
  [nodemon] to restart at any time, enter `rs`
  [nodemon] watching: *.*
  [nodemon] starting `node server.js`
  Server is listening!!!
  ```


## Your Task
### Greetings
1. Your app should have a route called `/greeting` that will send a generic greeting to the screen like "Hello, stranger".
2. Your app should have a route of `/greeting/:name`, where `:name` is a parameter that will accept a person's name. When hitting the route, the page should display a message such as "Hello, <name>", or "What's up, <name>", or "<name>! It's so great to see you!"


<hr>
 
>The purpose of this task is to demonstrate that similar to functions, routes in Express can take parameters and those parameters can have any value.

<hr>

  
### Tip Calculator
1. Your app should have a route called `/tip` that will expect *2 params*. One param should be called `total` and the other should be called `tipPercentage`.
2. When hitting the route, the page will display how much your tip will be based on the total amount of the bill and the tip percentage. (ex. hitting `'/tip/100/20'` should display `20` on the page).
3. Be sure you are using `res.send()` to send a **String**.  If you try to directly `res.send()` a Number, Express will think you're attempting to send an HTTP status code.

<hr>

>The purpose of this task is to demonstrate that info from the URL parameters can be used in your application to change things

<hr>


### Magic 8 Ball
1. Create a route called `/magic` that takes one parameter.
1. This parameter should expect a phrase in the URL that ask the Magic 8 ball a question.
1. So if the user hits that route and asks "will I be a millionaire" (`/magic/will%20i%20be%20a%20millionaire`) they should their question AND a random Magic 8 ball response returned back to them.
1. Remember that we can't use spaces in the url, so we use `%20` to express a space in the URL.
1. Use the array below of Magic 8 ball responses:
    ```js
    ["It is certain", "It is decidedly so", "Without a doubt", "Yes definitely","You may rely on it", "As I see it yes", "Most likely", "Outlook good","Yes", "Signs point to yes", "Reply hazy try again", "Ask again later","Better not tell you now", "Cannot predict now", "Concentrate and ask again","Don't count on it", "My reply is no", "My sources say no","Outlook not so good", "Very doubtful"]
    ```
    Make sure to *randomly* select an answer from this array when the user asks a question!


<hr>
 
>The purpose of this task is to demonstrate that a route may use data from _both_ the URL parameters AND other places within the app to do its work or construct its responses.

<hr>

  
### Fibonacci Part 1
1. Create a route called `fibonacci`
2. This route will take one param, the number we will operate on.
3. If the param is not a [fibonacci number](https://en.wikipedia.org/wiki/Fibonacci_number) send this response to the user:
    ```
    I can tell this ain't a fibonacci number. Wack.
    ```
4. If the number is a Fibonacci number send this response to the user:
    ```
    Sweet Fibonacci number!
    ```

 
### Fibonacci Part 2
1. Create a new route called `fibonacci-index`.
1. This route will also take one param, a number. 
1. The param will refer to the index of a number in the Fibonacci sequence. Send back to the user the Fibonacci number that is located at that index. 
1. For example, if the user goes to this URL: `/fibonacci-index/6` then they should receive a reponse of 13. If you look at the excerpt of the Fibonacci sequence below you'll see that 13 has an index of 6.
    ```
    1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, ...;
    ```

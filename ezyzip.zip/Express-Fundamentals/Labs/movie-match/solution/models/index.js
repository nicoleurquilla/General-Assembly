/* Require modules
--------------------------------------------------------------- */
require('dotenv').config()
const axios = require('axios')


/* Export API functions
--------------------------------------------------------------- */
module.exports = {
    // Async function that returns a new page of movie data
    getPage: async function (page) {
        const movies = await axios.get(`https://api.themoviedb.org/3/movie/popular?api_key=${process.env.APIKEY}&page=${page}`)
        return movies.data
    },
    getDetails: async function (movieId) {
        const movie = await axios.get(`https://api.themoviedb.org/3/movie/${movieId}?api_key=${process.env.APIKEY}`)
        return movie.data
    }
}
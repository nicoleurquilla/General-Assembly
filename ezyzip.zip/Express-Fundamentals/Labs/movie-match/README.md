# MovieMatch
<img width="center" src="https://i.imgur.com/kz3ZFqb.png" />


## Background
With your work at Nintendo you've been able to build your network and secured another project. Your client wants you to build a movie and TV show platform called MovieMatch!

MovieMatch is a platform that will allow users to discover new movies and TV shows, and detailed information about them.

Our application will use [The Movie Database API](https://developers.themoviedb.org/3/getting-started/introduction) to gather information about thousands of movies.


## Set Up
We'll be picking up where we left off from the [3rd Party APIs & Express lesson](https://git.generalassemb.ly/SEIR-Titans/Express-Fundamentals/blob/main/Lessons/6.%203rd%20Party%20APIs.md)


## Your Client Requests
### The Gallery
- The client wants the home page to redirect to `/gallery`, where the gallery page will display the 20 most popular movies
- The client wants the gallery to be comprised of cards that display the the movie's picture, rating, and name. When the card is hovered over, display a movie description

### Movie Details
- When a movie card is clicked on, the user should see a page that displays everything you see on the movie card and more advanced details about the movie such as:
    - The movie's runtime
    - What languages its available in
    - The movie's homepage
    - The movie's budget
- The details page should include a nav bar with a link back to the gallery

### Bonus
- On the gallery, the user should be able to click a Previous or Next button to view the next 20 or previous 20 most popular movies. When they go to a new page, the URL should show them what page they're on. For example:
    - `/gallery/2`
    - `/gallery/3`
    - `/gallery/78`
- Currently, the `getDetails` function executes an axios request that gives us movie details including the IDs of the streaming service the movie is avilable on. How could you update the `getDetails` function to return the name of the streaming services rather than the IDs?

    **HINT**: You will need to make additional axios requests in the `getDetails` function!

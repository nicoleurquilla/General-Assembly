/* Require modules
--------------------------------------------------------------- */
const express = require('express');


/* Create the Express app
--------------------------------------------------------------- */
const app = express();


/* Create a mock database
--------------------------------------------------------------- */
const plants = ['Monstera Deliciosa', 'Corpse Flower', 'Elephant-Foot Yam', "Witches' Butter",];


/* Static route
--------------------------------------------------------------- */
app.get('/home', (req, res) => {
    console.log(req.query.somekey)
    res.send('You are on the home route')
})


/* Dynamic route
--------------------------------------------------------------- */
app.get('/:indexOfPlantsArray', (req, res) => {
    console.log(req.params)
    res.send(plants[req.params.indexOfPlantsArray])
})





/* Tell the app to "listen" or run on the specified port
--------------------------------------------------------------- */
app.listen(3000, function () {
    console.log('Your app is running on port 3000...');
});

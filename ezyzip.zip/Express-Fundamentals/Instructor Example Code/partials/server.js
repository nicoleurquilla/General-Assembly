/* Require modules
--------------------------------------------------------------- */
const path = require('path');
const express = require('express');
const livereload = require('livereload');
const connectLiveReload = require('connect-livereload');


/* Create the Express app
--------------------------------------------------------------- */
const app = express();


/* Create the data the app will display
--------------------------------------------------------------- */
const data = [
    {
        id: 1,
        name: 'Gryffindor',
        founder: 'Godric Gryffindor',
        head: 'Minerva McGonagall',
        traits: ['Courage', 'Chivalry', 'Nerve', 'Daring', 'Determination', 'Bravery'],
        commonRoom: 'Gryffindor Tower'
    },
    {
        id: 2,
        name: 'Ravenclaw',
        founder: 'Rowena Ravenclaw',
        head: 'Filius Flitwick',
        traits: ['Learning', 'Acceptance', 'Intelligence', 'Wisdom', 'Wit', 'Creativity'],
        commonRoom: 'Ravenclaw Tower'
    },
    {
        id: 3,
        name: 'Hufflepuff',
        founder: 'Helga Hufflepuff',
        head: 'Pomona Sprout',
        traits: ['Hardworking', 'Patience', 'Loyalty', 'Fairness', 'Modesty'],
        commonRoom: 'Hufflepuff Basement'
    },
    {
        id: 4,
        name: 'Slytherin',
        founder: 'Salazar Slytherin',
        head: 'Severus Snape',
        traits: ['Resourcefulness', 'Self-preservation', 'Ambition', 'Cunning', 'Pride', 'Determination'],
        commonRoom: 'Slytherin Dungeon'
    }
]


/* Configure the app (app.set)
--------------------------------------------------------------- */
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


/* Middleware (app.use)
--------------------------------------------------------------- */
// A function that will refresh the browser when nodemon restarts
const liveReloadServer = livereload.createServer();
liveReloadServer.server.once('connection', () => {
    // wait for nodemon to fully restart before refreshing the page
    setTimeout(() => {
        liveReloadServer.refresh('/');
    }, 100);
});

// Tell Express what middleware functions to run
app.use(express.static('public'))
app.use(connectLiveReload())


/* Mount routes
--------------------------------------------------------------- */
app.get('/', function (req, res) {
    res.render('home', {
        houses: data,
        title: 'Hogwarts Houses'
    })
});

app.get('/house/:id', function (req, res) {
    const house = data.find(house => house.id === parseInt(req.params.id))
    res.render('wikiPage', {
        house: house,
        title: `${house.name} | Wiki Page`
    })
});


/* Tell the app to 'listen' or run on the specified port
--------------------------------------------------------------- */
app.listen(3000, function () {
    console.log('Your app is running on port 3000...');
});

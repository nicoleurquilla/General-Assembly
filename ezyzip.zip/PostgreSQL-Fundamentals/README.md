# PostgreSQL Fundamentals
<img src="https://i.imgur.com/sUA7H92.png" width="100%" />


## [What is PostgreSQL?](https://www.youtube.com/watch?v=zsjvFFKOm3c)
SQL, which stands for Structured Query Language, is a programming language used to manage and manipulate relational databases. It provides a standard way to interact with databases, allowing you to create, retrieve, update, and delete data. SQL is designed to be highly intuitive and readable, making it accessible to both beginners and experienced developers. It uses a declarative syntax, meaning you specify what you want to do, and the database engine takes care of the how.

PostgreSQL is a popular open-source relational database management system (RDBMS) that fully supports SQL. It is known for its reliability, robustness, and advanced features. It is a popular choice for developers and businesses seeking a reliable and powerful database solution that adheres to SQL standards.


## Lessons
1. [Installing PostgreSQL](./Lessons/1.%20Installing%20PostgreSQL.md)
1. [Intro to SQL & Relational Databases](./Lessons/2.%20Intro%20to%20SQL.md)
1. [Querying Data](./Lessons/3.%20Querying%20Data.md)
1. [Basic Joins](./Lessons/4.%20Basic%20Joins.md)


## Glossary
### Relational DB Terms
1. **Database:** A structured collection of data stored electronically, typically organized in tables with relationships between the data.
1. **Schema:** A collection of database objects (tables, views, etc.) associated with a particular database user.
1. **Table:** A structured data object consisting of rows and columns where each column represents an attribute, and each row represents a record.
1. **Column:** A vertical element in a table that represents a specific attribute or field. Also known as a field.
1. **Row:** A single record or entry in a table that contains data corresponding to each column.
1. **Primary Key:** A column or set of columns that uniquely identifies each row in a table. Ensures data integrity and allows for efficient data retrieval.
1. **Foreign Key:** A column or set of columns in one table that refers to the primary key in another table. Establishes a link between the two tables.
1. **Index:** A database object that improves the speed of data retrieval operations on a database table by providing a quick lookup mechanism.
1. **Normalization:** The process of organizing data in a database to eliminate redundancy and improve data integrity.
1. **Denormalization:** The opposite of normalization, denormalization is the process of intentionally introducing redundancy into a database by combining tables or adding redundant data to improve query performance.


### SQL Terms
1. **Statement:** A complete SQL command that performs a specific action, such as `SELECT`, `INSERT`, `UPDATE`, `DELETE`, etc.
1. **Clause:** A component of a SQL statement that provides additional instructions or conditions. Common clauses include `SELECT`, `FROM`, `WHERE`, `ORDER BY`, and `GROUP BY`.
1. **Operator:** A symbol or keyword that performs an operation on one or more operands. There are two types of operators in SQL.
    1. **Logical:** Keywords used to combine conditions. Examples include: `AND`, `OR`, `NOT`
    1. **Comparison:** Symbols or keywords used to compare values in SQL conditions. Examples include `<`, `>`, `=`, `LIKE`
1. **Operand:** A value or expression on which an operator acts. For example, in the expression `age > 25`, `age` is the operand.
1. **Constants:** Fixed values that remain unchanged during the execution of a query. Often used to provide static values in a result set. For example, we could provide a hard-coded discount rate to someone's order:
    ```sql
    SELECT 0.2 AS discount_rate, total_amount, order_id FROM orders;
    ```
    In this example `0.2` is a *constant*, and will remain unchanged in each row of the result set. It has been saved to an *alias* (see below) called `discount_rate`.
1. **Expressions:** In SQL, an expression is a combination of one or more values, operators, and SQL functions that, when evaluated, produces a single value. Examples include:
    1. Arithmetic calculations: `salary * 12`
    1. String concatenation: `first_name || ' ' || last_name`
    1. Function calls: `COUNT(*)`
1. **Conditions:** A logical statement or criteria specified in SQL statements that determine the rows to be included or excluded from the result set. Used in conjunction with `WHERE` clauses and often involve operators. `age > 25` is an example of a condition.
    > NOTE: it may be easy to confuse *conditions* and *expressions*. Remember:
    > - An *expression* is focused on calculating or deriving values.
    > - A *condition* is focused on establishing criteria for row selection or exclusion.
1. **Constraints:** Rules applied to a column or a set of columns in a table to enforce data integrity and control the type of data that can be stored. Common types of constraints include:
    1. `NOT NULL`: Ensures that a column cannot have a `NULL` value.
    1. `UNIQUE`: Ensures that all values in a column are unique.
    1. `PRIMARY KEY`: Combines the `NOT NULL` and `UNIQUE` constraints, creating a unique identifier for each record in a table.
    1. `FOREIGN KEY`: Establishes a link between two tables by enforcing referential integrity.
    1. `CHECK`: Specifies a condition that the data entered into a column must satisfy.
1. **Aliases:** Aliases are temporary names assigned to columns or tables in SQL queries to make the output more readable or to simplify the syntax. Aliases are defined using the `AS` keyword. Common use cases for aliases include:
    1. **Column Aliases:** Providing a more descriptive name for a column in the result set. For example:
        ```sql
        SELECT first_name AS "First Name" FROM employees;
        ```
    1. **Table Aliases:** Shortening table names to improve query readability, especially when dealing with complex queries involving multiple tables. For example: 
        ```sql
        SELECT e.first_name, d.department_name FROM employees AS e JOIN departments AS d ON e.department_id = d.department_id;
        ```
    1. **Expression Aliases:** Assigning a name to the result of an expression in the `SELECT` list. For example: 
        ```sql
        SELECT salary * 12 AS annual_salary FROM employees;
        ```
1. **System Functions:** A system function in SQL is a built-in function provided by the database management system (DBMS) to perform specific operations or retrieve system-related information. System functions vary between database systems. Examples of system functions include:
    1. `CURRENT_DATE`: Returns the current date.
    1. `CURRENT_TIME`: Returns the current time.
    1. `LENGTH`: Returns the number of characters in a string.


## Licensing
1. All content is licensed under a CC­BY­NC­SA 4.0 license.
2. All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.

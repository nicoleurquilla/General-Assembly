from django.contrib import admin
# import your models here
from .models import Cat

# Register your models here.
admin.site.register(Cat)
# Django Fundamentals
<img src="https://i.imgur.com/dz63SGR.png" width="100%"/>


## What is Django?
Django is a high-level web framework written in Python that simplifies web development by providing a comprehensive set of tools and features. It is considered an opinionated, full-feauture framework meaning it does a lot more behind the scenes for you but expects the developer to follow mor erules and conventions. Django also provides built-in features for user authentication, URL routing, form handling, and more. 

With Django, developers can focus on writing application logic and building robust web applications rather than dealing with low-level implementation details.


## Topics
1. [Intro to Django](./Lessons/1.%20Intro%20to%20Django.md)
    - [Official Django Tutorial](https://docs.djangoproject.com/en/4.2/intro/tutorial01/)
    - [Tutorial Solution](./Instructor%20Example%20Code/django-tutorial/)
1. [URLs, Views, & Templates](./Lessons/2.%20URLs%2C%20Views%2C%20%26%20Templates.md)
    - [Cat Collector Part 1](https://git.generalassemb.ly/SEIR-Mariposa/catcollector/tree/sync-5-finish-urls)
1. [Intro to Models](./Lessons/3.%20Intro%20to%20Models.md)
    - [Cat Collector Part 2](./Instructor%20Example%20Code/cat-collector-part2/)
1. [Class-based Views](./Lessons/4.%20Class-based%20Views.md)
    - [Cat Collector Part 3](./Instructor%20Example%20Code/cat-collector-part3/)
1. [One-to-Many Models & ModelForms](./Lessons/5.%20One-to-Many%20Models.md)
    - [Cat Collector Part 4](./Instructor%20Example%20Code/cat-collector-part4/)


### Bonus Lessons
1. [Many-to-Many Models](./Lessons/6.%20Many-to-Many%20Models%20(Bonus).md)
1. [Uploading Images to AWS](./Lessons/7.%20Uploading%20Images%20to%20AWS%20(Bonus).md)
1. [Django's Authentication System](./Lessons/8.%20Authentication%20System%20(Bonus).md)


## Cheatsheets
- [Dev.to](https://dev.to/ericchapman/my-beloved-django-cheat-sheet-2056)
- [GitHub.com](https://github.com/lucrae/django-cheat-sheet)


## Licensing
1. All content is licensed under a CC­BY­NC­SA 4.0 license.
2. All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.

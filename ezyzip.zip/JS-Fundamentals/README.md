# JavaScript Fundamentals
<img width="100%" src="https://i.imgur.com/TFKOFAk.png" />


## What is JavaScript?
JavaScript is a programming language that adds interactivity and dynamic behavior to websites. With JavaScript, you can make web pages come alive by responding to user actions, manipulating the content on the page, and communicating with web servers.

JavaScript is a fundamental language for web development, and learning it opens up a wide range of possibilities for creating modern web applications. Whether you're building a simple contact form or a complex web application, JavaScript is a crucial language that empowers you to bring your ideas to life on the web.


## Lessons
1. [Node.js & NPM](./Lessons/00.%20NodeJS%20&%20NPM.md)
    - Instructor Example Code: [Installing & Using `prompt-sync`](./Instructor%20Example%20Code/nodejs_example/)
1. [Intro to JS & Data Types](./Lessons/01.%20Intro%20to%20JS.md)
1. [Control Flow](./Lessons/02.%20Control%20Flow.md)
    - Instructor Example Code: [Control Flow Review](./Instructor%20Example%20Code/controlFlowReview.js)
1. Arrays
    1. [Intro to Arrays](./Lessons/03.%20Intro%20to%20Arrays.md)
    1. [Array Iterator Methods](./Lessons/10.%20Array%20Iterator%20Methods.md)
1. Functions 
    1. [Intro to Functions](./Lessons/04.%20Intro%20to%20Functions.md)
    1. [Arrow Functions](./Lessons/08.%20Arrow%20Functions.md)
        - Instructor Example Code: [Function Comparison](./Instructor%20Example%20Code/arrowFunctions.js)
    1. [Callback Functions](./Lessons/09.%20Callback%20Functions.md)
        - Instructor Example Code: [Using Callbacks](./Instructor%20Example%20Code/callback_functions/)
1. [Scope](./Lessons/05.%20Scope.md)
1. [Template Literals](./Lessons/11.%20Template%20Literals.md)
    - Instructor Example Code: [JS String Comparison](./Instructor%20Example%20Code/templateLiterals.js)
1. Object Oriented Programming
    1. [Objects](./Lessons/06.%20Objects.md)
    1. [Classes & OOP](./Lessons/07.%20Classes%20&%20OOP.md)
        - Instructor Example Code: [Classes Code-along](./Instructor%20Example%20Code/classes.js)
1. [Asynchronous JavaScript](./Lessons/12.%20Asynchronous%20JS.md)
1. [Immutability vs. Mutability](./Lessons/13.%20Immutability%20vs%20Mutability.md)
    - Instructor Example Code: [X-men](./Instructor%20Example%20Code/mutatingData.js)

    
## Cheatsheets
- [General JavaScript Cheatsheet (Codeacademy)](https://www.codecademy.com/learn/introduction-to-javascript/modules/learn-javascript-introduction/cheatsheet)
- [General JavaScript Cheatsheet (Devhints)](https://devhints.io/es6)
- [General JavaScript Cheatsheet (QuickRef)](https://quickref.me/javascript)
- [Object & Array Methods](https://github.com/LeCoupa/awesome-cheatsheets/blob/master/languages/javascript.js)


## Licensing
1. All content is licensed under a CC­BY­NC­SA 4.0 license.
2. All software code is licensed under GNU GPLv3. For commercial use or alternative licensing, please contact legal@ga.co.

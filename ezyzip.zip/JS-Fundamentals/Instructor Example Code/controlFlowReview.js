/* Truthy & Falsy
------------------------------------------------------------------ */
// const myVariable = 1
// console.log(myVariable === 1) // true
// console.log(myVariable === 3) // false
// console.log(myVariable == 1) // true
// console.log(myVariable == '1') // true
// console.log(myVariable === '1') // false

// if (undefined) {
//     console.log('I will run if the codition is true')
// } else {
//     console.log('I will run if the condition is false')
// }


/* Truthy & Falsy
------------------------------------------------------------------ */
// const myVar = 'my value'
// console.log(myVar)



/* Looping control flow
------------------------------------------------------------------ */
// for (can be used for anything)
// for (let x = 5; x > -10; x--) {
//     console.log(x)
// }

// for (let x = 1; x <= 10; x += 2) {
//     console.log(x)
// }


// for...of (typically used with arrays)
// const myArray = ['a', 'b', 'c', 'd']
// for (let i = 0; i < myArray.length; i++) {
//     console.log(myArray[i])
// }

// for (let letter of ['a', 'b', 'c', 'd']) {
//     console.log(letter)
// }

// for...in (typically used with objects)
// const myObj = { someKey: 'some value', anotherKey: 'another value' }
// for (let whatever in myObj) {
//     console.log(whatever, myObj[whatever])
// }

// while (doesn't necessarily have a set number of reptitions)
let x = 6
while (x > 1) {
    console.log(x)
    x--
}

console.clear()

/* Comparing arrow functions with a regualr function expression
---------------------------------------------- */
const sayHello = function (anotherPerson) {
    let person = "Jorge"
    return "Hello " + anotherPerson + " says " + person
}
console.log(sayHello("Kiara"))

const sayHello2 = (anotherPerson) => {
    let person = "Jorge"
    return "Hello " + anotherPerson + " says " + person
}
// console.log(sayHello2("Kiara"))


/* Single-line arrow functions
---------------------------------------------- */
const oneParamFunc = myParam => console.log(myParam)
// oneParamFunc('my arg')

const noParamFunc = () => console.log('I have no params')
// noParamFunc()

const multiParamFunc = (x, y, z = 5) => x * y - z
// console.log(multiParamFunc(10, .4))


/* Anonymous arrow functions
---------------------------------------------- */
let myVar = 'before the timeout'
console.log(myVar)

setTimeout(() => {
    myVar = 'after the timeout'
    return console.log(myVar)
}, 1000)

// const arrayBy10 = [1, 2, 3].map(function (item) { return item * 10 })
const myArray = [1, 2, 3]
const arrayBy10 = myArray.map(item => item * 10)
console.log(arrayBy10)


/* Arrow functions and the "this" keyword
---------------------------------------------- */
// const ticket = {
//     airlines: 'Air SEB',
//     flight: '0116',
//     seat: 'C19',
//     print: function () {
//         console.log(this.airlines + this.flight + this.seat);
//     }
// }
// ticket.print()


// const ticket = {
//     airlines: 'Air SEI',
//     flight: '0116',
//     seat: 'C19',
//     print: () => {
//         console.log(this.airlines + this.flight + this.seat);
//     }
// }
// WILL NOT WORK



const ticket = {
    airlines: 'Air SEI',
    flight: '0116',
    seat: 'C19',
    print: () => {
        console.log('Printing your ticket');
    }
}
ticket.print()
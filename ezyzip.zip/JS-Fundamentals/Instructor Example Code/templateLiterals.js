// Single-quote string
let myFirstString = '"This is a single quote string" said the person'
console.log(myFirstString)

// Double-quote string
let mySecondString = "This is a d'ouble quote string"
console.log(mySecondString)

// Template Literal
let myThirdString = `This is a back-tick string or template literal`
console.log(myThirdString)



// String Interpolation
const person = {
    firstName: 'Albert',
    lastName: 'Einstein',
    born: 1879,
    note: 'genius'
};

let firstSentence = person.firstName + ' ' + person.lastName + ' was born in ' +
    person.born + ' and was a ' + person.note + '.';
let secondSentence = `${person.firstName} ${person.lastName} was born in ${person.born} and was a ${person.note}.`;
console.log(firstSentence)
console.log(secondSentence)


// Multi-line strings
let twoLines = 'This is line one.\nThis is line two.';
console.log(twoLines)

let twoMoreLines = `This is line one.
This is line two.`;
console.log(twoMoreLines)


let htmlTemplate =
    `
  <div class="panel">
    <div class="title">${person.firstName} ${person.lastName}</div>
    <div class="content">
      <p>Born: ${person.born}</p>
      <p>Note: ${person.note}</p>
    </div>
  </div>
  `;

console.log(htmlTemplate)

console.clear()


/* MUTABLE METHODS
---------------------------------------------------------------------- */
// const arr = ['Charles Xavier', 'James Logan', 'Jean Grey']
// console.log(arr)
// arr.push('Scott Summers')
// console.log(arr)

// const mutant = { name: 'Rogue', alterEgo: 'Jean Grey' }
// console.log(mutant)
// mutant.alterEgo = 'Anne Marie'
// console.log(mutant)


/* IMMUTABLE METHODS
---------------------------------------------------------------------- */
const arr = ['Charles Xavier', 'James Logan', 'Jean Grey']

// .concat method
const newArr = arr.concat('Scott Summers')
// console.log(arr)
// console.log(newArr)

// the spread operator
const newArr2 = [...arr, 'Scott Summers']
// newArr2.push('Scott Summers')
console.log(arr)
console.log(newArr2)

const mutant = { name: 'Rogue', alterEgo: 'Jean Grey' }
const newMutant = { ...mutant, alterEgo: 'Anne Marie', isPowerful: true }
// newMutant.alterEgo = 'Anne Marie'
console.log(mutant)
console.log(newMutant)
console.clear()

// Pillar 1 & 2: Encapsulation & Abstraction
// class Character {
//     constructor(eyes, hair, legs = 2) {
//         this.legs = legs;
//         this.arms = 2;
//         this.eyes = eyes;
//         this.hair = hair;
//     }

//     greet(otherCharacter) {
//         console.log(`hi ${otherCharacter}!`)
//     }
// }


// const me = new Character('blue', 'brown');
// const you = new Character('hazel', 'gray', 4);
// console.log(me)
// console.log(you)

// me.greet('class')
// you.greet('scott')



// Pillar 3: Inheritance
class Character {
    constructor(name, age, eyes, hair, legs = 2) {
        this.legs = legs;
        this.arms = 2;
        this.name = name;
        this.age = age;
        this.eyes = eyes;
        this.hair = hair;
    }
    greet(otherCharacter) {
        console.log('hi ' + otherCharacter + '!');
    }
    classyGreeting(otherClassyCharacter) {
        console.log('Howdy ' + otherClassyCharacter.name + '!');
    }
    setHair(hairColor) {
        this.hair = hairColor;
    }
    smite() {
        console.log('i smited thee.');
    }

}
const hobbit = new Character('Mr Baggins', 33, 'brown', 'black')
// console.log(hobbit);


class Hobbit extends Character {
    constructor(name, eyes, hair, height, legs = 2) {
        // Call the constructor of the parent class (Character) with specified parameters, setting age to 'Unknown'.
        super(name, 'Unknown', eyes, hair, legs)
        // New property unqiue to the Hobbit subclass
        this.height = height;
    }
    // New function specific to the Hobbit subclass
    steal() {
        console.log('lets get away!');
    }
    // Updated function specific to the Hobbit subclass
    greet(otherCharacter) {
        console.log(`Hello ${otherCharacter}`);
    }
}
const frodo = new Hobbit('Frodo', 'blue', 'brown', '3 ft')
console.log(frodo)
frodo.steal()
frodo.greet('Bilbo');
frodo.smite()
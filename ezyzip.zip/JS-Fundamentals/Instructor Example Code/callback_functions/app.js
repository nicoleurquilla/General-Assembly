console.clear()

/* Use Cases for Callbacks
---------------------------------------------- */
// // Array Methods
// [1, 2, 3].forEach(num => console.log(num + 1))

// // Event Handlers
// const btnOne = document.querySelector('button')
// console.log(btnOne)
// btnOne.addEventListener('click', () => alert('You cliked a button!'))

// // Asynchronous JavaScript
// setTimeout(function () { console.log('I will run in 0.5 seconds') }, 2000)
// console.log('I will run before the setTimeout because JavaScript moves on as it is running the setTimeout in the background')



/* Writing Named Callbacks
---------------------------------------------- */
// Define the `primary` (or higher order function)
function primary(anotherFunc) {
    anotherFunc();
}

// Define the `secondary` (or callback) function
function secondary() {
    console.log('Hello from secondary')
}

secondary() // calling secondary directly
// primary() // returns an error because no parameter is passed, meaning `anotherFunc` is undefined, and undefiend cannot be called
// primary('I am not a function') // returns an error because a string is passed, and strings are not callable functions
primary(secondary) // calling secondary using the primary function



/* Writing Anonymous Callbacks
---------------------------------------------- */
function higherOrder(someFunc) {
    someFunc();
}

higherOrder(function () {
    console.log('Hello from anonymous!')
})

higherOrder(() => console.log('I am also anonymous'))


/* Callbacks with parameters
---------------------------------------------- */
function main(callback) {
    callback(5, 3);
}

main((a, b) => console.log(a * b))
/* Clears the console every time we run the JS file
------------------------------------------------------------ */
console.clear()



/* Defining a function will NOT execute it until we invoke (or call) it
------------------------------------------------------------ */
function showMessage() {
    console.log("hello everyone")
}

// some random code....
const myVar = 'my value'
const anotherVar = 'another value'

showMessage // this will not call the function because there are no parantheses
showMessage() // this will call the function because it has parantheses


// Separate outputs between each function
console.log('\n-------------------------------------------------\n')


/* Function declarations vs. function expressions
------------------------------------------------------------ */
sayGoodbye() // function declarations can be called before they are defined

function sayGoodbye() { // in a function declaration, the "function" keyword comes first
    console.log('Good bye!')
}

// sayFarewell() - this will not work, it is not hoisted
const sayFarewell = function () {
    console.log('Farewell!')
}
sayFarewell()


// Separate outputs between each function
console.log('\n-------------------------------------------------\n')


/* Arguments & Parameters
------------------------------------------------------------ */
// Define a function with a parameter (a placeholder for input)
const multiplyByFiveSubtractTen = function (anyNumber = 3) {
    let result = anyNumber * 5
    result -= 10
    return console.log(result)
}
multiplyByFiveSubtractTen(30)
multiplyByFiveSubtractTen(-10)
multiplyByFiveSubtractTen()
multiplyByFiveSubtractTen('string')
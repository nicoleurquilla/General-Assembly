/* Mock database
---------------------------------------------------------- */
const newGirl = [
    { name: 'Coach', occupation: 'Gym Teacher' },
    { name: 'Winston', occupation: 'Police Officer' },
    { name: 'Schmidt', occupation: 'Sales Account Manager' },
    { name: 'Nick', occupation: 'Author/Writer' },
    { name: 'Jess', occupation: 'Principal' },
    { name: 'Cece', occupation: 'CEO' }
]


/* Create loading screen
---------------------------------------------------------- */
const h1 = document.createElement('h1')
h1.id = 'loading-screen'
h1.innerText = 'Loading table...'
document.body.append(h1)


/* Create character table
---------------------------------------------------------- */
let characterTable = `
<div style="display: flex; flex-direction: column; align-items: center">
    <h1 style="text-align: center">New Girl Characters</h1>
    
    <table style="border: 2px solid black; width: 50vw; text-align: center">
        <tr>
            <th>Name</th>
            <th>Occupation</th>
        </tr>
`

for (let character of newGirl) {
    characterTable += `
        <tr>
            <td>${character.name}</td>
            <td>${character.occupation}</td>
        </tr>
    `
}

characterTable += `</table></div>`


/* Asynchronous operations
---------------------------------------------------------- */
// Using a higher-order async function
// setTimeout(() => { document.body.innerHTML = characterTable }, 5000)

// Using a promise
let getData = new Promise(
    function (resolve, reject) {
        setTimeout(() => resolve(characterTable), 5000) // simulate querying our mock database
        // setTimeout(() => reject('database not availabe'), 5000) // simulate failing to reach the database
    });

getData
    .then(dataTable => document.body.innerHTML = dataTable)
    .catch(err => console.log('Could not query the database:', err))







/* ******DEMO ONLY******
---------------------------------------------------------- */
// Consuming a promise
// fetch('https://generalassemb.ly')
//     .then(res => console.log(res))
//     .catch(err => console.log('YOU HAD AN ERROR', err))
//     .finally(() => console.log('I will run after the async operation, no matter the outcome!'))

// Building a promise
// let myPromise = new Promise(
//     function (resolve, reject) {
//         setTimeout(() => resolve("the async operation is complete"), 1000); // whatever your async operation is, such as fetching a website
//     });

// myPromise
//     .then(res => console.log(res))
//     .catch(err => alert(err))
//     .finally(() => console.log('I will run no matter what'))



// fetch('https://pokeapi.co/api/v2/pokemon/ditto')
//     .then(res => res.json())
//     .then(data => console.log(data))
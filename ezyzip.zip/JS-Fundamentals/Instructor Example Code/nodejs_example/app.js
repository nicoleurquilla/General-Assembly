// import the prompt-sync package
const prompt = require('prompt-sync')();


// Prompt the user to answer 'y' or 'n' and don't accept any other values
while (true) {
    // clear the console
    console.clear()

    // store user input in a variable
    let userInput = prompt('Do you like pumpkin pie? (y/n) ')

    if (userInput === 'y') {
        console.log('Cool, me too!')
        break
    } else if (userInput === 'n') {
        console.log('Oh, that\'s a bummer')
        break
    }
}